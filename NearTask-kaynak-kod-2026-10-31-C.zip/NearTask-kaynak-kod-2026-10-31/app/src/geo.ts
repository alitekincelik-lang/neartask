// Postcode-district locations. Approximate centres for the launch region (used offline and in demo mode);
// elsewhere the free postcodes.io service is used.
const OUT: Record<string, [number, number]> = {
  BS1: [51.454, -2.593], BS2: [51.459, -2.578], BS3: [51.440, -2.602], BS4: [51.435, -2.560], BS5: [51.462, -2.550],
  BS6: [51.471, -2.601], BS7: [51.483, -2.587], BS8: [51.455, -2.622], BS9: [51.490, -2.623], BS10: [51.508, -2.602],
  BS11: [51.497, -2.680], BS13: [51.415, -2.611], BS14: [51.416, -2.561], BS15: [51.456, -2.500], BS16: [51.484, -2.508],
  BS20: [51.481, -2.751], BS21: [51.441, -2.852], BS22: [51.360, -2.930], BS23: [51.343, -2.973], BS24: [51.330, -2.940],
  BS30: [51.440, -2.465], BS31: [51.412, -2.497], BS32: [51.540, -2.560], BS34: [51.520, -2.571], BS35: [51.600, -2.550],
  BS36: [51.530, -2.480], BS37: [51.540, -2.410], BS39: [51.330, -2.500], BS40: [51.360, -2.650], BS41: [51.420, -2.660],
  BS48: [51.430, -2.750], BS49: [51.380, -2.810],
  BA1: [51.392, -2.372], BA2: [51.371, -2.360], BA3: [51.290, -2.450], BA11: [51.230, -2.320], BA12: [51.205, -2.180],
  BA13: [51.260, -2.180], BA14: [51.320, -2.200], BA15: [51.350, -2.250],
};
const TOWNS: Record<string, string> = {
  keynsham: "BS31", saltford: "BS31", bath: "BA1", bristol: "BS1", "weston-super-mare": "BS23", weston: "BS23",
  portishead: "BS20", clevedon: "BS21", midsomer: "BA3", radstock: "BA3", frome: "BA11", trowbridge: "BA14",
  "bradford-on-avon": "BA15", kingswood: "BS15", bedminster: "BS3", clifton: "BS8", brislington: "BS4", "chipping sodbury": "BS37",
};

export type LatLng = { lat: number; lng: number };

/** Centre of the service area (Keynsham) and how far from it a saved location still counts as "near". */
export const HOME_CENTRE: LatLng = { lat: 51.4134, lng: -2.4979 };
export const SERVICE_RADIUS_KM = 60;

export function outcodeOf(text: string): string | null {
  const m = text.toUpperCase().match(/\b([A-Z]{1,2}\d{1,2}[A-Z]?)(?:\s*\d[A-Z]{2})?\b/);
  if (m) return m[1];
  const low = text.toLowerCase();
  for (const town in TOWNS) if (low.includes(town)) return TOWNS[town];
  return null;
}

/** Instant, offline lookup for the launch region. */
export function locate(text: string): LatLng | null {
  const oc = outcodeOf(text);
  const p = oc ? OUT[oc] : null;
  return p ? { lat: p[0], lng: p[1] } : null;
}

/** Offline table first, then postcodes.io (live mode only). */
export async function geocode(text: string, online: boolean): Promise<LatLng | null> {
  const hit = locate(text);
  if (hit || !online) return hit;
  const oc = outcodeOf(text);
  if (!oc) return null;
  try {
    const r = await fetch("https://api.postcodes.io/outcodes/" + encodeURIComponent(oc));
    const j = await r.json();
    return j?.result ? { lat: j.result.latitude, lng: j.result.longitude } : null;
  } catch {
    return null;
  }
}

export function km(a: LatLng, b: LatLng): number {
  const R = 6371, d = Math.PI / 180;
  const x = Math.sin(((b.lat - a.lat) * d) / 2) ** 2 + Math.cos(a.lat * d) * Math.cos(b.lat * d) * Math.sin(((b.lng - a.lng) * d) / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

export function fmtKm(k: number | undefined): string {
  if (k === undefined) return "";
  const mi = k * 0.621371;
  return mi < 0.5 ? "< 0.5 mi" : mi.toFixed(mi < 10 ? 1 : 0) + " mi";
}

export function myLocation(): Promise<LatLng | null> {
  return new Promise((res) => {
    if (!navigator.geolocation) return res(null);
    navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude, lng: p.coords.longitude }), () => res(null), { timeout: 8000, maximumAge: 600000 });
  });
}
