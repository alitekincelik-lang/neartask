import type { Filters, Listing } from "./types";
import { km, locate } from "./geo";

export function today(offset = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

export function daysFromToday(date: string): number {
  const a = new Date();
  a.setHours(0, 0, 0, 0);
  const b = new Date(date + "T00:00");
  return Math.round((b.getTime() - a.getTime()) / 864e5);
}

export type WhenLabel = "past" | "today" | "tomorrow" | "week" | "later";
export function whenOf(date: string): WhenLabel {
  const n = daysFromToday(date);
  return n < 0 ? "past" : n === 0 ? "today" : n === 1 ? "tomorrow" : n <= 7 ? "week" : "later";
}

/** Shared client-side filter, used by demo mode and as a final pass in live mode. */
export function applyFilters(list: Listing[], f: Filters): Listing[] {
  const q = f.q.trim().toLowerCase();
  const out = list.filter((l) => {
    if (l.status !== "open" || daysFromToday(l.date) < 0) return false;
    if (f.kind !== "all" && l.kind !== f.kind) return false;
    if (f.category !== "all" && l.category !== f.category) return false;
    if (f.when !== "any") {
      const n = daysFromToday(l.date);
      if (f.when === "today" && n !== 0) return false;
      if (f.when === "tomorrow" && n !== 1) return false;
      if (f.when === "week" && n > 7) return false;
    }
    if (q && !(l.title + " " + l.area + " " + l.description + " " + (l.owner?.name || "")).toLowerCase().includes(q)) return false;
    return true;
  });
  if (f.near) {
    for (const l of out) {
      const p = l.lat != null && l.lng != null ? { lat: l.lat, lng: l.lng } : locate(l.area);
      l.distance = p ? km(f.near, p) : undefined;
    }
  }
  const soon = (a: Listing, b: Listing) => (a.date + (a.start_time || "")).localeCompare(b.date + (b.start_time || ""));
  out.sort((a, b) =>
    f.sort === "new" ? b.created_at.localeCompare(a.created_at)
    : f.sort === "near" ? (a.distance ?? 999) - (b.distance ?? 999) || soon(a, b)
    : soon(a, b)
  );
  return out;
}

export function uid(): string {
  return (crypto as any).randomUUID ? crypto.randomUUID() : "id" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function lsGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
export function lsSet(key: string, v: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {}
}

/** Resize a photo in the browser before upload (max 1280px, JPEG). */
export function shrinkImage(file: File, max = 1280): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * s);
      c.height = Math.round(img.height * s);
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob((b) => (b ? resolve(b) : reject(new Error("image"))), "image/jpeg", 0.82);
    };
    img.onerror = () => reject(new Error("image"));
    img.src = url;
  });
}

export function blobToDataUrl(b: Blob): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(b);
  });
}

// ---- Time helpers (UK local time) ----

/** Minutes Europe/London is ahead of UTC at the given moment (0 in winter, 60 in summer). */
export function londonOffsetMin(ts: number): number {
  const p = new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/London", hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })
    .formatToParts(new Date(ts)).reduce((o, x) => ({ ...o, [x.type]: x.value }), {} as Record<string, string>);
  const asUtc = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute);
  return Math.round((asUtc - ts) / 6e4);
}

type Timed = { date: string; start_time?: string | null; end_time?: string | null };

/** When a job ends (ms). Same rule as job_end_at() in the database: no end time = end of the day; an end before the start = next day. */
export function jobEndAt(l: Timed): number {
  const end = l.end_time ? l.end_time.slice(0, 5) : "23:59";
  const [y, m, d] = l.date.split("-").map(Number);
  const [h, mi] = end.split(":").map(Number);
  let t = Date.UTC(y, m - 1, d, h, mi, l.end_time ? 0 : 59);
  if (l.end_time && l.start_time && l.end_time.slice(0, 5) <= l.start_time.slice(0, 5)) t += 864e5;
  return t - londonOffsetMin(t - (t % 6e4)) * 6e4;
}

/** When a job starts (ms); 09:00 if no start time. */
export function jobStartAt(l: Timed): number {
  const [y, m, d] = l.date.split("-").map(Number);
  const [h, mi] = (l.start_time ? l.start_time.slice(0, 5) : "09:00").split(":").map(Number);
  const t = Date.UTC(y, m - 1, d, h, mi);
  return t - londonOffsetMin(t) * 6e4;
}

/** "12" → "£12.00"; anything else is kept as typed. */
export function money(v: string | null | undefined): string {
  const s = (v || "").trim();
  return /^\d+(\.\d{1,2})?$/.test(s) ? "£" + Number(s).toFixed(2) : s;
}

/** Turn a typed amount into the pay text: "£12.50/hr" or "£40 fixed". Free text is kept. */
export function payText(v: string, unit: "hour" | "total"): string {
  const s = v.trim().replace(/^£\s*/, "");
  if (!/^\d+(\.\d{1,2})?$/.test(s)) return v.trim();
  const n = Number(s);
  return unit === "hour" ? "£" + n.toFixed(2) + "/hr" : "£" + (Number.isInteger(n) ? n : n.toFixed(2)) + " fixed";
}

/** A person's name, or a neutral fallback when they have not added one yet. */
export function nameOf(p: { name?: string | null } | null | undefined, fallback = "NearTask member"): string {
  return (p?.name || "").trim() || fallback;
}

/** UK National Living Wage (21+) per hour, from April 2026. Used to warn about low hourly pay. */
export const NLW = 12.71;

// ---- Calendar (.ics and Google Calendar link) ----

export interface CalEvent { uid: string; title: string; start: number; end: number; place: string; details: string; url: string }

const icsTime = (ms: number) => new Date(ms).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
const icsText = (s: string) => s.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/([,;])/g, "\\$1");

export function calEvent(l: Timed & { title: string; area?: string }, appId: string, withName: string, address?: string | null): CalEvent {
  const start = jobStartAt(l);
  let end = l.end_time ? jobEndAt(l) : start + 3 * 36e5;
  if (end <= start) end = start + 36e5;
  const url = "https://neartask.co.uk/#/chat/" + appId;
  return { uid: appId + "@neartask.co.uk", title: l.title + " (NearTask)", start, end, place: address || l.area || "", details: "With " + withName + ". Messages and changes: " + url, url };
}

/** An iCalendar file with a reminder 2 hours before. */
export function icsFile(e: CalEvent): string {
  const fold = (line: string) => (line.length <= 74 ? line : line.match(/.{1,73}/g)!.join("\r\n "));
  return ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//NearTask//Shift//EN", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
    "BEGIN:VEVENT", "UID:" + e.uid, "DTSTAMP:" + icsTime(Date.now()), "DTSTART:" + icsTime(e.start), "DTEND:" + icsTime(e.end),
    "SUMMARY:" + icsText(e.title), "LOCATION:" + icsText(e.place), "DESCRIPTION:" + icsText(e.details), "URL:" + e.url,
    "BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + icsText(e.title), "TRIGGER:-PT2H", "END:VALARM",
    "END:VEVENT", "END:VCALENDAR", ""].map(fold).join("\r\n");
}

export function googleCalUrl(e: CalEvent): string {
  return "https://calendar.google.com/calendar/render?" + new URLSearchParams({ action: "TEMPLATE", text: e.title, dates: icsTime(e.start) + "/" + icsTime(e.end), details: e.details, location: e.place }).toString();
}

// ---- Badges ----

/** An open shift that starts within the next 48 hours. */
export function isUrgent(l: { kind: string; status?: string; date: string; start_time?: string | null }, now = Date.now()): boolean {
  if (l.kind !== "job" || (l.status && l.status !== "open") || !l.start_time) return false;
  const s = jobStartAt(l);
  return s > now && s - now <= 48 * 36e5;
}

function londonWeekday(now = Date.now()): string {
  return new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/London", weekday: "short" }).format(new Date(now)).toLowerCase().slice(0, 3);
}

/** Looking for work and free today (no days chosen = any day). */
export function availableToday(p: { available?: boolean; available_days?: string[] | null }, now = Date.now()): boolean {
  return !!p.available && (!p.available_days?.length || p.available_days.includes(londonWeekday(now)));
}
