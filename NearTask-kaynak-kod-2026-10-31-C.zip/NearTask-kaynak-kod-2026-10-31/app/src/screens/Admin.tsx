import { useState, type ReactNode } from "react";
import { useApp } from "../state";
import type { AdminCancellation, AdminCompletion, AdminListing, AdminListingFilter, AdminReport, Profile } from "../types";
import { Avatar, Empty, Icon, Loading, Sheet, TopBar, useLoad } from "../ui";
import { fmtAgo, fmtDate, type Key } from "../i18n";
import { COMPANY, setSupportEmail } from "../company";

type Tab = "overview" | "reports" | "users" | "jobs" | "settings";

export function Admin() {
  const { api, t, isAdmin, uid, me } = useApp();
  const [tab, setTab] = useState<Tab>("overview");
  if (!uid || !me) return <div className="screen"><Loading /></div>;
  if (!isAdmin) return <div className="screen"><TopBar backTo="/me" /><Empty icon="lock" text={t("notFound")} /></div>;
  return (
    <div className="screen">
      <TopBar title={t("adminPanel")} backTo="/me" />
      <div className="seg tabs">
        {(["overview", "reports", "users", "jobs", "settings"] as Tab[]).map((x) => (
          <button key={x} className={tab === x ? "on" : ""} onClick={() => setTab(x)}>{t(("a." + x) as Key)}</button>
        ))}
      </div>
      {tab === "overview" ? <Overview go={setTab} /> : tab === "reports" ? <Reports /> : tab === "jobs" ? <Jobs /> : tab === "settings" ? <Settings /> : <Users />}
      {api.mode === "demo" && <p className="note">Demo: you're shown as the admin so you can try this screen. In the live app only accounts marked as admin see it.</p>}
    </div>
  );
}

function Settings() {
  const { api, t, toast } = useApp();
  const [email, setEmail] = useState(COMPANY.email);
  const [busy, setBusy] = useState(false);
  const clean = email.trim().toLowerCase();
  const save = async () => {
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(clean)) return toast(t("a.supportEmailBad"));
    setBusy(true);
    try {
      await api.adminSetSetting("support_email", clean);
      setSupportEmail(clean);
      setEmail(clean);
      toast(t("a.supportEmailSaved"));
    } catch { toast(t("error")); } finally { setBusy(false); }
  };
  return (
    <>
      <h2 className="sec">{t("a.supportEmail")}</h2>
      <p className="mute xs">{t("a.supportEmailHint")}</p>
      <label>{t("a.supportEmailLabel")}
        <input type="email" inputMode="email" autoComplete="off" maxLength={120} value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <button className="btn full" disabled={busy || clean === COMPANY.email} onClick={save}>{t("save")}</button>
    </>
  );
}

/** Date and time in UK time, e.g. "31 Oct 2026, 14:05". */
const fmtTime = (iso: string) => new Date(iso).toLocaleString("en-GB", { timeZone: "Europe/London", day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

interface NoteAsk { title: string; hint?: string; required?: boolean; run(note: string): Promise<void> }

/** Every admin action asks for a short note, saved in the audit log. Suspending and verifying require one. */
function useNoteSheet(): { open(a: NoteAsk): void; sheet: ReactNode } {
  const { t, toast } = useApp();
  const [ask, setAsk] = useState<NoteAsk | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const open = (a: NoteAsk) => { setNote(""); setAsk(a); };
  const confirm = async () => {
    if (!ask || busy) return;
    if (ask.required && note.trim().length < 5) return toast(t("a.noteRequired"));
    setBusy(true);
    try { await ask.run(note.trim()); toast(t("saved")); setAsk(null); }
    catch (e) { toast(String((e as Error)?.message || "").includes("NOTE") ? t("a.noteRequired") : t("error")); }
    finally { setBusy(false); }
  };
  const sheet = (
    <Sheet open={!!ask} onClose={() => setAsk(null)} title={ask?.title || ""}>
      {ask?.hint && <p className="mute">{ask.hint}</p>}
      <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder={ask?.required ? t("a.reason") : ""} maxLength={300} />
      <div className="btnrow">
        <button className="btn ghost" onClick={() => setAsk(null)}>{t("cancel")}</button>
        <button className="btn" disabled={busy || (!!ask?.required && note.trim().length < 5)} onClick={confirm}>{t("a.confirm")}</button>
      </div>
    </Sheet>
  );
  return { open, sheet };
}

function Overview({ go }: { go(t: Tab): void }) {
  const { api, t } = useApp();
  const [o] = useLoad(() => api.adminOverview(), [api]);
  if (!o) return <Loading />;
  const tiles: [Key, number, string][] = [
    ["a.usersTotal", o.users, "user"], ["a.new", o.new_users_7d, "plus"], ["a.biz", o.businesses, "briefcase"], ["a.seekers", o.seekers, "search"],
    ["a.open", o.open_listings, "list"], ["a.apps", o.applications, "check"], ["a.msgs", o.messages_7d, "chat"], ["a.openReports", o.open_reports, "flag"],
  ];
  return (
    <>
      <div className="kpis">
        {tiles.map(([k, v, icon]) => (
          <button key={k} className={"kpi" + (k === "a.openReports" && v > 0 ? " alert" : "")} onClick={() => k === "a.openReports" && go("reports")}>
            <Icon name={icon} size={18} /><b>{v.toLocaleString()}</b><span>{t(k)}</span>
          </button>
        ))}
      </div>
      <RecentActions />
    </>
  );
}

function RecentActions() {
  const { api, t, lang } = useApp();
  const [list] = useLoad(() => api.adminActions(), [api]);
  return (
    <>
      <h2 className="sec">{t("a.recent")}</h2>
      {!list ? <Loading /> : !list.length ? <p className="mute">{t("a.noActions")}</p> : (
        <ul className="mute xs">
          {list.slice(0, 20).map((a) => (
            <li key={a.id}>
              {fmtAgo(lang, a.created_at)} · <b>{a.actor_name || "Admin"}</b> · {a.action.replace(/_/g, " ")}
              {a.user_name ? " · " + a.user_name : ""}{a.listing_title ? " · " + a.listing_title : ""}{a.note ? ' — "' + a.note + '"' : ""}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function Reports() {
  const { api, t, lang, toast, go } = useApp();
  const ask = useNoteSheet();
  const [filter, setFilter] = useState<"open" | "all">("open");
  const [list, reload] = useLoad(() => api.adminReports(), [api]);
  if (!list) return <Loading />;
  const shown = list.filter((r) => filter === "all" || r.status === "open");
  const act = async (fn: () => Promise<void>, msg: Key) => { try { await fn(); toast(t(msg)); reload(); } catch { toast(t("error")); } };
  const target = (r: AdminReport) => r.reported_user_id || r.listing_owner;
  return (
    <>
      <div className="chips">
        <button className={"chip" + (filter === "open" ? " on" : "")} onClick={() => setFilter("open")}>{t("a.status.open")}</button>
        <button className={"chip" + (filter === "all" ? " on" : "")} onClick={() => setFilter("all")}>{t("all")}</button>
      </div>
      {!shown.length ? <Empty icon="check" text={t("a.noReports")} /> : shown.map((r) => (
        <div key={r.id} className={"reportcard st-" + r.status}>
          <div className="trow">
            <b className="ellip">{r.listing_title ? r.listing_title : r.reported_name}</b>
            <span className={"status sm " + (r.status === "open" ? "st-pending" : "st-declined")}>{t(("a.status." + r.status) as Key)}</span>
          </div>
          <span className="mute xs block">{r.listing_title ? r.reported_name + " · " : ""}{t("a.reportedBy", { name: r.reporter_name || "No name" })} · {fmtAgo(lang, r.created_at)}</span>
          <p className="quote">"{r.reason}"</p>
          {r.reported_banned && <span className="tag off">{t("a.suspended")}</span>}
          <div className="btnwrap">
            {r.listing_id && <button className="btn ghost sm" onClick={() => go("/l/" + r.listing_id)}><Icon name="search" size={15} /> View</button>}
            {r.listing_id && (r.listing_status === "closed"
              ? <button className="btn ghost sm" onClick={() => ask.open({ title: t("a.reopenListing"), run: async (n) => { await api.adminSetListingStatus(r.listing_id!, "open", n); reload(); } })}>{t("a.reopenListing")}</button>
              : <button className="btn ghost sm" onClick={() => ask.open({ title: t("a.closeListing"), run: async (n) => { await api.adminSetListingStatus(r.listing_id!, "closed", n); reload(); } })}>{t("a.closeListing")}</button>)}
            {target(r) && (r.reported_banned
              ? <button className="btn ghost sm" onClick={() => ask.open({ title: t("a.unban"), run: async (n) => { await api.adminSetBanned(target(r)!, false, n); reload(); } })}>{t("a.unban")}</button>
              : <button className="btn danger sm" onClick={() => ask.open({ title: t("a.banQ"), hint: t("a.banHint"), required: true, run: async (n) => { await api.adminSetBanned(target(r)!, true, n); reload(); } })}>{t("a.ban")}</button>)}
            {r.status === "open" && <>
              <button className="btn sm" onClick={() => act(() => api.adminResolveReport(r.id, "resolved"), "saved")}><Icon name="check" size={15} /> {t("a.resolve")}</button>
              <button className="btn ghost sm" onClick={() => act(() => api.adminResolveReport(r.id, "dismissed"), "saved")}>{t("a.dismiss")}</button>
            </>}
          </div>
        </div>
      ))}
      {ask.sheet}
    </>
  );
}

function Users() {
  const { api, t, go } = useApp();
  const [q, setQ] = useState("");
  const [list, reload] = useLoad(() => api.adminSearch(q), [api, q]);
  const ask = useNoteSheet();
  return (
    <>
      <label className="searchbox"><Icon name="search" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("a.search")} type="search" /></label>
      {!list ? <Loading /> : !list.length ? <Empty icon="user" text={t("none")} /> : list.map((p: Profile) => (
        <div key={p.id} className="usercard">
          <button className="owner flat" onClick={() => go("/u/" + p.id)}>
            <Avatar p={p} size={40} />
            <span className="grow"><b className="ellip block">{p.name || "No name yet"}</b>
              <span className="mute xs">{t(p.account_type === "business" ? "business" : "person")}{p.postcode ? " · " + p.postcode : ""}</span></span>
            {p.verified && <span className="vtag"><Icon name="check" size={12} /> {t("verified")}</span>}
            {p.banned && <span className="tag off">{t("a.suspended")}</span>}
          </button>
          <div className="btnwrap">
            <button className="btn ghost sm" onClick={() => ask.open(p.verified
              ? { title: t("a.unverify"), run: async (n) => { await api.adminSetVerified(p.id, false, n); reload(); } }
              : { title: t("a.verifyQ"), hint: t("a.verifyHint"), required: true, run: async (n) => { await api.adminSetVerified(p.id, true, n); reload(); } })}>
              {p.verified ? t("a.unverify") : t("a.verify")}
            </button>
            <button className={"btn sm " + (p.banned ? "ghost" : "danger")} onClick={() => ask.open(p.banned
              ? { title: t("a.unban"), run: async (n) => { await api.adminSetBanned(p.id, false, n); reload(); } }
              : { title: t("a.banQ"), hint: t("a.banHint"), required: true, run: async (n) => { await api.adminSetBanned(p.id, true, n); reload(); } })}>
              {p.banned ? t("a.unban") : t("a.ban")}
            </button>
          </div>
        </div>
      ))}
      {ask.sheet}
    </>
  );
}

type JobFilter = "completed" | Exclude<AdminListingFilter, "all"> | "cancelled";

/** Listings by status, cancellations and completed jobs. */
function Jobs() {
  const { api, t, lang, go } = useApp();
  const [f, setF] = useState<JobFilter>("completed");
  const ask = useNoteSheet();
  const [list, reload] = useLoad<(AdminListing | AdminCancellation)[] | null>(
    () => (f === "completed" ? Promise.resolve(null) : f === "cancelled" ? api.adminCancellations() : api.adminListings(f)), [api, f]);
  const view = (id: string) => <button className="btn ghost sm" onClick={() => go("/l/" + id)}><Icon name="search" size={15} /> View</button>;
  return (
    <>
      <div className="chips">
        {(["completed", "open", "filled", "closed", "reported", "cancelled"] as JobFilter[]).map((x) => (
          <button key={x} className={"chip" + (f === x ? " on" : "")} onClick={() => setF(x)}>{t(("a.f." + x) as Key)}</button>
        ))}
      </div>
      {f === "completed" ? <Completions /> : !list ? <Loading /> : !list.length ? <Empty icon="check" text={t("a.none")} />
        : f === "cancelled" ? (list as AdminCancellation[]).map((c) => (
          <div key={c.id} className={"reportcard " + (c.late ? "st-open" : "st-resolved")}>
            <div className="trow"><b className="ellip">{c.title}</b>{c.late && <span className="status sm st-declined">{t("a.late")}</span>}</div>
            <span className="mute xs block">{fmtDate(lang, c.date)} · {t("a.cancelledBy", { name: c.actor_name || "No name", d: fmtAgo(lang, c.created_at) })}</span>
            <p className="quote">"{c.reason}"</p>
            <div className="btnwrap">{view(c.listing_id)}</div>
          </div>
        ))
        : (list as AdminListing[]).map((l) => (
          <div key={l.id} className={"reportcard " + (l.open_reports ? "st-open" : "st-resolved")}>
            <div className="trow">
              <b className="ellip">{l.title}</b>
              <span className={"status sm st-" + (l.status === "open" ? "accepted" : "declined")}>{t(l.status === "open" ? "a.f.open" : l.status === "filled" ? "a.f.filled" : "a.f.closed")}</span>
            </div>
            <span className="mute xs block">{t("a.listingMeta", { owner: l.owner_name || "No name", d: fmtDate(lang, l.date), acc: l.accepted, pos: l.positions, pend: l.pending, views: l.views })}</span>
            {l.open_reports > 0 && <span className="tag off">{t("a.openReportsN", { n: l.open_reports })}</span>}
            <div className="btnwrap">
              {view(l.id)}
              {l.status === "closed"
                ? <button className="btn ghost sm" onClick={() => ask.open({ title: t("a.reopenListing"), run: async (n) => { await api.adminSetListingStatus(l.id, "open", n); reload(); } })}>{t("a.reopenListing")}</button>
                : <button className="btn ghost sm" onClick={() => ask.open({ title: t("a.closeListing"), run: async (n) => { await api.adminSetListingStatus(l.id, "closed", n); reload(); } })}>{t("a.closeListing")}</button>}
            </div>
          </div>
        ))}
      {ask.sheet}
    </>
  );
}

/** Recently completed jobs; jobs marked done before they ended are flagged, and an admin can undo a completion. */
function Completions() {
  const { api, t, toast, go } = useApp();
  const [list, reload] = useLoad(() => api.adminRecentCompletions(), [api]);
  const [open, setOpen] = useState<AdminCompletion | null>(null);
  const [hist, reloadHist] = useLoad(() => (open ? api.adminJobHistory(open.id) : Promise.resolve(null)), [api, open?.id]);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const revert = async () => {
    if (!open || busy) return;
    setBusy(true);
    try { await api.adminRevertCompletion(open.id, reason.trim()); toast(t("a.reverted")); setReason(""); reloadHist(); reload(); }
    catch { toast(t("error")); }
    finally { setBusy(false); }
  };
  if (!list) return <Loading />;
  return (
    <>
      {!list.length ? <Empty icon="check" text={t("a.noCompletions")} /> : list.map((c) => (
        <div key={c.id} className={"reportcard " + (c.early ? "st-open" : "st-resolved")}>
          <div className="trow"><b className="ellip">{c.title}</b>{c.early && <span className="status sm st-declined">{t("a.early")}</span>}</div>
          <span className="mute xs block">{t("a.parties", { owner: c.owner_name || "No name", worker: c.applicant_name || "No name" })} · {t("a.endsAt", { d: fmtTime(c.ends_at) })}</span>
          <span className="mute xs block">{t("a.completedBy", { name: c.completed_by_name || "Not recorded", d: fmtTime(c.completed_at) })} · {t("a.reviewsN", { n: c.reviews })}</span>
          <div className="btnwrap">
            <button className="btn ghost sm" onClick={() => go("/l/" + c.listing_id)}><Icon name="search" size={15} /> View</button>
            <button className="btn sm" onClick={() => { setReason(""); setOpen(c); }}><Icon name="clock" size={15} /> {t("a.history")}</button>
          </div>
        </div>
      ))}
      <Sheet open={!!open} onClose={() => setOpen(null)} title={t("a.history")}>
        {!hist ? <Loading /> : <>
          <p><b>{hist.title}</b><br /><span className="mute xs">{t("a.endsAt", { d: fmtTime(hist.ends_at) })}</span></p>
          <ul className="mute xs">
            <li>{fmtTime(hist.created_at)} · {t("a.ev.created")}</li>
            {hist.events.map((e) => (
              <li key={e.id}>{fmtTime(e.created_at)} · {t(("a.ev." + e.event) as Key, { name: e.actor_name || "No name" })}{e.reason ? ' — "' + e.reason + '"' : ""}</li>
            ))}
          </ul>
          {hist.completed_at && <>
            <p className="mute xs">{t("a.revertHint")}</p>
            <textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder={t("a.reason")} maxLength={500} />
            <button className="btn full danger" disabled={busy || reason.trim().length < 5} onClick={revert}>{t("a.revert")}</button>
          </>}
        </>}
      </Sheet>
    </>
  );
}
