import { useEffect, useRef, useState } from "react";
import { useApp } from "../state";
import type { Application, Message, Review } from "../types";
import { Avatar, Empty, Icon, Loading, Sheet, TopBar, useLoad } from "../ui";
import { fmtAgo, fmtDate, type Key } from "../i18n";
import { isOffensive } from "../moderation";
import { fmtPrice, quoteExpired } from "../categories";
import type { PriceUnit } from "../types";
import { calEvent, googleCalUrl, icsFile, jobEndAt, money, nameOf } from "../util";

export function Inbox() {
  const { t, go, lang, threads, isUnread, uid, needAuth, blocked } = useApp();
  useEffect(() => { needAuth(); }, [needAuth]);
  if (!uid) return <div className="screen"><Loading /></div>;
  return (
    <div className="screen">
      <h1 className="pagetitle">{t("inbox")}</h1>
      {!threads.length ? <Empty icon="chat" text={t("noThreads")} action={<button className="btn" onClick={() => go("/explore")}>{t("explore")}</button>} /> :
        threads.filter((th) => !blocked.has(th.other?.id)).map((th) => {
          const un = isUnread(th);
          return (
            <button key={th.app.id} className={"thread" + (un ? " unread" : "")} onClick={() => go("/chat/" + th.app.id)}>
              <Avatar p={th.other} size={48} />
              <span className="grow">
                <span className="trow"><b className="ellip">{nameOf(th.other)}</b><span className="mute xs">{th.last ? fmtAgo(lang, th.last.created_at) : ""}</span></span>
                <span className="mute xs ellip block">{th.listing.title} · {fmtDate(lang, th.listing.date)}{th.app.price != null ? " · " + fmtPrice(th.app.price, th.app.price_unit) : ""}</span>
                <span className="ellip block tlast">{th.last ? (th.last.sender_id === uid ? t("you") + ": " : "") + th.last.body : ""}</span>
              </span>
              <span className={"status sm st-" + th.app.status}>{t(("st." + th.app.status) as Key)}</span>
              {un && <span className="dot" aria-label={t("newMsg")} />}
            </button>
          );
        })}
    </div>
  );
}

export function Chat({ id }: { id: string }) {
  const { api, t, lang, uid, go, markSeen, toast, refreshThreads, needAuth, blocked } = useApp();
  const [app, setApp] = useState<Application | null>();
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [rateOpen, setRateOpen] = useState(false);
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState("");
  const [doneOpen, setDoneOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [probOpen, setProbOpen] = useState(false);
  const [problem, setProblem] = useState("");
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [newPrice, setNewPrice] = useState("");
  const [newUnit, setNewUnit] = useState<PriceUnit>("total");
  const [calOpen, setCalOpen] = useState(false);
  const [calAddress, setCalAddress] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const [myReview, reloadReview] = useLoad<Review | null>(() => (uid ? api.myReview(id) : Promise.resolve(null)), [api, id, uid]);

  useEffect(() => { needAuth(); }, [needAuth]);
  useEffect(() => {
    let live = true;
    const load = async () => {
      const [a, m] = await Promise.all([api.getApplication(id), api.messages(id)]);
      if (!live) return;
      setApp(a); setMsgs(m); markSeen(id);
    };
    load();
    const off = api.subscribe(id, load);
    return () => { live = false; off(); };
  }, [api, id, markSeen]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);

  if (app === undefined) return <div className="screen"><TopBar backTo="/inbox" /><Loading /></div>;
  if (!app || !app.listing) return <div className="screen"><TopBar backTo="/inbox" /><Empty icon="chat" text={t("notFound")} /></div>;
  const l = app.listing;
  const owner = l.owner_id === uid;
  const other = owner ? app.applicant : l.owner;
  const otherName = nameOf(other);
  const errOf = (e: unknown) => String((e as Error)?.message || "");

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    if (isOffensive(body)) return toast(t("offensive"));
    setText("");
    try { await api.send(id, body); refreshThreads(); } catch { toast(t("error")); setText(body); }
  };
  const setStatus = async (s: "accepted" | "declined" | "withdrawn") => {
    try { await api.setApplicationStatus(id, s); toast(t(("st." + s) as Key)); }
    catch (e) {
      const m = errOf(e);
      toast(t(m.includes("FULL") ? "listingFull" : m.includes("ACCEPTED_LOCKED") ? "acceptedLocked" : s === "accepted" ? "quoteExpiredOwner" : "error"));
    }
  };
  const expired = quoteExpired(app);
  const sendQuote = async () => {
    const n = Number(newPrice.replace(/[£,\s]/g, ""));
    if (!(n >= 1 && n < 100000)) return toast(t("badPrice"));
    try { await api.updateQuote(id, { price: Math.round(n * 100) / 100, unit: newUnit }); setQuoteOpen(false); toast(t("quoteUpdated")); setApp(await api.getApplication(id)); refreshThreads(); }
    catch { toast(t("error")); }
  };
  const submitReview = async () => {
    if (busy) return;
    setBusy(true);
    try { await api.review(id, other!.id, stars, comment.trim()); toast(t("thanksReview")); setRateOpen(false); reloadReview(); }
    catch (e) {
      const m = errOf(e);
      toast(t(m.includes("NOT_COMPLETED") ? "rateAfterDone" : m.includes("ALREADY_REVIEWED") || m.includes("duplicate") ? "alreadyRated" : "error"));
      reloadReview();
    } finally { setBusy(false); }
  };
  const markDone = async () => {
    if (busy) return;
    setBusy(true);
    try { await api.completeJob(id); setDoneOpen(false); toast(t("jobDoneToast")); setApp(await api.getApplication(id)); setRateOpen(true); }
    catch (e) {
      const m = errOf(e);
      setDoneOpen(false);
      toast(t(m.includes("NOT_FINISHED") ? "notFinished" : m.includes("Already completed") ? "alreadyDone" : "error"));
      setApp(await api.getApplication(id));
    } finally { setBusy(false); }
  };
  const cancelJob = async () => {
    if (busy) return;
    if (cancelReason.trim().length < 5) return toast(t("reasonShort"));
    setBusy(true);
    try { await api.cancelJob(id, cancelReason.trim()); setCancelOpen(false); setCancelReason(""); toast(t("cancelledToast")); setApp(await api.getApplication(id)); refreshThreads(); }
    catch (e) { const m = errOf(e); toast(t(m.includes("ENDED") ? "jobEnded" : m.includes("REASON") ? "reasonShort" : "error")); }
    finally { setBusy(false); }
  };
  const sendProblem = async () => {
    try { await api.reportJobProblem(id, problem.trim()); setProbOpen(false); setProblem(""); toast(t("problemSent")); }
    catch (e) { toast(errOf(e).includes("72") || errOf(e) === "window" ? t("problemLate") : t("error")); }
  };
  // A job can be marked done (and is no longer cancellable) once its end time has passed, in UK time.
  const endsAt = jobEndAt(l);
  const ended = Date.now() >= endsAt;
  const endsText = new Date(endsAt).toLocaleString("en-GB", { timeZone: "Europe/London", weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  const since = app.completed_at ? Date.parse(app.completed_at) : Date.parse(l.date + "T23:59:59");
  const canReport = app.status === "accepted" && Date.now() <= since + 72 * 3600 * 1000;
  // The calendar entry includes the exact address, which only the two people in the job can read.
  const openCalendar = async () => {
    setCalOpen(true);
    try { setCalAddress(await api.getAddress(l.id)); } catch { setCalAddress(null); }
  };
  const cal = calEvent(l, app.id, otherName, calAddress);
  const downloadIcs = () => {
    const url = URL.createObjectURL(new Blob([icsFile(cal)], { type: "text/calendar;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url; a.download = "neartask-shift.ics";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    setCalOpen(false);
  };

  let lastDay = "";
  return (
    <div className="screen chat">
      <TopBar backTo="/inbox" title={otherName} right={<button className="iconbtn" onClick={() => go("/u/" + other?.id)} aria-label={t("profile")}><Avatar p={other} size={32} /></button>} />
      <button className="ctx" onClick={() => go("/l/" + l.id)}>
        <span className="grow ellip"><span className="mute xs">{t("aboutListing")}</span><br /><b>{l.title}</b> · {fmtDate(lang, l.date)} · {app.price != null ? t("quote") + " " + fmtPrice(app.price, app.price_unit) : money(l.pay)}</span>
        <span className={"status sm st-" + app.status}>{t(("st." + app.status) as Key)}</span>
      </button>
      {app.status === "cancelled" && <p className="banner off"><Icon name="x" size={16} /> {t("cancelledBanner")}</p>}
      {app.status === "accepted" && !owner && <p className="banner ok"><Icon name="check" size={16} /> {t("acceptedBanner")}</p>}
      {!owner && app.status === "invited" && (<>
        <p className="banner invite"><Icon name="briefcase" size={16} /> {t("invitedBanner", { name: otherName })}</p>
        <div className="btnrow pad"><button className="btn ghost" onClick={() => setStatus("declined")}>{t("decline")}</button>
          <button className="btn" onClick={() => setStatus("accepted")}><Icon name="check" /> {t("acceptInvite")}</button></div>
      </>)}
      {app.status === "pending" && expired && (owner
        ? <p className="banner off"><Icon name="clock" size={16} /> {t("quoteExpiredOwner")}</p>
        : <div className="banner off"><Icon name="clock" size={16} /> <span className="grow">{t("quoteExpiredMine")}</span>
          <button className="btn sm" onClick={() => { setNewPrice(String(app.price ?? "")); setNewUnit(app.price_unit || "total"); setQuoteOpen(true); }}>{t("updateQuote")}</button></div>)}
      {owner && app.status === "pending" && (
        <div className="btnrow pad"><button className="btn ghost" onClick={() => setStatus("declined")}>{t("decline")}</button>
          {!expired && <button className="btn" onClick={() => setStatus("accepted")}><Icon name="check" /> {t("accept")}</button>}</div>
      )}
      {app.status === "accepted" && (
        <div className="jobbox">
          {app.completed_at ? <p className="banner ok"><Icon name="check" size={16} /> {t("jobCompleted", { d: fmtDate(lang, app.completed_at.slice(0, 10)) })}</p>
            : owner && ended ? <button className="btn full" onClick={() => setDoneOpen(true)}><Icon name="check" /> {t("markDone")}</button>
            : owner ? <p className="mute xs center">{t("doneAfter", { d: endsText })}</p>
            : <p className="mute xs center">{t("doneByOwner", { name: otherName })}</p>}
          {!app.completed_at && !ended && <button className="btn ghost full" onClick={openCalendar}><Icon name="calendar" /> {t("addToCalendar")}</button>}
          {app.completed_at && (myReview
            ? <p className="mute xs center">{t("youRated", { n: myReview.stars })}</p>
            : <button className="ratebtn" onClick={() => setRateOpen(true)}><Icon name="star" fill size={16} /> {t("rate", { name: otherName })}</button>)}
          <div className="promise"><Icon name="shield" size={18} />
            <span className="grow"><b>{t("promiseTitle")}</b><br />{t("promiseBody")}
              {canReport && <><br /><button className="link danger" onClick={() => setProbOpen(true)}><Icon name="flag" size={14} /> {t("reportProblem")}</button></>}</span>
          </div>
          {!app.completed_at && !ended && <button className="link center block muted-link" onClick={() => setCancelOpen(true)}>{t("cancelJob")}</button>}
        </div>
      )}
      <div className="msgs" aria-live="polite">
        {msgs.map((m) => {
          const day = m.created_at.slice(0, 10);
          const sep = day !== lastDay ? (lastDay = day, <div key={"d" + m.id} className="daysep">{fmtDate(lang, day)}</div>) : null;
          const mine = m.sender_id === uid;
          return [sep, <div key={m.id} className={"bubble" + (mine ? " me" : "")}>{m.body}<span className="time">{new Date(m.created_at).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</span></div>];
        })}
        <div ref={endRef} />
      </div>
      {!owner && app.status === "pending" && <button className="link center block muted-link" onClick={() => setStatus("withdrawn")}>{t("withdraw")}</button>}
      {other && blocked.has(other.id) ? <p className="banner off">{t("youBlocked")}</p> : (
        <form className="composer" onSubmit={(e) => { e.preventDefault(); send(); }}>
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder={t("messagePh")} aria-label={t("messagePh")} enterKeyHint="send" maxLength={2000} />
          <button className="sendbtn" type="submit" disabled={!text.trim()} aria-label={t("send")}><Icon name="send" /></button>
        </form>
      )}

      <Sheet open={quoteOpen} onClose={() => setQuoteOpen(false)} title={t("updateQuote")}>
        <p className="mute">{t("updateQuoteHint")}</p>
        <div className="pricerow">
          <span className="pricebox"><b>£</b><input inputMode="decimal" value={newPrice} onChange={(e) => setNewPrice(e.target.value)} aria-label={t("yourPrice")} maxLength={9} autoFocus /></span>
          <div className="seg">{(["total", "hour"] as PriceUnit[]).map((u) => <button key={u} type="button" className={newUnit === u ? "on" : ""} onClick={() => setNewUnit(u)}>{t(u === "total" ? "priceTotal" : "priceHour")}</button>)}</div>
        </div>
        <button className="btn full" onClick={sendQuote}><Icon name="send" /> {t("send")}</button>
      </Sheet>
      <Sheet open={probOpen} onClose={() => setProbOpen(false)} title={t("reportProblem")}>
        <p className="mute">{t("problemHint")}</p>
        <textarea rows={4} value={problem} onChange={(e) => setProblem(e.target.value)} maxLength={480} autoFocus />
        <button className="btn full danger" disabled={problem.trim().length < 5} onClick={sendProblem}>{t("send")}</button>
      </Sheet>
      <Sheet open={cancelOpen} onClose={() => setCancelOpen(false)} title={t("cancelJob")}>
        <p className="mute">{t("cancelHint", { name: otherName })}</p>
        <textarea rows={3} value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} placeholder={t("cancelReasonPh")} maxLength={300} />
        <div className="btnrow">
          <button className="btn ghost" onClick={() => setCancelOpen(false)}>{t("keepJob")}</button>
          <button className="btn danger" disabled={busy || cancelReason.trim().length < 5} onClick={cancelJob}>{t("confirmCancel")}</button>
        </div>
      </Sheet>
      <Sheet open={calOpen} onClose={() => setCalOpen(false)} title={t("addToCalendar")}>
        <p className="mute">{t("calHint")}</p>
        <button className="btn full" onClick={downloadIcs}><Icon name="calendar" /> {t("calApple")}</button>
        <a className="btn ghost full" href={googleCalUrl(cal)} target="_blank" rel="noopener" onClick={() => setCalOpen(false)}>{t("calGoogle")}</a>
      </Sheet>
      <Sheet open={doneOpen} onClose={() => setDoneOpen(false)} title={t("markDone")}>
        <p>{t("confirmDoneQ")}</p>
        <div className="btnrow">
          <button className="btn ghost" onClick={() => setDoneOpen(false)}>{t("cancel")}</button>
          <button className="btn" disabled={busy} onClick={markDone}><Icon name="check" /> {t("confirmDone")}</button>
        </div>
      </Sheet>
      <Sheet open={rateOpen && !!app.completed_at && !myReview} onClose={() => setRateOpen(false)} title={t("rate", { name: otherName })}>
        <p className="mute">{t("rateHint")}</p>
        <div className="starpick" role="radiogroup">
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} role="radio" aria-checked={stars === n} aria-label={n + "★"} className={n <= stars ? "on" : ""} onClick={() => setStars(n)}><Icon name="star" size={34} fill={n <= stars} /></button>
          ))}
        </div>
        <textarea rows={3} value={comment} onChange={(e) => setComment(e.target.value)} placeholder={t("ratePh")} maxLength={500} />
        <button className="btn full" disabled={busy} onClick={submitReview}>{t("send")}</button>
      </Sheet>
    </div>
  );
}
