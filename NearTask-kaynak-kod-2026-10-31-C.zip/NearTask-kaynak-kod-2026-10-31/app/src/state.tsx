import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Api, Notice, Profile, Thread } from "./types";
import { enablePush, showLocal } from "./push";
import { HOME_CENTRE, SERVICE_RADIUS_KM, km, locate, type LatLng } from "./geo";
import { translate, type Key, type Lang } from "./i18n";
import { lsGet, lsSet } from "./util";

export type Route =
  | { name: "home" } | { name: "explore" } | { name: "post" } | { name: "edit"; id: string }
  | { name: "inbox" } | { name: "chat"; id: string } | { name: "me" } | { name: "listing"; id: string }
  | { name: "user"; id: string } | { name: "login"; next: string } | { name: "manage"; id: string } | { name: "saved" }
  | { name: "notices" } | { name: "dashboard" } | { name: "copy"; id: string } | { name: "recovery" }
  | { name: "admin" } | { name: "privacy" } | { name: "terms" } | { name: "blocked" }
  | { name: "services" } | { name: "service"; id: string } | { name: "newService" } | { name: "editService"; id: string };

export function parseRoute(hash: string): Route {
  const [path, query] = hash.replace(/^#/, "").split("?");
  const p = path.split("/").filter(Boolean);
  const id = decodeURIComponent(p[1] || "");
  switch (p[0]) {
    case "explore": return { name: "explore" };
    case "post": return { name: "post" };
    case "edit": return { name: "edit", id };
    case "inbox": return { name: "inbox" };
    case "chat": return { name: "chat", id };
    case "me": return { name: "me" };
    case "l": return { name: "listing", id };
    case "u": return { name: "user", id };
    case "manage": return { name: "manage", id };
    case "saved": return { name: "saved" };
    case "notices": return { name: "notices" };
    case "recovery": return { name: "recovery" };
    case "admin": return { name: "admin" };
    case "privacy": return { name: "privacy" };
    case "terms": return { name: "terms" };
    case "blocked": return { name: "blocked" };
    case "dashboard": return { name: "dashboard" };
    case "copy": return { name: "copy", id };
    case "services": return { name: "services" };
    case "s": return { name: "service", id };
    case "new-service": return { name: "newService" };
    case "edit-service": return { name: "editService", id };
    case "login": return { name: "login", next: new URLSearchParams(query || "").get("next") || "/" };
    default: return { name: "home" };
  }
}

export type Theme = "auto" | "light" | "dark";

interface Ctx {
  api: Api;
  uid: string | null;
  me: Profile | null;
  refreshMe(): Promise<void>;
  lang: Lang;
  theme: Theme;
  setTheme(t: Theme): void;
  t(key: Key, vars?: Record<string, string | number>): string;
  route: Route;
  go(path: string, replace?: boolean): void;
  back(fallback?: string): void;
  needAuth(): boolean;
  toast(msg: string): void;
  favs: Set<string>;
  toggleFav(id: string): Promise<void>;
  threads: Thread[];
  unread: number;
  isUnread(th: Thread): boolean;
  markSeen(appId: string): void;
  refreshThreads(): Promise<void>;
  notices: Notice[];
  unreadNotices: number;
  refreshNotices(): Promise<void>;
  markNoticesRead(): Promise<void>;
  near: LatLng | null;
  setNear(p: LatLng | null): void;
  blocked: Set<string>;
  refreshBlocked(): Promise<void>;
  isAdmin: boolean;
  onboarded: boolean;
  finishOnboarding(): void;
}

const C = createContext<Ctx>(null as any);
export const useApp = () => useContext(C);

export function AppProvider({ api, children }: { api: Api; children: ReactNode }) {
  const [uid, setUid] = useState<string | null>(null);
  const [me, setMe] = useState<Profile | null>(null);
  // The app is English-only.
  const lang: Lang = "en";
  const [theme, setThemeS] = useState<Theme>(() => lsGet<Theme>("nt_theme", "auto"));
  const [route, setRoute] = useState<Route>(() => parseRoute(location.hash));
  const [toastMsg, setToast] = useState("");
  const [favs, setFavs] = useState<Set<string>>(new Set());
  const [threads, setThreads] = useState<Thread[]>([]);
  const [seen, setSeen] = useState<Record<string, string>>(() => lsGet("nt_seen", {}));
  const [notices, setNotices] = useState<Notice[]>([]);
  const [nearOverride, setNear] = useState<LatLng | null>(null);
  const [blocked, setBlocked] = useState<Set<string>>(new Set());
  const [onboarded, setOnboarded] = useState<boolean>(() => lsGet("nt_onboarded", false));
  const finishOnboarding = useCallback(() => { setOnboarded(true); lsSet("nt_onboarded", true); }, []);
  const toastTimer = useRef<number>();
  const depth = useRef(0);

  const t = useCallback((k: Key, v?: Record<string, string | number>) => translate(lang, k, v), [lang]);
  const toast = useCallback((m: string) => {
    setToast(m);
    clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 2600);
  }, []);

  useEffect(() => {
    const on = () => { setRoute(parseRoute(location.hash)); window.scrollTo(0, 0); };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const go = useCallback((path: string, replace = false) => {
    const h = "#" + path;
    if (replace) { history.replaceState(null, "", h); setRoute(parseRoute(h)); window.scrollTo(0, 0); }
    else { depth.current++; location.hash = path; }
  }, []);
  const back = useCallback((fallback = "/") => {
    if (depth.current > 0) { depth.current--; history.back(); } else go(fallback, true);
  }, [go]);

  const refreshMe = useCallback(async () => {
    const u = await api.currentUser();
    setUid(u);
    let p = u ? await api.myProfile() : null;
    // Apply the name and account type chosen at sign-up (saved before the email was confirmed).
    const pending = lsGet<{ name: string; account_type: "person" | "business"; age_group?: "16-17" | "18+" } | null>("nt_pending_profile", null);
    if (u && p && pending && (!p.name || api.mode === "demo")) {
      try {
        await api.saveProfile({ name: pending.name, account_type: pending.account_type, postcode: p.postcode, bio: p.bio, avatar_url: p.avatar_url,
          headline: p.headline || "", skills: p.skills || [], available: !!p.available, available_days: p.available_days || [], lat: p.lat, lng: p.lng,
          age_group: pending.account_type === "business" ? "18+" : pending.age_group || null });
        p = await api.myProfile();
      } catch {}
    }
    if (u && pending) lsSet("nt_pending_profile", null);
    setMe(p);
    setFavs(new Set(u ? await api.favorites() : []));
    setBlocked(new Set(u ? await api.blockedIds().catch(() => []) : []));
  }, [api]);
  const refreshBlocked = useCallback(async () => { setBlocked(new Set(await api.blockedIds().catch(() => []))); }, [api]);
  const refreshThreads = useCallback(async () => { try { setThreads(await api.threads()); } catch {} }, [api]);

  useEffect(() => { refreshMe(); return api.onAuthChange(() => { refreshMe(); refreshThreads(); }); }, [api, refreshMe, refreshThreads]);
  // If notifications were allowed before push was set up, register this phone quietly once signed in.
  useEffect(() => {
    if (uid && api.mode === "live" && "Notification" in window && Notification.permission === "granted") enablePush(api).catch(() => {});
  }, [api, uid]);
  useEffect(() => api.onRecovery(() => go("/recovery", true)), [api, go]);
  // An email link that has expired or was already used comes back as #error=...&error_code=...
  useEffect(() => {
    const m = location.hash.match(/error_code=([a-z_]+)/);
    if (!m) return;
    toast(t(m[1] === "otp_expired" ? "linkExpired" : "linkFailed"));
    go("/login", true);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!uid) { setThreads([]); return; }
    refreshThreads();
    const off = api.subscribeAll(() => refreshThreads());
    const iv = window.setInterval(refreshThreads, 30000);
    return () => { off(); clearInterval(iv); };
  }, [api, uid, refreshThreads]);

  const refreshNotices = useCallback(async () => { try { setNotices(await api.notifications()); } catch {} }, [api]);
  const markNoticesRead = useCallback(async () => {
    await api.markAllRead().catch(() => {});
    setNotices((ns) => ns.map((n) => ({ ...n, read: true })));
  }, [api]);
  useEffect(() => {
    if (!uid) { setNotices([]); return; }
    refreshNotices();
    return api.onNotification((n) => {
      setNotices((ns) => [n, ...ns.filter((x) => x.id !== n.id)]);
      showLocal(n);
      if (!location.hash.startsWith("#/chat/") || n.type !== "message") toast("🔔 " + n.title);
    });
  }, [api, uid, refreshNotices, toast]);
  // Opening a chat or listing marks the notifications that point at it as read.
  useEffect(() => {
    const path = location.hash.replace(/^#/, "").split("?")[0];
    if (!uid || !notices.some((n) => !n.read && n.link === path)) return;
    api.markLinkRead(path).catch(() => {});
    setNotices((ns) => ns.map((n) => (n.link === path ? { ...n, read: true } : n)));
  }, [api, uid, route, notices]);
  const unreadNotices = notices.filter((n) => !n.read).length;
  const saved = me?.lat != null && me?.lng != null ? { lat: me.lat, lng: me.lng } : me?.postcode ? locate(me.postcode) : null;
  // A saved location far outside the service area would hide every listing, so it is ignored for "near".
  const near = nearOverride || (saved && km(saved, HOME_CENTRE) <= SERVICE_RADIUS_KM ? saved : null);

  const isUnread = useCallback((th: Thread) => !!th.last && th.last.sender_id !== uid && th.last.created_at > (seen[th.app.id] || ""), [seen, uid]);
  const unread = threads.filter(isUnread).length;
  const markSeen = useCallback((appId: string) => {
    setSeen((s) => { const n = { ...s, [appId]: new Date().toISOString() }; lsSet("nt_seen", n); return n; });
  }, []);

  const needAuth = useCallback(() => {
    if (uid) return false;
    go("/login?next=" + encodeURIComponent(location.hash.replace(/^#/, "") || "/"));
    return true;
  }, [uid, go]);

  const toggleFav = useCallback(async (id: string) => {
    if (needAuth()) return;
    const on = await api.toggleFavorite(id);
    setFavs((f) => { const n = new Set(f); on ? n.add(id) : n.delete(id); return n; });
    toast(on ? t("saved") : t("unsaved"));
  }, [api, needAuth, toast, t]);

  const setTheme = (x: Theme) => { setThemeS(x); lsSet("nt_theme", x); };
  useEffect(() => {
    document.documentElement.lang = lang;
    if (theme === "auto") document.documentElement.removeAttribute("data-theme");
    else document.documentElement.setAttribute("data-theme", theme);
  }, [lang, theme]);

  const value = useMemo<Ctx>(() => ({
    api, uid, me, refreshMe, lang, theme, setTheme, t, route, go, back, needAuth, toast, favs, toggleFav,
    threads, unread, isUnread, markSeen, refreshThreads, notices, unreadNotices, refreshNotices, markNoticesRead, near, setNear,
    blocked, refreshBlocked, isAdmin: !!me?.is_admin, onboarded, finishOnboarding,
  }), [blocked, refreshBlocked, onboarded, finishOnboarding, api, uid, me, refreshMe, lang, theme, t, route, go, back, needAuth, toast, favs, toggleFav, threads, unread, isUnread, markSeen, refreshThreads,
    notices, unreadNotices, refreshNotices, markNoticesRead, near]);

  return (
    <C.Provider value={value}>
      {children}
      <div className={"toast" + (toastMsg ? " on" : "")} role="status" aria-live="polite">{toastMsg}</div>
    </C.Provider>
  );
}
