import { useEffect, useState, type ReactNode } from "react";
import type { Category, Listing, Profile } from "./types";
import { useApp } from "./state";
import { fmtDate } from "./i18n";
import { availableToday, isUrgent, money, whenOf } from "./util";
import { fmtKm } from "./geo";
import { CAT_INFO, adultOnly } from "./categories";
import type { Key } from "./i18n";

const P: Record<string, string> = {
  home: "M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
  search: "M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zM20 20l-4.2-4.2",
  plus: "M12 5v14M5 12h14",
  chat: "M4 5h16v11H9l-5 4z",
  user: "M12 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8zM4 21c0-4 4-6 8-6s8 2 8 6",
  back: "M15 5l-7 7 7 7",
  heart: "M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z",
  share: "M12 3v12M7 8l5-5 5 5M5 14v6h14v-6",
  pin: "M12 21s-6-5.5-6-11a6 6 0 0 1 12 0c0 5.5-6 11-6 11zM12 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4z",
  clock: "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18zM12 7v5l3 2",
  cash: "M3 7h18v10H3zM12 9.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z",
  check: "M5 12l5 5 9-10",
  shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z",
  flag: "M5 21V4h11l-2 4 2 4H5",
  lock: "M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3",
  send: "M4 12l16-8-6 16-2-6z",
  edit: "M4 20h4L19 9l-4-4L4 16zM14 6l4 4",
  trash: "M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13",
  star: "M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.2L12 17.4 6.5 20.3l1-6.2L3 9.7l6.2-.9z",
  camera: "M4 8h3l2-3h6l2 3h3v11H4zM12 10.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z",
  x: "M6 6l12 12M18 6L6 18",
  bell: "M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 20a2 2 0 0 0 4 0",
  map: "M9 4L3 6v14l6-2 6 2 6-2V4l-6 2zM9 4v14M15 6v14",
  list: "M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01",
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  copy: "M8 8h12v12H8zM4 16V4h12",
  briefcase: "M3 8h18v12H3zM8 8V5h8v3M3 13h18",
  // categories
  hospitality: "M5 3v7a3 3 0 0 0 6 0V3M8 3v18M16 21V3c2.5 1 4 3.5 4 7h-4",
  cleaning: "M14 3l-4 9M6 12h10l2 9H4zM9 16v5M13 16v5",
  garden: "M12 21v-9M12 12C12 7 8 4 4 4c0 5 3 8 8 8zM12 14c0-4 3-7 8-7 0 4-3 7-8 7z",
  warehouse: "M3 9l9-5 9 5v12H3zM7 21v-8h10v8M7 17h10",
  moving: "M2 6h12v10H2zM14 10h4l3 3v3h-7M6 19a2 2 0 1 0 0-.1M17 19a2 2 0 1 0 0-.1",
  repairs: "M14.5 4a4.5 4.5 0 0 0-4.3 5.8L4 16v4h4l6.2-6.2A4.5 4.5 0 0 0 20 9.5l-3 1-3.5-3.5 1-3z",
  care: "M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10zM9 11h6M12 8v6",
  retail: "M5 8h14l-1 12H6zM9 8V6a3 3 0 0 1 6 0v2",
  family: "M12 12.5c-3 0-5 2.6-5 5 0 1.6 1.4 2.2 2.6 1.6.8-.4 1.6-.6 2.4-.6s1.6.2 2.4.6c1.2.6 2.6 0 2.6-1.6 0-2.4-2-5-5-5zM5.5 8a1.5 2 0 1 1 0 4 1.5 2 0 0 1 0-4zM18.5 8a1.5 2 0 1 1 0 4 1.5 2 0 0 1 0-4zM9.5 4a1.5 2 0 1 1 0 4 1.5 2 0 0 1 0-4zM14.5 4a1.5 2 0 1 1 0 4 1.5 2 0 0 1 0-4z",
  lessons: "M4 5h5a3 3 0 0 1 3 3v12a2 2 0 0 0-2-2H4zM20 5h-5a3 3 0 0 0-3 3v12a2 2 0 0 1 2-2h6z",
  beauty: "M6 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM6 15.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM8.2 7.6 20 17.5M8.2 16.4 20 6.5",
  events: "M9 18V5l11-2v13M6 15a3 3 0 1 1 0 6 3 3 0 0 1 0-6zM17 13a3 3 0 1 1 0 6 3 3 0 0 1 0-6z",
  tech: "M4 5h16v10H4zM2 19h20",
  auto: "M5 16v-5l2-5h10l2 5v5M3 16h18v3H3zM5 11h14M7.5 13.5h.01M16.5 13.5h.01",
  other: "M5 12h.01M12 12h.01M19 12h.01",
  image: "M4 5h16v14H4zM4 16l5-5 4 4 2-2 5 5M15.5 8.5h.01",
  calendar: "M4 6h16v14H4zM4 10h16M8 3v4M16 3v4",
  tag: "M3 12V4h8l10 10-8 8zM7.5 8h.01",
};

const catInfo = (c: string) => CAT_INFO[c as Category] || CAT_INFO.other;
export const CAT_COLOR = new Proxy({} as Record<Category, string>, { get: (_t, c: string) => catInfo(c).color });

export function Icon({ name, size = 20, fill = false }: { name: string; size?: number; fill?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={P[name] || P.other} />
    </svg>
  );
}

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="16" fill="var(--pri)" />
      <ellipse cx="32" cy="53" rx="14" ry="3.6" fill="none" stroke="var(--sig)" strokeWidth="2.6" />
      <path d="M32 9c-8.8 0-15.8 6.9-15.8 15.5 0 10.8 12.4 20.3 14.8 22.1a1.5 1.5 0 0 0 2 0c2.4-1.8 14.8-11.3 14.8-22.1C47.8 15.9 40.8 9 32 9z" fill="#fff" />
      <path d="M24.5 24.5l5.4 5.4 10.4-10.4" fill="none" stroke="var(--pri)" strokeWidth="4.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const HUES = ["#0E7C7B", "#7A5AF8", "#E2683C", "#2F80ED", "#C2417A", "#3E8E41", "#B7791F"];
export function Avatar({ p, size = 40 }: { p?: Profile | null; size?: number }) {
  const name = (p?.name || "?").replace(/\(sample\)/i, "").trim();
  const initials = name.split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "?";
  const hue = HUES[[...(p?.id || "x")].reduce((s, c) => s + c.charCodeAt(0), 0) % HUES.length];
  if (p?.avatar_url) return <img className="avatar" src={p.avatar_url} alt="" style={{ width: size, height: size }} />;
  return <span className="avatar" style={{ width: size, height: size, background: hue, fontSize: size * 0.38 }} aria-hidden="true">{initials}</span>;
}

export function Stars({ value, count, small }: { value: number; count?: number; small?: boolean }) {
  const { t } = useApp();
  if (count === 0) return <span className="mute xs">{t("noReviews")}</span>;
  return (
    <span className={"stars" + (small ? " xs" : "")}>
      <Icon name="star" size={small ? 13 : 15} fill />
      <b>{value.toFixed(1)}</b>
      {count !== undefined && <span className="mute">({count})</span>}
    </span>
  );
}

export function CatBadge({ c, size = 44 }: { c: Category; size?: number }) {
  const i = catInfo(c);
  return <span className="catb" style={{ width: size, height: size, background: i.tint, color: i.color }}><Icon name={P[c] ? c : "other"} size={size * 0.48} /></span>;
}

export function CatTag({ c }: { c: string }) {
  const { t } = useApp();
  const i = catInfo(c);
  return <span className="tag" style={{ background: i.tint, color: i.color }}>{t(("cat." + (CAT_INFO[c as Category] ? c : "other")) as Key)}</span>;
}

export function WhenTag({ date }: { date: string }) {
  const { t, lang } = useApp();
  const w = whenOf(date);
  const label = w === "today" ? t("today") : w === "tomorrow" ? t("tomorrow") : w === "past" ? t("past") : fmtDate(lang, date);
  return <span className={"tag" + (w === "today" ? " now" : w === "past" ? " off" : "")}>{label}</span>;
}

export function timeRange(l: Listing, flexible: string) {
  return l.start_time ? l.start_time.slice(0, 5) + (l.end_time ? "–" + l.end_time.slice(0, 5) : "") : flexible;
}

export function ListingCard({ l, compact }: { l: Listing; compact?: boolean }) {
  const { t, go, favs, toggleFav, uid } = useApp();
  const fav = favs.has(l.id);
  return (
    <article className={"lcard" + (compact ? " compact" : "")} onClick={() => go("/l/" + l.id)}>
      {l.photo_url && !compact ? <img className="lphoto" src={l.photo_url} alt="" /> : <CatBadge c={l.category} />}
      <div className="lbody">
        <div className="lrow">
          <h3>{l.title}</h3>
          {l.owner_id !== uid && <button className={"fav" + (fav ? " on" : "")} aria-label={t("save")} aria-pressed={fav}
            onClick={(e) => { e.stopPropagation(); toggleFav(l.id); }}>
            <Icon name="heart" size={19} fill={fav} />
          </button>}
        </div>
        <div className="lowner">
          <span className="ellip">{l.owner?.name}</span>
          {l.owner?.verified && <span className="vtick" title={t("verified")}><Icon name="check" size={11} /></span>}
          {l.owner && l.owner.rating_count > 0 && <Stars small value={l.owner.rating_avg} />}
        </div>
        <div className="lmeta">
          {isUrgent(l) && <span className="tag urgent"><Icon name="clock" size={12} /> {t("urgent")}</span>}
          <WhenTag date={l.date} />
          <span className="tag ghost">{timeRange(l, t("timeAny"))}</span>
          <span className="tag ghost ellip">{l.area}{l.distance !== undefined ? " · " + fmtKm(l.distance) : ""}</span>
          {adultOnly(l) && <span className="tag ghost">18+</span>}
          <span className="lpay">{money(l.pay)}</span>
        </div>
        {l.status !== "open" && <span className="tag off" style={{ marginTop: 8 }}>{l.status === "filled" ? t("filled") : t("closed")}</span>}
      </div>
    </article>
  );
}

export function TopBar({ title, backTo, right }: { title?: string; backTo?: string; right?: ReactNode }) {
  const { back, t } = useApp();
  return (
    <header className="topbar">
      {backTo !== undefined && (
        <button className="iconbtn" onClick={() => back(backTo)} aria-label={t("back")}><Icon name="back" size={22} /></button>
      )}
      <h1 className="tb-title ellip">{title}</h1>
      <div className="tb-right">{right}</div>
    </header>
  );
}

export function Sheet({ open, onClose, children, title }: { open: boolean; onClose(): void; children: ReactNode; title: string }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="scrim" onClick={onClose}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="grab" />
        <h2>{title}</h2>
        {children}
      </div>
    </div>
  );
}

export function Empty({ icon, text, action }: { icon: string; text: string; action?: ReactNode }) {
  return (
    <div className="empty">
      <span className="empty-ic"><Icon name={icon} size={26} /></span>
      <p>{text}</p>
      {action}
    </div>
  );
}

export function Loading() {
  const { t } = useApp();
  return <div className="loading" aria-label={t("loading")}><span /><span /><span /></div>;
}

/** Load async data with a key; re-runs when deps change. */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]): [T | undefined, () => void, boolean] {
  const [v, setV] = useState<T>();
  const [n, setN] = useState(0);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let live = true;
    setErr(false);
    fn().then((x) => live && setV(x)).catch(() => live && setErr(true));
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, n]);
  return [v, () => setN((x) => x + 1), err];
}
