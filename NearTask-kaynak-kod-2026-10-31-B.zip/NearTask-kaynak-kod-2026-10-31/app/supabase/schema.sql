-- NearTask database schema
-- Run once in Supabase: SQL Editor > New query > paste everything > Run.
-- Safe to re-run: it drops nothing that holds data, and uses IF NOT EXISTS where it can.

create extension if not exists pgcrypto;

-- ---------- Profiles ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '' check (char_length(name) <= 60),
  postcode text not null default '' check (char_length(postcode) <= 10),
  bio text not null default '' check (char_length(bio) <= 500),
  avatar_url text,
  rating_avg numeric(3,2) not null default 0,
  rating_count int not null default 0,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

-- Create a profile automatically for every new account.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Listings ----------
create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  kind text not null check (kind in ('job','service')),
  title text not null check (char_length(title) between 3 and 80),
  category text not null check (category in ('hospitality','cleaning','garden','warehouse','moving','repairs','care','other')),
  area text not null check (char_length(area) between 2 and 40),
  date date not null,
  start_time time,
  end_time time,
  pay text not null check (char_length(pay) between 1 and 30),
  description text not null default '' check (char_length(description) <= 1500),
  requirements text not null default '' check (char_length(requirements) <= 500),
  photo_url text,
  status text not null default 'open' check (status in ('open','filled','closed')),
  created_at timestamptz not null default now()
);
create index if not exists listings_open_date on public.listings (status, date);
create index if not exists listings_owner on public.listings (owner_id);

-- Exact address: only the owner and an accepted applicant can read it.
create table if not exists public.listing_private (
  listing_id uuid primary key references public.listings(id) on delete cascade,
  address text not null default '' check (char_length(address) <= 200)
);

-- ---------- Applications / offers ----------
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  applicant_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  message text not null default '' check (char_length(message) <= 1000),
  status text not null default 'pending' check (status in ('pending','accepted','declined','withdrawn')),
  created_at timestamptz not null default now(),
  unique (listing_id, applicant_id)
);
create index if not exists applications_applicant on public.applications (applicant_id);

-- ---------- Messages ----------
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists messages_app on public.messages (application_id, created_at);

-- ---------- Favourites, reviews, reports ----------
create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  reviewer_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  reviewee_id uuid not null references public.profiles(id) on delete cascade,
  stars int not null check (stars between 1 and 5),
  comment text not null default '' check (char_length(comment) <= 500),
  created_at timestamptz not null default now(),
  unique (application_id, reviewer_id)
);
create index if not exists reviews_reviewee on public.reviews (reviewee_id);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  reporter_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  reason text not null check (char_length(reason) between 1 and 500),
  created_at timestamptz not null default now()
);

-- ---------- Helper functions ----------
create or replace function public.is_listing_owner(l uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from listings where id = l and owner_id = auth.uid())
$$;

create or replace function public.is_participant(a uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from applications ap join listings li on li.id = ap.listing_id
    where ap.id = a and (ap.applicant_id = auth.uid() or li.owner_id = auth.uid())
  )
$$;

-- Applicant can withdraw; owner can accept or decline. Nothing else changes.
create or replace function public.check_application_update() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid;
begin
  if auth.uid() is null then return new; end if; -- dashboard / admin edits
  select owner_id into owner from listings where id = old.listing_id;
  if new.listing_id <> old.listing_id or new.applicant_id <> old.applicant_id or new.message <> old.message then
    raise exception 'Only the status can change';
  end if;
  if auth.uid() = old.applicant_id and new.status = 'withdrawn' then return new; end if;
  if auth.uid() = owner and new.status in ('accepted','declined','pending') then return new; end if;
  raise exception 'Not allowed';
end $$;
drop trigger if exists application_update_guard on public.applications;
create trigger application_update_guard before update on public.applications
  for each row execute function public.check_application_update();

-- Reviews only between the two people of an accepted application.
create or replace function public.check_review() returns trigger
language plpgsql security definer set search_path = public as $$
declare ap record;
begin
  select a.applicant_id, a.status, l.owner_id into ap
  from applications a join listings l on l.id = a.listing_id where a.id = new.application_id;
  if ap is null or ap.status <> 'accepted' then raise exception 'Application not accepted'; end if;
  if not ((new.reviewer_id = ap.applicant_id and new.reviewee_id = ap.owner_id)
       or (new.reviewer_id = ap.owner_id and new.reviewee_id = ap.applicant_id)) then
    raise exception 'Not a participant';
  end if;
  return new;
end $$;
drop trigger if exists review_guard on public.reviews;
create trigger review_guard before insert on public.reviews
  for each row execute function public.check_review();

-- Keep each profile's average rating up to date.
create or replace function public.refresh_rating() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update profiles p set
    rating_avg = coalesce((select round(avg(stars)::numeric, 2) from reviews where reviewee_id = new.reviewee_id), 0),
    rating_count = (select count(*) from reviews where reviewee_id = new.reviewee_id)
  where p.id = new.reviewee_id;
  return new;
end $$;
drop trigger if exists review_rating on public.reviews;
create trigger review_rating after insert on public.reviews
  for each row execute function public.refresh_rating();

-- ---------- Row level security ----------
alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_private enable row level security;
alter table public.applications enable row level security;
alter table public.messages enable row level security;
alter table public.favorites enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;

drop policy if exists "profiles read" on public.profiles;
create policy "profiles read" on public.profiles for select using (true);
drop policy if exists "profiles update own" on public.profiles;
create policy "profiles update own" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
-- Users may only edit these columns (not rating or verified).
revoke update on public.profiles from authenticated, anon;
grant update (name, postcode, bio, avatar_url) on public.profiles to authenticated;

drop policy if exists "listings read" on public.listings;
create policy "listings read" on public.listings for select using (status <> 'closed' or owner_id = auth.uid());
drop policy if exists "listings insert" on public.listings;
create policy "listings insert" on public.listings for insert with check (owner_id = auth.uid());
drop policy if exists "listings update" on public.listings;
create policy "listings update" on public.listings for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "listings delete" on public.listings;
create policy "listings delete" on public.listings for delete using (owner_id = auth.uid());

drop policy if exists "address read" on public.listing_private;
create policy "address read" on public.listing_private for select using (
  public.is_listing_owner(listing_id) or exists (
    select 1 from public.applications a where a.listing_id = listing_private.listing_id
      and a.applicant_id = auth.uid() and a.status = 'accepted'));
drop policy if exists "address write" on public.listing_private;
create policy "address write" on public.listing_private for all
  using (public.is_listing_owner(listing_id)) with check (public.is_listing_owner(listing_id));

drop policy if exists "applications read" on public.applications;
create policy "applications read" on public.applications for select using (applicant_id = auth.uid() or public.is_listing_owner(listing_id));
drop policy if exists "applications insert" on public.applications;
create policy "applications insert" on public.applications for insert with check (
  applicant_id = auth.uid() and not public.is_listing_owner(listing_id)
  and exists (select 1 from public.listings l where l.id = listing_id and l.status = 'open'));
drop policy if exists "applications update" on public.applications;
create policy "applications update" on public.applications for update using (applicant_id = auth.uid() or public.is_listing_owner(listing_id));

drop policy if exists "messages read" on public.messages;
create policy "messages read" on public.messages for select using (public.is_participant(application_id));
drop policy if exists "messages insert" on public.messages;
create policy "messages insert" on public.messages for insert with check (sender_id = auth.uid() and public.is_participant(application_id));

drop policy if exists "favorites own" on public.favorites;
create policy "favorites own" on public.favorites for all using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "reviews read" on public.reviews;
create policy "reviews read" on public.reviews for select using (true);
drop policy if exists "reviews insert" on public.reviews;
create policy "reviews insert" on public.reviews for insert with check (reviewer_id = auth.uid());

drop policy if exists "reports insert" on public.reports;
create policy "reports insert" on public.reports for insert with check (reporter_id = auth.uid());
-- Reports have no read policy: review them in the Supabase dashboard (Table Editor > reports).

-- ---------- Live updates (chat and application status) ----------
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.applications;
exception when duplicate_object then null; end $$;

-- ---------- Photo storage ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('photos', 'photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "photos read" on storage.objects;
create policy "photos read" on storage.objects for select using (bucket_id = 'photos');
drop policy if exists "photos upload own folder" on storage.objects;
create policy "photos upload own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "photos delete own" on storage.objects;
create policy "photos delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- =====================================================================
-- v2: worker profiles, invites, positions, views, map, notifications,
--     saved-search alerts, push subscriptions, public stats
-- (Safe to re-run. If you already ran an earlier version, just run this whole file again.)
-- =====================================================================

alter table public.profiles add column if not exists account_type text not null default 'person';
alter table public.profiles add column if not exists headline text not null default '';
alter table public.profiles add column if not exists skills text[] not null default '{}';
alter table public.profiles add column if not exists available boolean not null default false;
alter table public.profiles add column if not exists available_days text[] not null default '{}';
alter table public.profiles add column if not exists lat double precision;
alter table public.profiles add column if not exists lng double precision;
do $$ begin
  alter table public.profiles add constraint profiles_account_type check (account_type in ('person','business'));
exception when duplicate_object then null; end $$;
grant update (name, postcode, bio, avatar_url, account_type, headline, skills, available, available_days, lat, lng) on public.profiles to authenticated;
create index if not exists profiles_available on public.profiles (available) where available;

alter table public.listings add column if not exists positions int not null default 1;
alter table public.listings add column if not exists views int not null default 0;
alter table public.listings add column if not exists lat double precision;
alter table public.listings add column if not exists lng double precision;
do $$ begin
  alter table public.listings add constraint listings_positions check (positions between 1 and 50);
exception when duplicate_object then null; end $$;
-- Owners cannot fake their view count.
revoke update on public.listings from authenticated, anon;
grant update (kind, title, category, area, date, start_time, end_time, pay, description, requirements, photo_url, status, positions, lat, lng) on public.listings to authenticated;

create or replace function public.view_listing(l uuid) returns void
language sql security definer set search_path = public as $$
  update listings set views = views + 1 where id = l and owner_id is distinct from auth.uid()
$$;
grant execute on function public.view_listing(uuid) to anon, authenticated;

-- Invitations: an owner can invite a worker; the worker accepts or declines.
alter table public.applications drop constraint if exists applications_status_check;
alter table public.applications add constraint applications_status_check check (status in ('pending','accepted','declined','withdrawn','invited'));

drop policy if exists "applications insert" on public.applications;
create policy "applications insert" on public.applications for insert with check (
  exists (select 1 from public.listings l where l.id = listing_id and l.status = 'open') and (
    (applicant_id = auth.uid() and status = 'pending' and not public.is_listing_owner(listing_id))
    or (status = 'invited' and public.is_listing_owner(listing_id) and applicant_id <> auth.uid())
  ));

create or replace function public.check_application_update() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid;
begin
  if auth.uid() is null then return new; end if; -- dashboard / admin edits
  select owner_id into owner from listings where id = old.listing_id;
  if new.listing_id <> old.listing_id or new.applicant_id <> old.applicant_id or new.message <> old.message then
    raise exception 'Only the status can change';
  end if;
  if auth.uid() = old.applicant_id then
    if old.status = 'invited' and new.status in ('accepted','declined') then return new; end if;
    if old.status in ('pending','declined','withdrawn') and new.status in ('withdrawn','pending') then return new; end if;
  end if;
  if auth.uid() = owner and old.status <> 'invited' and new.status in ('accepted','declined','pending') then return new; end if;
  if auth.uid() = owner and old.status = 'invited' and new.status = 'withdrawn' then return new; end if;
  raise exception 'Not allowed';
end $$;

-- When enough people are accepted, mark the listing as filled.
create or replace function public.auto_fill() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'accepted' then
    update listings l set status = 'filled'
    where l.id = new.listing_id and l.status = 'open'
      and (select count(*) from applications a where a.listing_id = l.id and a.status = 'accepted') >= l.positions;
  end if;
  return new;
end $$;
drop trigger if exists application_auto_fill on public.applications;
create trigger application_auto_fill after insert or update of status on public.applications
  for each row execute function public.auto_fill();

-- ---------- Notifications ----------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text not null default '',
  link text not null default '/',
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user on public.notifications (user_id, created_at desc);
alter table public.notifications enable row level security;
drop policy if exists "notifications own read" on public.notifications;
create policy "notifications own read" on public.notifications for select using (user_id = auth.uid());
drop policy if exists "notifications own update" on public.notifications;
create policy "notifications own update" on public.notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke update on public.notifications from authenticated, anon;
grant update (read) on public.notifications to authenticated;

create or replace function public.notify(u uuid, ty text, ti text, bo text, li text) returns void
language sql security definer set search_path = public as $$
  insert into notifications (user_id, type, title, body, link) select u, ty, ti, left(coalesce(bo, ''), 140), li where u is not null
$$;
revoke execute on function public.notify(uuid, text, text, text, text) from public, anon, authenticated;

create or replace function public.on_message_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare ap record; who text;
begin
  select a.applicant_id, l.owner_id, l.title into ap from applications a join listings l on l.id = a.listing_id where a.id = new.application_id;
  select name into who from profiles where id = new.sender_id;
  perform notify(case when new.sender_id = ap.applicant_id then ap.owner_id else ap.applicant_id end,
    'message', coalesce(nullif(who, ''), 'New message') || ' - ' || ap.title, new.body, '/chat/' || new.application_id);
  return new;
end $$;
drop trigger if exists message_notify on public.messages;
create trigger message_notify after insert on public.messages for each row execute function public.on_message_notify();

create or replace function public.on_application_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare l record; who text;
begin
  select owner_id, title into l from listings where id = new.listing_id;
  if tg_op = 'INSERT' then
    if new.status = 'invited' then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'invite', coalesce(nullif(who, ''), 'Someone') || ' invited you', l.title, '/chat/' || new.id);
    else
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, 'application', 'New applicant: ' || coalesce(nullif(who, ''), 'someone'), l.title, '/manage/' || new.listing_id);
    end if;
  elsif new.status <> old.status then
    if new.status in ('accepted','declined') and old.status = 'pending' then
      perform notify(new.applicant_id, new.status, initcap(new.status) || ': ' || l.title, '', '/chat/' || new.id);
    elsif old.status = 'invited' and new.status in ('accepted','declined') then
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, new.status, coalesce(nullif(who, ''), 'Worker') || ' ' || new.status || ' your invite', l.title, '/chat/' || new.id);
    end if;
  end if;
  return new;
end $$;
drop trigger if exists application_notify on public.applications;
create trigger application_notify after insert or update of status on public.applications
  for each row execute function public.on_application_notify();

create or replace function public.on_review_notify() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform notify(new.reviewee_id, 'review', 'New review: ' || new.stars || ' stars', new.comment, '/u/' || new.reviewee_id);
  return new;
end $$;
drop trigger if exists review_notify on public.reviews;
create trigger review_notify after insert on public.reviews for each row execute function public.on_review_notify();

-- ---------- Saved-search alerts ----------
create table if not exists public.saved_searches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  label text not null default '' check (char_length(label) <= 80),
  kind text not null default 'all',
  category text not null default 'all',
  q text not null default '' check (char_length(q) <= 60),
  created_at timestamptz not null default now()
);
alter table public.saved_searches enable row level security;
drop policy if exists "saved searches own" on public.saved_searches;
create policy "saved searches own" on public.saved_searches for all using (user_id = auth.uid()) with check (user_id = auth.uid());

create or replace function public.on_listing_alert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into notifications (user_id, type, title, body, link)
  select distinct s.user_id, 'alert', 'New match: ' || new.title, new.area || ' - ' || new.pay, '/l/' || new.id
  from saved_searches s
  where s.user_id <> new.owner_id
    and (s.kind = 'all' or s.kind = new.kind)
    and (s.category = 'all' or s.category = new.category)
    and (s.q = '' or (new.title || ' ' || new.area || ' ' || new.description) ilike '%' || s.q || '%');
  return new;
end $$;
drop trigger if exists listing_alert on public.listings;
create trigger listing_alert after insert on public.listings for each row execute function public.on_listing_alert();

-- ---------- Web push subscriptions (phone notifications when the app is closed) ----------
create table if not exists public.push_subscriptions (
  endpoint text primary key,
  user_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  subscription jsonb not null,
  created_at timestamptz not null default now()
);
alter table public.push_subscriptions enable row level security;
drop policy if exists "push own" on public.push_subscriptions;
create policy "push own" on public.push_subscriptions for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------- Public counters for the home screen ----------
create or replace function public.public_stats() returns json
language sql stable security definer set search_path = public as $$
  select json_build_object(
    'seekers', (select count(*) from profiles where available and account_type = 'person'),
    'businesses', (select count(*) from profiles where account_type = 'business'),
    'listings', (select count(*) from listings where status = 'open' and date >= current_date))
$$;
grant execute on function public.public_stats() to anon, authenticated;

do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null; end $$;
-- ==== PART 1: admin + ban flags, blocks ====
alter table public.profiles add column if not exists is_admin boolean not null default false;
alter table public.profiles add column if not exists banned boolean not null default false;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from profiles where id = auth.uid()), false)
$$;

create or replace function public.is_banned() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select banned from profiles where id = auth.uid()), false)
$$;

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);
alter table public.blocks enable row level security;
drop policy if exists "blocks own" on public.blocks;
create policy "blocks own" on public.blocks for all using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

create or replace function public.blocked_between(a uuid, b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from blocks where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a))
$$;

-- ==== PART 2: stricter insert rules (banned users and blocked pairs) ====
drop policy if exists "listings insert" on public.listings;
create policy "listings insert" on public.listings for insert with check (owner_id = auth.uid() and not public.is_banned());

drop policy if exists "applications insert" on public.applications;
create policy "applications insert" on public.applications for insert with check (
  not public.is_banned()
  and exists (select 1 from public.listings l where l.id = listing_id and l.status = 'open'
    and not public.blocked_between(l.owner_id, applicant_id)) and (
    (applicant_id = auth.uid() and status = 'pending' and not public.is_listing_owner(listing_id))
    or (status = 'invited' and public.is_listing_owner(listing_id) and applicant_id <> auth.uid())
  ));

create or replace function public.can_message(a uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from applications ap join listings li on li.id = ap.listing_id
    where ap.id = a and (ap.applicant_id = auth.uid() or li.owner_id = auth.uid())
      and not blocked_between(ap.applicant_id, li.owner_id)
  ) and not is_banned()
$$;

drop policy if exists "messages insert" on public.messages;
create policy "messages insert" on public.messages for insert with check (sender_id = auth.uid() and public.can_message(application_id));

-- ==== PART 3: report users, delete own account ====
alter table public.reports alter column listing_id drop not null;
alter table public.reports add column if not exists reported_user_id uuid references public.profiles(id) on delete cascade;
alter table public.reports add column if not exists status text not null default 'open';
do $$ begin
  alter table public.reports add constraint reports_target check (listing_id is not null or reported_user_id is not null);
exception when duplicate_object then null; end $$;

create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from storage.objects where bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text;
  delete from auth.users where id = auth.uid();
end $$;
revoke execute on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- ==== PART 4: admin tools ====
create or replace function public.admin_overview() returns json
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return json_build_object(
    'users', (select count(*) from profiles),
    'businesses', (select count(*) from profiles where account_type = 'business'),
    'seekers', (select count(*) from profiles where available and account_type = 'person'),
    'open_listings', (select count(*) from listings where status = 'open' and date >= current_date),
    'applications', (select count(*) from applications),
    'messages_7d', (select count(*) from messages where created_at > now() - interval '7 days'),
    'new_users_7d', (select count(*) from profiles where created_at > now() - interval '7 days'),
    'open_reports', (select count(*) from reports where status = 'open'));
end $$;

create or replace function public.admin_reports() returns json
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return coalesce((select json_agg(r order by r.created_at desc) from (
    select rp.id, rp.reason, rp.status, rp.created_at, rp.listing_id, rp.reported_user_id,
      l.title as listing_title, l.status as listing_status, l.owner_id as listing_owner,
      rr.name as reporter_name, ru.name as reported_name, ru.banned as reported_banned
    from reports rp
    left join listings l on l.id = rp.listing_id
    left join profiles rr on rr.id = rp.reporter_id
    left join profiles ru on ru.id = coalesce(rp.reported_user_id, l.owner_id)
    order by rp.created_at desc limit 200) r), '[]'::json);
end $$;

-- ==== PART 5: admin actions ====
create or replace function public.admin_resolve_report(r uuid, s text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  update reports set status = s where id = r;
end $$;

create or replace function public.admin_set_listing_status(l uuid, s text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  update listings set status = s where id = l;
end $$;

create or replace function public.admin_set_verified(u uuid, v boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  update profiles set verified = v where id = u;
end $$;

create or replace function public.admin_set_banned(u uuid, v boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if u = auth.uid() then raise exception 'Cannot ban yourself'; end if;
  update profiles set banned = v where id = u;
  if v then update listings set status = 'closed' where owner_id = u and status = 'open'; end if;
end $$;

-- ==== PART 6: make the owner an admin (change the email if needed) ====
update public.profiles set is_admin = true
where id = (select id from auth.users where email = 'alitekincelik@gmail.com');

-- =====================================================================
-- v4: broader categories, smart request details, priced quotes,
--     stronger provider profiles (work photos + track record)
-- Safe to re-run. Run once in Supabase → SQL Editor → New query → Run.
-- =====================================================================

-- 1. Broad main categories
alter table public.listings drop constraint if exists listings_category_check;
alter table public.listings add constraint listings_category_check check (category in (
  'hospitality','retail','warehouse','cleaning','repairs','garden','moving','care',
  'family','lessons','beauty','events','tech','auto','other'));

-- 2. Smart request answers (e.g. {"type": "Deep clean", "size": "2 bedrooms"})
alter table public.listings add column if not exists details jsonb not null default '{}'::jsonb;
do $$ begin
  alter table public.listings add constraint listings_details_shape check (jsonb_typeof(details) = 'object' and length(details::text) <= 2000);
exception when duplicate_object then null; end $$;
grant update (kind, title, category, area, date, start_time, end_time, pay, description, requirements, photo_url, status, positions, lat, lng, details)
  on public.listings to authenticated;

-- 3. Priced quotes on applications / offers
alter table public.applications add column if not exists price numeric(10,2);
alter table public.applications add column if not exists price_unit text;
do $$ begin
  alter table public.applications add constraint applications_price check (price is null or (price >= 1 and price < 100000));
exception when duplicate_object then null; end $$;
alter table public.applications drop constraint if exists applications_price_unit;
alter table public.applications add constraint applications_price_unit check (
  (price is null and price_unit is null) or (price is not null and price_unit is not null and price_unit in ('total','hour')));

-- Only the status can change, except that the applicant may set a new price when (re)applying.
create or replace function public.check_application_update() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid;
begin
  if auth.uid() is null then return new; end if; -- dashboard / admin edits
  select owner_id into owner from listings where id = old.listing_id;
  if new.listing_id <> old.listing_id or new.applicant_id <> old.applicant_id or new.message <> old.message then
    raise exception 'Only the status can change';
  end if;
  if (new.price is distinct from old.price or new.price_unit is distinct from old.price_unit)
     and not (auth.uid() = old.applicant_id and new.status = 'pending') then
    raise exception 'Only the applicant can change their quote';
  end if;
  if auth.uid() = old.applicant_id then
    if old.status = 'invited' and new.status in ('accepted','declined') then return new; end if;
    if old.status in ('pending','declined','withdrawn') and new.status in ('withdrawn','pending') then return new; end if;
  end if;
  if auth.uid() = owner and old.status <> 'invited' and new.status in ('accepted','declined','pending') then return new; end if;
  if auth.uid() = owner and old.status = 'invited' and new.status = 'withdrawn' then return new; end if;
  raise exception 'Not allowed';
end $$;

-- Notifications mention the quoted price.
create or replace function public.on_application_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare l record; who text; q text;
begin
  select owner_id, title into l from listings where id = new.listing_id;
  q := case when new.price is null then ''
            else ' · £' || trim(to_char(new.price, 'FM99999.00')) || case when new.price_unit = 'hour' then '/hr' else '' end end;
  q := replace(q, '.00', '');
  if tg_op = 'INSERT' then
    if new.status = 'invited' then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'invite', coalesce(nullif(who, ''), 'Someone') || ' invited you', l.title, '/chat/' || new.id);
    else
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, 'application',
        case when new.price is null then 'New applicant: ' else 'New quote: ' end || coalesce(nullif(who, ''), 'someone') || q,
        l.title, '/manage/' || new.listing_id);
    end if;
  elsif new.status <> old.status then
    if new.status in ('accepted','declined') and old.status = 'pending' then
      perform notify(new.applicant_id, new.status, initcap(new.status) || ': ' || l.title, '', '/chat/' || new.id);
    elsif old.status = 'invited' and new.status in ('accepted','declined') then
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, new.status, coalesce(nullif(who, ''), 'Worker') || ' ' || new.status || ' your invite', l.title, '/chat/' || new.id);
    end if;
  end if;
  return new;
end $$;

-- 4. Provider profiles: work photos and a public track record
alter table public.profiles add column if not exists portfolio text[] not null default '{}';
do $$ begin
  alter table public.profiles add constraint profiles_portfolio_max check (cardinality(portfolio) <= 8);
exception when duplicate_object then null; end $$;
grant update (name, postcode, bio, avatar_url, account_type, headline, skills, available, available_days, lat, lng, portfolio)
  on public.profiles to authenticated;

-- Jobs done, people hired and median reply time (minutes) over the last 120 days.
-- Returns totals only, never individual jobs or messages.
create or replace function public.profile_stats(u uuid) returns json
language sql stable security definer set search_path = public as $$
  with mine as (
    select a.id from applications a join listings l on l.id = a.listing_id
    where a.applicant_id = u or l.owner_id = u
  ), m as (
    select x.sender_id, x.created_at,
      lag(x.sender_id) over (partition by x.application_id order by x.created_at) as prev_sender,
      lag(x.created_at) over (partition by x.application_id order by x.created_at) as prev_at
    from messages x
    where x.application_id in (select id from mine) and x.created_at > now() - interval '120 days'
  )
  select json_build_object(
    'jobs_done', (select count(*) from applications a join listings l on l.id = a.listing_id
                  where a.applicant_id = u and a.status = 'accepted' and l.date <= current_date),
    'hires', (select count(*) from applications a join listings l on l.id = a.listing_id
              where l.owner_id = u and a.status = 'accepted'),
    'reply_minutes', (select round(percentile_cont(0.5) within group (order by extract(epoch from (m.created_at - m.prev_at)) / 60))::int
                      from m where m.sender_id = u and m.prev_sender is not null and m.prev_sender <> u))
$$;
grant execute on function public.profile_stats(uuid) to anon, authenticated;

-- =====================================================================
-- v5: automatic matching, price guide, job completion + NearTask Promise,
--     fixed-price services (packages)
-- Needs v4 first. Safe to re-run. Supabase → SQL Editor → New query → Run.
-- =====================================================================

-- ---------- 1. Automatic matching ----------
-- New requests are sent straight to nearby helpers who picked that category under "What I do".
alter table public.profiles add column if not exists match_alerts boolean not null default true;
grant update (name, postcode, bio, avatar_url, account_type, headline, skills, available, available_days, lat, lng, portfolio, match_alerts)
  on public.profiles to authenticated;

alter table public.listings add column if not exists notified int not null default 0;     -- how many helpers were told
alter table public.listings add column if not exists booked_package uuid;                  -- set when created by booking a package

create or replace function public.km_between(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision)
returns double precision language sql immutable as $$
  select 6371 * 2 * asin(sqrt(power(sin(radians(lat2 - lat1) / 2), 2)
    + cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)))
$$;

create or replace function public.on_listing_match() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if new.status <> 'open' or new.booked_package is not null then return new; end if;
  with helpers as (
    select p.id from profiles p
    where p.id <> new.owner_id
      and p.match_alerts and not p.banned
      and new.category = any (p.skills)
      and (new.kind = 'service' or p.available)                -- shifts go to people looking for work
      and not blocked_between(p.id, new.owner_id)
      and (
        (p.lat is not null and new.lat is not null and km_between(p.lat, p.lng, new.lat, new.lng) <= 20)
        or ((p.lat is null or new.lat is null) and p.postcode <> '' and new.area ilike '%' || p.postcode || '%')
      )
      -- skip people who already got a saved-search alert for this listing
      and not exists (select 1 from notifications x where x.user_id = p.id and x.link = '/l/' || new.id)
    order by case when p.lat is not null and new.lat is not null then km_between(p.lat, p.lng, new.lat, new.lng) else 99 end
    limit 100
  ), sent as (
    insert into notifications (user_id, type, title, body, link)
    select h.id, 'match',
      case when new.kind = 'service' then 'New request near you: ' else 'New shift near you: ' end || new.title,
      left(new.area || ' · ' || new.pay, 140), '/l/' || new.id
    from helpers h
    returning 1
  )
  select count(*) into n from sent;
  update listings set notified = n where id = new.id;
  return new;
end $$;
drop trigger if exists listing_match on public.listings;
create trigger listing_match after insert on public.listings for each row execute function public.on_listing_match();

-- Saved-search alerts ignore private bookings.
create or replace function public.on_listing_alert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.booked_package is not null then return new; end if;
  insert into notifications (user_id, type, title, body, link)
  select distinct s.user_id, 'alert', 'New match: ' || new.title, new.area || ' - ' || new.pay, '/l/' || new.id
  from saved_searches s
  where s.user_id <> new.owner_id
    and (s.kind = 'all' or s.kind = new.kind)
    and (s.category = 'all' or s.category = new.category)
    and (s.q = '' or (new.title || ' ' || new.area || ' ' || new.description) ilike '%' || s.q || '%');
  return new;
end $$;

-- ---------- 2. Price guide ----------
-- Typical quotes for a category over the last year. Needs at least 3 quotes, otherwise returns null.
create or replace function public.price_guide(cat text) returns json
language sql stable security definer set search_path = public as $$
  with q as (
    select a.price, a.price_unit from applications a join listings l on l.id = a.listing_id
    where l.category = cat and a.price is not null and a.created_at > now() - interval '365 days'
  ), u as (
    select price_unit from q group by price_unit order by count(*) desc, price_unit limit 1
  ), s as (
    select q.price from q, u where q.price_unit = u.price_unit
  )
  select case when (select count(*) from s) < 3 then null else json_build_object(
    'n', (select count(*) from s),
    'unit', (select price_unit from u),
    'low', (select round(percentile_cont(0.25) within group (order by price)::numeric) from s),
    'mid', (select round(percentile_cont(0.5) within group (order by price)::numeric) from s),
    'high', (select round(percentile_cont(0.75) within group (order by price)::numeric) from s)) end
$$;
grant execute on function public.price_guide(text) to anon, authenticated;

-- ---------- 3. Job completion + NearTask Promise ----------
alter table public.applications add column if not exists completed_at timestamptz;

-- The person who posted marks an accepted job as done; both sides are asked for a review.
create or replace function public.complete_job(a uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  select ap.id, ap.applicant_id, ap.status, ap.completed_at, l.owner_id, l.title into r
  from applications ap join listings l on l.id = ap.listing_id where ap.id = a;
  if r.id is null or r.owner_id <> auth.uid() then raise exception 'Not allowed'; end if;
  if r.status <> 'accepted' then raise exception 'Only accepted jobs can be completed'; end if;
  if r.completed_at is not null then return; end if;
  update applications set completed_at = now() where id = a;
  perform notify(r.applicant_id, 'completed', 'Job done: ' || r.title, 'Leave a review to help others choose.', '/chat/' || a);
  perform notify(r.owner_id, 'completed', 'How did it go? ' || r.title, 'Leave a review to help others choose.', '/chat/' || a);
end $$;
revoke execute on function public.complete_job(uuid) from public, anon;
grant execute on function public.complete_job(uuid) to authenticated;

-- Report a problem with a job within 72 hours of it being completed (or of the job date).
create or replace function public.report_job_problem(a uuid, reason text) returns void
language plpgsql security definer set search_path = public as $$
declare r record; since timestamptz;
begin
  select ap.id, ap.applicant_id, ap.status, ap.completed_at, l.id as lid, l.owner_id, l.date into r
  from applications ap join listings l on l.id = ap.listing_id where ap.id = a;
  if r.id is null or auth.uid() not in (r.applicant_id, r.owner_id) then raise exception 'Not allowed'; end if;
  if r.status <> 'accepted' then raise exception 'Only accepted jobs'; end if;
  since := coalesce(r.completed_at, (r.date + 1)::timestamptz);
  if now() > since + interval '72 hours' then raise exception 'The 72-hour window has passed'; end if;
  if char_length(coalesce(reason, '')) not between 5 and 480 then raise exception 'Please describe the problem'; end if;
  insert into reports (reporter_id, listing_id, reported_user_id, reason)
  values (auth.uid(), r.lid, case when auth.uid() = r.owner_id then r.applicant_id else r.owner_id end, '[Job problem] ' || reason);
end $$;
revoke execute on function public.report_job_problem(uuid, text) from public, anon;
grant execute on function public.report_job_problem(uuid, text) to authenticated;

-- Track record counts completed jobs, and accepted jobs whose date has passed.
create or replace function public.profile_stats(u uuid) returns json
language sql stable security definer set search_path = public as $$
  with mine as (
    select a.id from applications a join listings l on l.id = a.listing_id
    where a.applicant_id = u or l.owner_id = u
  ), m as (
    select x.sender_id, x.created_at,
      lag(x.sender_id) over (partition by x.application_id order by x.created_at) as prev_sender,
      lag(x.created_at) over (partition by x.application_id order by x.created_at) as prev_at
    from messages x
    where x.application_id in (select id from mine) and x.created_at > now() - interval '120 days'
  )
  select json_build_object(
    'jobs_done', (select count(*) from applications a join listings l on l.id = a.listing_id
                  where a.applicant_id = u and a.status = 'accepted' and (a.completed_at is not null or l.date <= current_date)),
    'hires', (select count(*) from applications a join listings l on l.id = a.listing_id
              where l.owner_id = u and a.status = 'accepted'),
    'reply_minutes', (select round(percentile_cont(0.5) within group (order by extract(epoch from (m.created_at - m.prev_at)) / 60))::int
                      from m where m.sender_id = u and m.prev_sender is not null and m.prev_sender <> u))
$$;

-- Bookings get their own notification text.
create or replace function public.on_application_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare l record; who text; q text;
begin
  select owner_id, title, booked_package into l from listings where id = new.listing_id;
  q := case when new.price is null then ''
            else ' · £' || trim(to_char(new.price, 'FM99999.00')) || case when new.price_unit = 'hour' then '/hr' else '' end end;
  q := replace(q, '.00', '');
  if tg_op = 'INSERT' then
    if new.status = 'invited' and l.booked_package is not null then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'booking', 'New booking' || q || ': ' || coalesce(nullif(who, ''), 'someone'), l.title, '/chat/' || new.id);
    elsif new.status = 'invited' then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'invite', coalesce(nullif(who, ''), 'Someone') || ' invited you', l.title, '/chat/' || new.id);
    else
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, 'application',
        case when new.price is null then 'New applicant: ' else 'New quote: ' end || coalesce(nullif(who, ''), 'someone') || q,
        l.title, '/manage/' || new.listing_id);
    end if;
  elsif new.status <> old.status then
    if new.status in ('accepted','declined') and old.status = 'pending' then
      perform notify(new.applicant_id, new.status, initcap(new.status) || ': ' || l.title, '', '/chat/' || new.id);
    elsif old.status = 'invited' and new.status in ('accepted','declined') then
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, new.status, coalesce(nullif(who, ''), 'Worker') || ' ' || new.status || ' your invite', l.title, '/chat/' || new.id);
    end if;
  end if;
  return new;
end $$;

-- ---------- 4. Fixed-price services (packages) ----------
create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  category text not null check (category in ('hospitality','retail','warehouse','cleaning','repairs','garden','moving','care',
    'family','lessons','beauty','events','tech','auto','other')),
  title text not null check (char_length(title) between 3 and 80),
  description text not null default '' check (char_length(description) <= 800),
  price numeric(10,2) not null check (price >= 1 and price < 100000),
  price_unit text not null default 'total' check (price_unit in ('total','hour')),
  duration text not null default '' check (char_length(duration) <= 30),
  area text not null default '' check (char_length(area) <= 40),
  photo_url text,
  active boolean not null default true,
  lat double precision,
  lng double precision,
  created_at timestamptz not null default now()
);
create index if not exists packages_active on public.packages (category) where active;
alter table public.packages enable row level security;
drop policy if exists "packages read" on public.packages;
create policy "packages read" on public.packages for select using (active or owner_id = auth.uid());
drop policy if exists "packages insert" on public.packages;
create policy "packages insert" on public.packages for insert with check (owner_id = auth.uid() and not public.is_banned());
drop policy if exists "packages update" on public.packages;
create policy "packages update" on public.packages for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "packages delete" on public.packages;
create policy "packages delete" on public.packages for delete using (owner_id = auth.uid());
grant select on public.packages to anon, authenticated;
grant insert, update, delete on public.packages to authenticated;

-- Booking a package creates a private request and invites the provider at the package price.
-- Done in one step so the booking is consistent; the provider then accepts in the chat.
create or replace function public.book_package(pkg uuid, d date, t time, addr text, note text) returns uuid
language plpgsql security definer set search_path = public as $$
declare p record; lid uuid; aid uuid; msg text; payt text;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if is_banned() then raise exception 'Not allowed'; end if;
  select * into p from packages where id = pkg and active;
  if p.id is null then raise exception 'This service is no longer available'; end if;
  if p.owner_id = auth.uid() then raise exception 'You cannot book your own service'; end if;
  if blocked_between(p.owner_id, auth.uid()) then raise exception 'Not allowed'; end if;
  if d is null or d < current_date then raise exception 'Pick a date from today'; end if;
  payt := '£' || replace(trim(to_char(p.price, 'FM99999.00')), '.00', '') || case when p.price_unit = 'hour' then '/hr' else '' end;
  insert into listings (owner_id, kind, title, category, area, date, start_time, pay, description, positions, lat, lng, booked_package)
  values (auth.uid(), 'service', p.title, p.category,
    coalesce(nullif((select postcode from profiles where id = auth.uid()), ''), nullif(p.area, ''), 'Local'),
    d, t, payt, left(coalesce(note, ''), 1500), 1, p.lat, p.lng, p.id)
  returning id into lid;
  insert into listing_private (listing_id, address) values (lid, left(coalesce(addr, ''), 200));
  msg := 'Booking request: ' || p.title || ' (' || payt || ') on ' || to_char(d, 'Dy DD Mon') ||
    coalesce(' at ' || to_char(t, 'HH24:MI'), '') || case when coalesce(note, '') <> '' then E'\n' || left(note, 600) else '' end;
  insert into applications (listing_id, applicant_id, status, message, price, price_unit)
  values (lid, p.owner_id, 'invited', left(msg, 1000), p.price, p.price_unit) returning id into aid;
  insert into messages (application_id, sender_id, body) values (aid, auth.uid(), left(msg, 2000));
  return aid;
end $$;
revoke execute on function public.book_package(uuid, date, time, text, text) from public, anon;
grant execute on function public.book_package(uuid, date, time, text, text) to authenticated;

-- =====================================================================
-- v6: 48-hour quotes and protections for users aged 16 and 17
-- Needs v5 first. Safe to re-run. Supabase → SQL Editor → New query → Run.
-- =====================================================================

-- ---------- Age group (asked at sign-up; businesses count as 18+) ----------
alter table public.profiles add column if not exists age_group text;
alter table public.profiles drop constraint if exists profiles_age_group;
alter table public.profiles add constraint profiles_age_group check (age_group is null or age_group in ('16-17','18+'));
grant update (name, postcode, bio, avatar_url, account_type, headline, skills, available, available_days, lat, lng, portfolio, match_alerts, age_group)
  on public.profiles to authenticated;

create or replace function public.is_minor() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select age_group = '16-17' from profiles where id = auth.uid()), false)
$$;

-- Jobs and services involving alcohol, childcare or care are 18+.
create or replace function public.adult_only(l uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from listings x where x.id = l and (
    x.category in ('family','care')
    or (x.category = 'hospitality' and (x.details->>'role' = 'Bar staff' or (x.title || ' ' || x.description) ~* '\m(bar|pub|alcohol)\M'))))
$$;

drop policy if exists "applications insert" on public.applications;
create policy "applications insert" on public.applications for insert with check (
  not public.is_banned()
  and exists (select 1 from public.listings l where l.id = listing_id and l.status = 'open'
    and not public.blocked_between(l.owner_id, applicant_id))
  and not (public.adult_only(listing_id) and coalesce((select age_group from public.profiles where id = applicant_id), '') = '16-17')
  and (
    (applicant_id = auth.uid() and status = 'pending' and not public.is_listing_owner(listing_id))
    or (status = 'invited' and public.is_listing_owner(listing_id) and applicant_id <> auth.uid())
  ));

-- ---------- Quotes are valid for 48 hours ----------
alter table public.applications add column if not exists quoted_at timestamptz;
update public.applications set quoted_at = created_at where price is not null and quoted_at is null;

create or replace function public.stamp_quote() returns trigger
language plpgsql as $$
begin
  if new.price is not null and (tg_op = 'INSERT' or new.price is distinct from old.price or new.price_unit is distinct from old.price_unit) then
    new.quoted_at := now();
  end if;
  if new.price is null then new.quoted_at := null; end if;
  return new;
end $$;
drop trigger if exists application_stamp_quote on public.applications;
create trigger application_stamp_quote before insert or update on public.applications
  for each row execute function public.stamp_quote();

create or replace function public.check_application_update() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid;
begin
  if auth.uid() is null then return new; end if; -- dashboard / admin edits
  select owner_id into owner from listings where id = old.listing_id;
  if new.listing_id <> old.listing_id or new.applicant_id <> old.applicant_id or new.message <> old.message then
    raise exception 'Only the status can change';
  end if;
  if (new.price is distinct from old.price or new.price_unit is distinct from old.price_unit)
     and not (auth.uid() = old.applicant_id and new.status = 'pending') then
    raise exception 'Only the applicant can change their quote';
  end if;
  if auth.uid() = old.applicant_id then
    if old.status = 'invited' and new.status in ('accepted','declined') then return new; end if;
    if old.status in ('pending','declined','withdrawn') and new.status in ('withdrawn','pending') then return new; end if;
  end if;
  if auth.uid() = owner and old.status = 'pending' and new.status = 'accepted'
     and old.price is not null and coalesce(old.quoted_at, old.created_at) < now() - interval '48 hours' then
    raise exception 'This quote has expired. Ask for an updated quote first.';
  end if;
  if auth.uid() = owner and old.status <> 'invited' and new.status in ('accepted','declined','pending') then return new; end if;
  if auth.uid() = owner and old.status = 'invited' and new.status = 'withdrawn' then return new; end if;
  raise exception 'Not allowed';
end $$;

create or replace function public.book_package(pkg uuid, d date, t time, addr text, note text) returns uuid
language plpgsql security definer set search_path = public as $$
declare p record; lid uuid; aid uuid; msg text; payt text;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if is_banned() then raise exception 'Not allowed'; end if;
  select * into p from packages where id = pkg and active;
  if p.id is null then raise exception 'This service is no longer available'; end if;
  if p.owner_id = auth.uid() then raise exception 'You cannot book your own service'; end if;
  if blocked_between(p.owner_id, auth.uid()) then raise exception 'Not allowed'; end if;
  if d is null or d < current_date then raise exception 'Pick a date from today'; end if;
  if is_minor() and (p.category in ('family','care') or (p.category = 'hospitality' and (p.title || ' ' || p.description) ~* '\m(bar|pub|alcohol)\M')) then
    raise exception 'This service is for people aged 18 and over';
  end if;
  payt := '£' || replace(trim(to_char(p.price, 'FM99999.00')), '.00', '') || case when p.price_unit = 'hour' then '/hr' else '' end;
  insert into listings (owner_id, kind, title, category, area, date, start_time, pay, description, positions, lat, lng, booked_package)
  values (auth.uid(), 'service', p.title, p.category,
    coalesce(nullif((select postcode from profiles where id = auth.uid()), ''), nullif(p.area, ''), 'Local'),
    d, t, payt, left(coalesce(note, ''), 1500), 1, p.lat, p.lng, p.id)
  returning id into lid;
  insert into listing_private (listing_id, address) values (lid, left(coalesce(addr, ''), 200));
  msg := 'Booking request: ' || p.title || ' (' || payt || ') on ' || to_char(d, 'Dy DD Mon') ||
    coalesce(' at ' || to_char(t, 'HH24:MI'), '') || case when coalesce(note, '') <> '' then E'\n' || left(note, 600) else '' end;
  insert into applications (listing_id, applicant_id, status, message, price, price_unit)
  values (lid, p.owner_id, 'invited', left(msg, 1000), p.price, p.price_unit) returning id into aid;
  insert into messages (application_id, sender_id, body) values (aid, auth.uid(), left(msg, 2000));
  return aid;
end $$;
revoke execute on function public.book_package(uuid, date, time, text, text) from public, anon;
grant execute on function public.book_package(uuid, date, time, text, text) to authenticated;
-- =====================================================================
-- v7: phone notifications when the app is closed
-- Run AFTER deploying the send-push Edge Function (verify_jwt off). Safe to re-run.
-- No secrets in this file: the function only sends notifications that already
-- exist in the database, once each (pushed_at).
-- =====================================================================
create extension if not exists pg_net;

alter table public.notifications add column if not exists pushed_at timestamptz;

-- Remove the settings table used by the first draft of v7, if it was created.
drop table if exists private.settings;

create or replace function public.on_notification_push() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
begin
  if not exists (select 1 from push_subscriptions where user_id = new.user_id) then return new; end if;
  perform net.http_post(
    url := 'https://qayxsfanlheldqepegob.supabase.co/functions/v1/send-push',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object('id', new.id)
  );
  return new;
exception when others then
  return new; -- never block the notification itself
end $$;
revoke execute on function public.on_notification_push() from public, anon, authenticated;

drop trigger if exists notification_push on public.notifications;
create trigger notification_push after insert on public.notifications
  for each row execute function public.on_notification_push();
