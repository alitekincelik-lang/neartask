// E-mails a NearTask notification that is still unread after 5 minutes.
// Called every 5 minutes by public.send_due_emails() (supabase/v13_email_notifications.sql) with { id } only.
// Like send-push it needs no shared secret: it re-checks with public.email_due() that the
// notification really is due, claims it once (emailed_at) and only then sends, so a caller
// can't make it send anything early, twice, or to anyone else.
// Secret needed: RESEND_API_KEY. Optional: EMAIL_FROM (default "NearTask <noreply@neartask.co.uk>").
// Deployed as version 3 on 31 October 2026 (support address changed to info@artwin.co.uk).
import { createClient } from "npm:@supabase/supabase-js@2";

const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const SITE = "https://neartask.co.uk";

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

function html(title: string, body: string, url: string, button: string) {
  return `<!doctype html><html><body style="margin:0;background:#F4F6F8;font-family:Arial,Helvetica,sans-serif;color:#13203A">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F4F6F8;padding:24px 12px"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#FFFFFF;border-radius:14px;border:1px solid #DCE3EA">
<tr><td style="padding:20px 24px;border-bottom:1px solid #DCE3EA;font-size:20px;font-weight:bold;color:#0E7C7B">NearTask</td></tr>
<tr><td style="padding:24px">
<p style="margin:0 0 10px;font-size:18px;font-weight:bold;line-height:1.35">${esc(title)}</p>
${body ? `<p style="margin:0 0 20px;font-size:15px;line-height:1.5;color:#3A4760;white-space:pre-line">${esc(body)}</p>` : ""}
<a href="${url}" style="display:inline-block;background:#0E7C7B;color:#FFFFFF;text-decoration:none;font-weight:bold;font-size:15px;padding:13px 22px;border-radius:10px">${esc(button)}</a>
</td></tr>
<tr><td style="padding:16px 24px;border-top:1px solid #DCE3EA;font-size:12px;line-height:1.5;color:#5E6A80">
You get this because you have e-mail notifications on. <a href="${SITE}/#/me" style="color:#0E7C7B">Turn them off in your profile</a>.<br>
NearTask is run by Artwin Ltd. Questions: info@artwin.co.uk
</td></tr></table></td></tr></table></body></html>`;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
  const key = (Deno.env.get("RESEND_API_KEY") || "").trim();
  if (!key) { console.error("RESEND_API_KEY secret is missing"); return new Response("not configured", { status: 503 }); }
  let id: string | undefined;
  try { id = (await req.json())?.id; } catch { /* bad body */ }
  if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return new Response("bad request", { status: 400 });

  const { data: due, error: dueErr } = await sb.rpc("email_due", { nid: id });
  if (dueErr) { console.error("email_due", dueErr.message); return new Response("error", { status: 500 }); }
  if (!due || !(due as unknown[]).length) return new Response("not due");

  // Claim it: only the first caller gets the row back.
  const { data: n } = await sb.from("notifications").update({ emailed_at: new Date().toISOString() })
    .eq("id", id).is("emailed_at", null).select("id, user_id, type, title, body, link").maybeSingle();
  if (!n) return new Response("ignored");

  const { data: u, error: uErr } = await sb.auth.admin.getUserById(n.user_id);
  const to = u?.user?.email;
  if (uErr || !to || !u.user.email_confirmed_at) return new Response("no address");

  const link = typeof n.link === "string" && n.link.startsWith("/") ? n.link : "/";
  const url = SITE + "/#" + link;
  const button = n.type === "message" ? "Reply in NearTask" : link.startsWith("/manage/") ? "See applicants" : "Open in NearTask";
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: "Bearer " + key, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: (Deno.env.get("EMAIL_FROM") || "NearTask <noreply@neartask.co.uk>").trim(),
      to: [to],
      reply_to: "info@artwin.co.uk",
      subject: n.title.slice(0, 150),
      html: html(n.title, (n.body || "").slice(0, 600), url, button),
      text: n.title + "\n\n" + (n.body || "").slice(0, 600) + "\n\n" + url + "\n\nTurn off e-mails: " + SITE + "/#/me",
    }),
  });
  if (!r.ok) { console.error("resend failed", r.status, await r.text()); return new Response("send failed", { status: 502 }); }
  return new Response("ok");
});
