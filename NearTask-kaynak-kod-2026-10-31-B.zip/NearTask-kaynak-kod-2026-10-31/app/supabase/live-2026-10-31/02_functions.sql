-- ============================================================
-- NearTask – live database schema, exported 31 October 2026
-- Part 2: functions (all 54, each checked against the live database)
-- ============================================================

set check_function_bodies = off;

CREATE OR REPLACE FUNCTION public.admin_actions_recent()
 RETURNS json
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return coalesce((select json_agg(x order by x.created_at desc) from (
    select a.id, a.action, a.note, a.created_at, pa.name as actor_name, pu.name as user_name, l.title as listing_title
    from admin_actions a
    left join profiles pa on pa.id = a.actor_id
    left join profiles pu on pu.id = a.target_user
    left join listings l on l.id = a.target_listing
    order by a.created_at desc limit 100) x), '[]'::json);
end $function$;
revoke all on function public.admin_actions_recent() from public, anon, authenticated;
grant execute on function public.admin_actions_recent() to authenticated;
grant execute on function public.admin_actions_recent() to service_role;

CREATE OR REPLACE FUNCTION public.admin_job_history(a uuid)
 RETURNS json
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return (select json_build_object(
    'id', ap.id, 'status', ap.status, 'created_at', ap.created_at,
    'completed_at', ap.completed_at, 'completed_by', ap.completed_by,
    'listing_id', l.id, 'title', l.title, 'date', l.date, 'start_time', l.start_time, 'end_time', l.end_time,
    'ends_at', job_end_at(l.date, l.start_time, l.end_time),
    'owner_name', po.name, 'applicant_name', pa.name,
    'events', coalesce((select json_agg(json_build_object(
        'id', e.id, 'event', e.event, 'actor_id', e.actor_id, 'actor_name', pe.name, 'reason', e.reason,
        'prev_completed_at', e.prev_completed_at, 'created_at', e.created_at) order by e.created_at)
      from job_events e left join profiles pe on pe.id = e.actor_id where e.application_id = ap.id), '[]'::json))
    from applications ap join listings l on l.id = ap.listing_id
    left join profiles po on po.id = l.owner_id
    left join profiles pa on pa.id = ap.applicant_id
    where ap.id = a);
end $function$;
revoke all on function public.admin_job_history(a uuid) from public, anon, authenticated;
grant execute on function public.admin_job_history(a uuid) to authenticated;
grant execute on function public.admin_job_history(a uuid) to service_role;

CREATE OR REPLACE FUNCTION public.admin_listings(f text)
 RETURNS json
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if f = 'cancelled' then
    return coalesce((select json_agg(x order by x.created_at desc) from (
      select e.id, e.created_at, e.reason, e.application_id, l.id as listing_id, l.title, l.date, l.start_time,
             pa.name as actor_name, (e.created_at > ((l.date + coalesce(l.start_time, time '00:00')) at time zone 'Europe/London') - interval '24 hours') as late
      from job_events e join listings l on l.id = e.listing_id left join profiles pa on pa.id = e.actor_id
      where e.event = 'cancelled' order by e.created_at desc limit 100) x), '[]'::json);
  end if;
  return coalesce((select json_agg(x order by x.date desc, x.created_at desc) from (
    select l.id, l.title, l.category, l.kind, l.date, l.start_time, l.end_time, l.status, l.positions, l.views, l.created_at,
           po.name as owner_name,
           (select count(*) from applications a where a.listing_id = l.id and a.status = 'accepted') as accepted,
           (select count(*) from applications a where a.listing_id = l.id and a.status = 'pending') as pending,
           (select count(*) from reports r where r.listing_id = l.id and r.status = 'open') as open_reports
    from listings l left join profiles po on po.id = l.owner_id
    where case f when 'open' then l.status = 'open' when 'filled' then l.status = 'filled' when 'closed' then l.status = 'closed'
                 when 'reported' then exists (select 1 from reports r where r.listing_id = l.id and r.status = 'open') else true end
    order by l.date desc limit 200) x), '[]'::json);
end $function$;
revoke all on function public.admin_listings(f text) from public, anon, authenticated;
grant execute on function public.admin_listings(f text) to authenticated;
grant execute on function public.admin_listings(f text) to service_role;

CREATE OR REPLACE FUNCTION public.admin_overview()
 RETURNS json
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return json_build_object(
    'users', (select count(*) from profiles),
    'businesses', (select count(*) from profiles where account_type = 'business'),
    'seekers', (select count(*) from profiles where available and account_type = 'person'),
    'open_listings', (select count(*) from listings where status = 'open' and date >= current_date),
    'applications', (select count(*) from applications),
    'messages_7d', (select count(*) from messages where created_at > now() - interval '7 days'),
    'new_users_7d', (select count(*) from profiles where created_at > now() - interval '7 days'),
    'open_reports', (select count(*) from reports where status = 'open'));
end $function$;
revoke all on function public.admin_overview() from public, anon, authenticated;
grant execute on function public.admin_overview() to authenticated;
grant execute on function public.admin_overview() to service_role;

CREATE OR REPLACE FUNCTION public.admin_recent_completions()
 RETURNS json
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return coalesce((select json_agg(x order by x.completed_at desc) from (
    select a.id, a.completed_at, a.completed_by, cb.name as completed_by_name,
      l.id as listing_id, l.title, l.category, l.date, l.start_time, l.end_time,
      job_end_at(l.date, l.start_time, l.end_time) as ends_at,
      a.completed_at < job_end_at(l.date, l.start_time, l.end_time) as early,
      po.name as owner_name, pa.name as applicant_name,
      (select count(*) from reviews r where r.application_id = a.id) as reviews
    from applications a join listings l on l.id = a.listing_id
    left join profiles cb on cb.id = a.completed_by
    left join profiles po on po.id = l.owner_id
    left join profiles pa on pa.id = a.applicant_id
    where a.completed_at is not null
    order by a.completed_at desc limit 100) x), '[]'::json);
end $function$;
revoke all on function public.admin_recent_completions() from public, anon, authenticated;
grant execute on function public.admin_recent_completions() to authenticated;
grant execute on function public.admin_recent_completions() to service_role;

CREATE OR REPLACE FUNCTION public.admin_reports()
 RETURNS json
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return coalesce((select json_agg(r order by r.created_at desc) from (
    select rp.id, rp.reason, rp.status, rp.created_at, rp.listing_id, rp.reported_user_id,
      l.title as listing_title, l.status as listing_status, l.owner_id as listing_owner,
      rr.name as reporter_name, ru.name as reported_name, ru.banned as reported_banned
    from reports rp
    left join listings l on l.id = rp.listing_id
    left join profiles rr on rr.id = rp.reporter_id
    left join profiles ru on ru.id = coalesce(rp.reported_user_id, l.owner_id)
    order by rp.created_at desc limit 200) r), '[]'::json);
end $function$;
revoke all on function public.admin_reports() from public, anon, authenticated;
grant execute on function public.admin_reports() to authenticated;
grant execute on function public.admin_reports() to service_role;

CREATE OR REPLACE FUNCTION public.admin_resolve_report(r uuid, s text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if s not in ('open','resolved','dismissed') then raise exception 'Unknown status'; end if;
  update reports set status = s where id = r;
  insert into admin_actions (actor_id, action, target_report) values (auth.uid(), 'report_' || s, r);
end $function$;
revoke all on function public.admin_resolve_report(r uuid, s text) from public, anon, authenticated;
grant execute on function public.admin_resolve_report(r uuid, s text) to authenticated;
grant execute on function public.admin_resolve_report(r uuid, s text) to service_role;

CREATE OR REPLACE FUNCTION public.admin_revert_completion(a uuid, reason text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record;
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if char_length(coalesce(trim(reason), '')) not between 5 and 500 then raise exception 'Please give a reason (5-500 characters)'; end if;
  select ap.id, ap.listing_id, ap.completed_at, ap.completed_by into r from applications ap where ap.id = a for update;
  if r.id is null then raise exception 'Job not found'; end if;
  if r.completed_at is null then raise exception 'This job is not marked as completed'; end if;
  insert into job_events (application_id, listing_id, event, actor_id, reason, prev_completed_at, prev_completed_by)
  values (a, r.listing_id, 'completion_reverted', auth.uid(), trim(reason), r.completed_at, r.completed_by);
  update applications set completed_at = null, completed_by = null where id = a;
end $function$;
revoke all on function public.admin_revert_completion(a uuid, reason text) from public, anon, authenticated;
grant execute on function public.admin_revert_completion(a uuid, reason text) to authenticated;
grant execute on function public.admin_revert_completion(a uuid, reason text) to service_role;

CREATE OR REPLACE FUNCTION public.admin_search(q text)
 RETURNS json
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return coalesce((select json_agg(p order by p.created_at desc) from (
    select id, name, postcode, bio, avatar_url, rating_avg, rating_count, verified, created_at, account_type,
           headline, skills, available, available_days, lat, lng, portfolio, is_admin, banned, age_group,
           verified_at, verified_note
    from profiles
    where coalesce(trim(q), '') = '' or name ilike '%' || replace(replace(trim(q), '%', ''), '_', '') || '%'
    order by created_at desc limit 50) p), '[]'::json);
end $function$;
revoke all on function public.admin_search(q text) from public, anon, authenticated;
grant execute on function public.admin_search(q text) to authenticated;
grant execute on function public.admin_search(q text) to service_role;

CREATE OR REPLACE FUNCTION public.admin_set_banned(u uuid, v boolean, note text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n text := trim(coalesce(note, ''));
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if u = auth.uid() then raise exception 'Cannot ban yourself'; end if;
  if v and char_length(n) not between 5 and 300 then raise exception 'NOTE: Give a reason (5-300 characters)'; end if;
  update profiles set banned = v where id = u;
  if v then
    update listings set status = 'closed' where owner_id = u and status = 'open';
    update packages set active = false where owner_id = u and active;
  end if;
  insert into admin_actions (actor_id, action, target_user, note) values (auth.uid(), case when v then 'suspend' else 'restore' end, u, n);
end $function$;
revoke all on function public.admin_set_banned(u uuid, v boolean, note text) from public, anon, authenticated;
grant execute on function public.admin_set_banned(u uuid, v boolean, note text) to authenticated;
grant execute on function public.admin_set_banned(u uuid, v boolean, note text) to service_role;

CREATE OR REPLACE FUNCTION public.admin_set_listing_status(l uuid, s text, note text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if s not in ('open','filled','closed') then raise exception 'Unknown status'; end if;
  update listings set status = s where id = l;
  insert into admin_actions (actor_id, action, target_listing, note) values (auth.uid(), 'listing_' || s, l, trim(coalesce(note, '')));
end $function$;
revoke all on function public.admin_set_listing_status(l uuid, s text, note text) from public, anon, authenticated;
grant execute on function public.admin_set_listing_status(l uuid, s text, note text) to authenticated;
grant execute on function public.admin_set_listing_status(l uuid, s text, note text) to service_role;

CREATE OR REPLACE FUNCTION public.admin_set_setting(k text, v text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and is_admin) then
    raise exception 'NOT_ADMIN';
  end if;
  if k not in ('support_email') then
    raise exception 'BAD_KEY';
  end if;
  v := lower(trim(v));
  if k = 'support_email' and v !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'BAD_EMAIL';
  end if;
  insert into public.app_settings (key, value, updated_at, updated_by)
  values (k, v, now(), auth.uid())
  on conflict (key) do update
    set value = excluded.value, updated_at = now(), updated_by = auth.uid();
end
$function$;
revoke all on function public.admin_set_setting(k text, v text) from public, anon, authenticated;
grant execute on function public.admin_set_setting(k text, v text) to authenticated;
grant execute on function public.admin_set_setting(k text, v text) to service_role;

CREATE OR REPLACE FUNCTION public.admin_set_verified(u uuid, v boolean, note text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n text := trim(coalesce(note, ''));
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if v and char_length(n) not between 5 and 300 then raise exception 'NOTE: Say what you checked (5-300 characters)'; end if;
  update profiles set verified = v,
    verified_at = case when v then now() end, verified_by = case when v then auth.uid() end, verified_note = case when v then n end
  where id = u;
  insert into admin_actions (actor_id, action, target_user, note) values (auth.uid(), case when v then 'verify' else 'unverify' end, u, n);
end $function$;
revoke all on function public.admin_set_verified(u uuid, v boolean, note text) from public, anon, authenticated;
grant execute on function public.admin_set_verified(u uuid, v boolean, note text) to authenticated;
grant execute on function public.admin_set_verified(u uuid, v boolean, note text) to service_role;

CREATE OR REPLACE FUNCTION public.adult_only(l uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (select 1 from listings x where x.id = l and (
    x.category in ('family','care')
    or (x.category = 'hospitality' and (x.details->>'role' = 'Bar staff' or (x.title || ' ' || x.description) ~* '\m(bar|pub|alcohol)\M'))))
$function$;
revoke all on function public.adult_only(l uuid) from public, anon, authenticated;
grant execute on function public.adult_only(l uuid) to authenticated;
grant execute on function public.adult_only(l uuid) to service_role;

CREATE OR REPLACE FUNCTION public.applicant_is_minor(u uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce((select p.age_group = '16-17' from profiles p where p.id = u), false)
     and (auth.uid() is null          -- background jobs and the database owner
          or u = auth.uid()
          or exists (select 1 from listings l where l.owner_id = auth.uid() and public.adult_only(l.id)))
$function$;
revoke all on function public.applicant_is_minor(u uuid) from public, anon, authenticated;
grant execute on function public.applicant_is_minor(u uuid) to authenticated;
grant execute on function public.applicant_is_minor(u uuid) to service_role;

CREATE OR REPLACE FUNCTION public.auto_fill()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare l record; r record;
begin
  if new.status = 'accepted' then
    update listings x set status = 'filled'
    where x.id = new.listing_id and x.status = 'open'
      and (select count(*) from applications a where a.listing_id = x.id and a.status = 'accepted') >= x.positions
    returning x.id, x.title into l;
    if l.id is not null then
      perform set_config('neartask.quiet', '1', true);
      for r in update applications set status = 'declined'
               where listing_id = l.id and status = 'pending' returning id, applicant_id loop
        perform notify(r.applicant_id, 'declined', 'Shift filled: ' || l.title,
          'This one has been filled. Thanks for applying - new shifts appear in Explore.', '/chat/' || r.id);
      end loop;
      perform set_config('neartask.quiet', '', true);
    end if;
  end if;
  return new;
end $function$;
revoke all on function public.auto_fill() from public, anon, authenticated;
grant execute on function public.auto_fill() to service_role;

CREATE OR REPLACE FUNCTION public.blocked_between(a uuid, b uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select (auth.uid() is null or auth.uid() in (a, b))
     and exists (select 1 from blocks where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a))
$function$;
revoke all on function public.blocked_between(a uuid, b uuid) from public, anon, authenticated;
grant execute on function public.blocked_between(a uuid, b uuid) to authenticated;
grant execute on function public.blocked_between(a uuid, b uuid) to service_role;

CREATE OR REPLACE FUNCTION public.book_package(pkg uuid, d date, t time without time zone, addr text, note text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare p record; lid uuid; aid uuid; msg text; payt text;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if is_banned() then raise exception 'Not allowed'; end if;
  select * into p from packages where id = pkg and active;
  if p.id is null then raise exception 'This service is no longer available'; end if;
  if p.owner_id = auth.uid() then raise exception 'You cannot book your own service'; end if;
  if blocked_between(p.owner_id, auth.uid()) then raise exception 'Not allowed'; end if;
  if d is null or d < current_date then raise exception 'Pick a date from today'; end if;
  if is_minor() and (p.category in ('family','care') or (p.category = 'hospitality' and (p.title || ' ' || p.description) ~* '\m(bar|pub|alcohol)\M')) then
    raise exception 'This service is for people aged 18 and over';
  end if;
  payt := '£' || replace(trim(to_char(p.price, 'FM99999.00')), '.00', '') || case when p.price_unit = 'hour' then '/hr' else '' end;
  insert into listings (owner_id, kind, title, category, area, date, start_time, pay, description, positions, lat, lng, booked_package)
  values (auth.uid(), 'service', p.title, p.category,
    coalesce(nullif((select postcode from profiles where id = auth.uid()), ''), nullif(p.area, ''), 'Local'),
    d, t, payt, left(coalesce(note, ''), 1500), 1, p.lat, p.lng, p.id)
  returning id into lid;
  insert into listing_private (listing_id, address) values (lid, left(coalesce(addr, ''), 200));
  msg := 'Booking request: ' || p.title || ' (' || payt || ') on ' || to_char(d, 'Dy DD Mon') ||
    coalesce(' at ' || to_char(t, 'HH24:MI'), '') || case when coalesce(note, '') <> '' then E'\n' || left(note, 600) else '' end;
  insert into applications (listing_id, applicant_id, status, message, price, price_unit)
  values (lid, p.owner_id, 'invited', left(msg, 1000), p.price, p.price_unit) returning id into aid;
  insert into messages (application_id, sender_id, body) values (aid, auth.uid(), left(msg, 2000));
  return aid;
end $function$;
revoke all on function public.book_package(pkg uuid, d date, t time without time zone, addr text, note text) from public, anon, authenticated;
grant execute on function public.book_package(pkg uuid, d date, t time without time zone, addr text, note text) to authenticated;
grant execute on function public.book_package(pkg uuid, d date, t time without time zone, addr text, note text) to service_role;

CREATE OR REPLACE FUNCTION public.can_message(a uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (
    select 1 from applications ap join listings li on li.id = ap.listing_id
    where ap.id = a and (ap.applicant_id = auth.uid() or li.owner_id = auth.uid())
      and not blocked_between(ap.applicant_id, li.owner_id)
  ) and not is_banned()
$function$;
revoke all on function public.can_message(a uuid) from public, anon, authenticated;
grant execute on function public.can_message(a uuid) to authenticated;
grant execute on function public.can_message(a uuid) to service_role;

CREATE OR REPLACE FUNCTION public.cancel_job(a uuid, reason text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; starts timestamptz; late boolean; other uuid; why text := trim(coalesce(reason, ''));
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  select ap.id, ap.applicant_id, ap.status, ap.completed_at, ap.listing_id,
         l.owner_id, l.title, l.date, l.start_time, l.end_time, l.booked_package into r
  from applications ap join listings l on l.id = ap.listing_id where ap.id = a for update of ap;
  if r.id is null or auth.uid() not in (r.applicant_id, r.owner_id) then raise exception 'Not allowed'; end if;
  if r.status <> 'accepted' then raise exception 'Only accepted jobs can be cancelled'; end if;
  if r.completed_at is not null then raise exception 'COMPLETED_LOCKED: A completed job cannot be changed'; end if;
  if now() >= job_end_at(r.date, r.start_time, r.end_time) then raise exception 'ENDED: This job has already ended. Report a problem instead.'; end if;
  if char_length(why) not between 5 and 300 then raise exception 'REASON: Please give a reason (5-300 characters)'; end if;
  starts := (r.date + coalesce(r.start_time, time '00:00')) at time zone 'Europe/London';
  late := now() > starts - interval '24 hours';
  update applications set status = 'cancelled' where id = a;
  insert into job_events (application_id, listing_id, event, actor_id, reason) values (a, r.listing_id, 'cancelled', auth.uid(), why);
  if r.booked_package is not null then
    update listings set status = 'closed' where id = r.listing_id;
  else
    update listings l set status = 'open' where l.id = r.listing_id and l.status = 'filled' and l.date >= current_date
      and (select count(*) from applications x where x.listing_id = l.id and x.status = 'accepted') < l.positions;
  end if;
  other := case when auth.uid() = r.applicant_id then r.owner_id else r.applicant_id end;
  perform notify(other, 'cancelled', 'Cancelled: ' || r.title, why, '/chat/' || a);
  if late then
    insert into reports (reporter_id, listing_id, reported_user_id, reason)
    values (auth.uid(), r.listing_id, auth.uid(), left('[Late cancellation] ' || why, 500));
  end if;
end $function$;
revoke all on function public.cancel_job(a uuid, reason text) from public, anon, authenticated;
grant execute on function public.cancel_job(a uuid, reason text) to authenticated;
grant execute on function public.cancel_job(a uuid, reason text) to service_role;

CREATE OR REPLACE FUNCTION public.check_application_update()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare owner uuid; places int; taken int;
begin
  if auth.uid() is null then return new; end if; -- dashboard / admin edits
  -- Only reachable from inside another trigger (auto_fill), never from a user's own update.
  if pg_trigger_depth() > 1 and old.status = 'pending' and new.status = 'declined'
     and exists (select 1 from listings where id = old.listing_id and status in ('filled', 'closed')) then
    return new;
  end if;
  select owner_id, positions into owner, places from listings where id = old.listing_id;
  if new.listing_id <> old.listing_id or new.applicant_id <> old.applicant_id or new.message <> old.message then
    raise exception 'Only the status can change';
  end if;
  if new.status = old.status
     and new.price is not distinct from old.price and new.price_unit is not distinct from old.price_unit then
    return new;
  end if;
  if new.status is distinct from old.status then
    if old.completed_at is not null then raise exception 'COMPLETED_LOCKED: A completed job cannot be changed'; end if;
    if old.status = 'cancelled' then raise exception 'This job was cancelled'; end if;
    if new.status = 'cancelled' then
      if old.status = 'accepted' and auth.uid() in (old.applicant_id, owner) then return new; end if;
      raise exception 'Not allowed';
    end if;
    if old.status = 'accepted' then raise exception 'ACCEPTED_LOCKED: Use "Cancel job" to cancel an accepted job'; end if;
    if new.status = 'accepted' then
      perform 1 from listings where id = old.listing_id for update;
      select count(*) into taken from applications where listing_id = old.listing_id and status = 'accepted';
      if taken >= coalesce(places, 1) then raise exception 'FULL: All places for this listing are filled'; end if;
    end if;
  end if;
  if (new.price is distinct from old.price or new.price_unit is distinct from old.price_unit)
     and not (auth.uid() = old.applicant_id and new.status = 'pending') then
    raise exception 'Only the applicant can change their quote';
  end if;
  if auth.uid() = old.applicant_id then
    if old.status = 'invited' and new.status in ('accepted','declined') then return new; end if;
    if old.status in ('pending','declined','withdrawn') and new.status in ('withdrawn','pending') then return new; end if;
  end if;
  if auth.uid() = owner and old.status = 'pending' and new.status = 'accepted'
     and old.price is not null and coalesce(old.quoted_at, old.created_at) < now() - interval '48 hours' then
    raise exception 'This quote has expired. Ask for an updated quote first.';
  end if;
  if auth.uid() = owner and old.status in ('pending','declined') and new.status in ('accepted','declined','pending') then return new; end if;
  if auth.uid() = owner and old.status = 'invited' and new.status = 'withdrawn' then return new; end if;
  raise exception 'Not allowed';
end $function$;
revoke all on function public.check_application_update() from public, anon, authenticated;
grant execute on function public.check_application_update() to service_role;

CREATE OR REPLACE FUNCTION public.check_review()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare ap record;
begin
  select a.applicant_id, a.status, a.completed_at, l.owner_id into ap
  from applications a join listings l on l.id = a.listing_id where a.id = new.application_id;
  if ap is null then raise exception 'Job not found'; end if;
  if not ((new.reviewer_id = ap.applicant_id and new.reviewee_id = ap.owner_id)
       or (new.reviewer_id = ap.owner_id and new.reviewee_id = ap.applicant_id)) then
    raise exception 'Not a participant';
  end if;
  if ap.status <> 'accepted' or ap.completed_at is null then
    raise exception 'NOT_COMPLETED: You can rate this job once it has been completed';
  end if;
  if exists (select 1 from reviews where application_id = new.application_id and reviewer_id = new.reviewer_id) then
    raise exception 'ALREADY_REVIEWED: You have already rated this job';
  end if;
  new.created_at := now(); -- server timestamp, not client supplied
  return new;
end $function$;
revoke all on function public.check_review() from public, anon, authenticated;
grant execute on function public.check_review() to service_role;

CREATE OR REPLACE FUNCTION public.close_past_listings()
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare l record; r record; n int := 0;
begin
  perform set_config('neartask.quiet', '1', true);
  for l in update listings x set status = 'closed'
           where x.status = 'open' and x.date is not null
             and public.job_end_at(x.date, x.start_time, x.end_time) < now()
           returning x.id, x.title loop
    for r in update applications set status = 'declined'
             where listing_id = l.id and status = 'pending' returning id, applicant_id loop
      perform notify(r.applicant_id, 'closed', 'Closed: ' || l.title,
        'This listing has ended without a booking for you. New shifts appear in Explore.', '/chat/' || r.id);
    end loop;
    n := n + 1;
  end loop;
  perform set_config('neartask.quiet', '', true);
  return n;
end $function$;
revoke all on function public.close_past_listings() from public, anon, authenticated;
grant execute on function public.close_past_listings() to service_role;

CREATE OR REPLACE FUNCTION public.complete_job(a uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; ends timestamptz;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  select ap.id, ap.applicant_id, ap.status, ap.completed_at, ap.listing_id,
         l.owner_id, l.title, l.status as lstatus, l.date, l.start_time, l.end_time into r
  from applications ap join listings l on l.id = ap.listing_id where ap.id = a
  for update of ap;
  if r.id is null or r.owner_id <> auth.uid() then raise exception 'Not allowed'; end if;
  if is_banned() then raise exception 'Not allowed'; end if;
  if r.status <> 'accepted' then raise exception 'Only accepted jobs can be completed'; end if;
  if r.lstatus = 'closed' then raise exception 'This listing was closed'; end if;
  if r.completed_at is not null then raise exception 'Already completed'; end if;
  ends := job_end_at(r.date, r.start_time, r.end_time);
  if now() < ends then
    raise exception 'NOT_FINISHED: This job can be marked as done after %', to_char(ends at time zone 'Europe/London', 'DD Mon YYYY HH24:MI');
  end if;
  update applications set completed_at = now(), completed_by = auth.uid() where id = a;
  insert into job_events (application_id, listing_id, event, actor_id) values (a, r.listing_id, 'completed', auth.uid());
  perform notify(r.applicant_id, 'completed', 'Job done: ' || r.title, 'Leave a review to help others choose.', '/chat/' || a);
  perform notify(r.owner_id, 'completed', 'How did it go? ' || r.title, 'Leave a review to help others choose.', '/chat/' || a);
end $function$;
revoke all on function public.complete_job(a uuid) from public, anon, authenticated;
grant execute on function public.complete_job(a uuid) to authenticated;
grant execute on function public.complete_job(a uuid) to service_role;

CREATE OR REPLACE FUNCTION public.delete_my_account()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from storage.objects where bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text;
  delete from auth.users where id = auth.uid();
end $function$;
revoke all on function public.delete_my_account() from public, anon, authenticated;
grant execute on function public.delete_my_account() to authenticated;
grant execute on function public.delete_my_account() to service_role;

CREATE OR REPLACE FUNCTION public.email_due(nid uuid DEFAULT NULL::uuid)
 RETURNS SETOF uuid
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select n.id from notifications n join profiles p on p.id = n.user_id
  where (nid is null or n.id = nid)
    and n.emailed_at is null and n.read = false
    and n.created_at <= now() - interval '5 minutes'
    and n.created_at >  now() - interval '1 hour'
    and n.type in ('application', 'accepted', 'invite', 'invited', 'booking', 'declined', 'cancelled', 'reminder', 'message')
    and p.email_notify and not coalesce(p.banned, false)
    and not (n.type = 'message' and (
      exists (select 1 from notifications o where o.user_id = n.user_id and o.type = 'message' and o.link = n.link
                and o.emailed_at > now() - interval '30 minutes')
      or exists (select 1 from notifications o where o.user_id = n.user_id and o.type = 'message' and o.link = n.link
                and o.emailed_at is null and o.read = false and o.created_at > n.created_at)
      or exists (select 1 from messages m where n.link = '/chat/' || m.application_id
                and m.sender_id = n.user_id and m.created_at > n.created_at)
      or exists (select 1 from notifications o where o.user_id = n.user_id and o.type in ('application', 'invite', 'invited', 'booking')
                and o.created_at between n.created_at - interval '1 minute' and n.created_at + interval '1 minute')))
  order by n.created_at
  limit 50
$function$;
revoke all on function public.email_due(nid uuid) from public, anon, authenticated;
grant execute on function public.email_due(nid uuid) to service_role;

CREATE OR REPLACE FUNCTION public.guard_completion_columns()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if current_user in ('authenticated', 'anon') then
    if new.completed_at is distinct from old.completed_at or new.completed_by is distinct from old.completed_by then
      raise exception 'Use "Mark job as done" to complete a job';
    end if;
    if new.status = 'cancelled' and old.status is distinct from 'cancelled' then
      raise exception 'Use "Cancel job" to cancel';
    end if;
  end if;
  return new;
end $function$;
revoke all on function public.guard_completion_columns() from public, anon, authenticated;
grant execute on function public.guard_completion_columns() to service_role;

CREATE OR REPLACE FUNCTION public.guard_profile_age()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if current_user in ('authenticated', 'anon') and old.age_group = '16-17'
     and (new.age_group is distinct from '16-17' or new.account_type = 'business') then
    raise exception 'AGE_LOCKED: Contact support to change your age group';
  end if;
  return new;
end $function$;
revoke all on function public.guard_profile_age() from public, anon, authenticated;
grant execute on function public.guard_profile_age() to service_role;

CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  insert into public.profiles (id) values (new.id) on conflict do nothing;
  return new;
end $function$;
revoke all on function public.handle_new_user() from public, anon, authenticated;
grant execute on function public.handle_new_user() to supabase_auth_admin;
grant execute on function public.handle_new_user() to service_role;

CREATE OR REPLACE FUNCTION public.is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce((select is_admin from profiles where id = auth.uid()), false)
$function$;
revoke all on function public.is_admin() from public, anon, authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_admin() to service_role;

CREATE OR REPLACE FUNCTION public.is_banned()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce((select banned from profiles where id = auth.uid()), false)
$function$;
revoke all on function public.is_banned() from public, anon, authenticated;
grant execute on function public.is_banned() to authenticated;
grant execute on function public.is_banned() to service_role;

CREATE OR REPLACE FUNCTION public.is_listing_owner(l uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (select 1 from listings where id = l and owner_id = auth.uid())
$function$;
revoke all on function public.is_listing_owner(l uuid) from public, anon, authenticated;
grant execute on function public.is_listing_owner(l uuid) to authenticated;
grant execute on function public.is_listing_owner(l uuid) to service_role;

CREATE OR REPLACE FUNCTION public.is_minor()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce((select age_group = '16-17' from profiles where id = auth.uid()), false)
$function$;
revoke all on function public.is_minor() from public, anon, authenticated;
grant execute on function public.is_minor() to authenticated;
grant execute on function public.is_minor() to service_role;

CREATE OR REPLACE FUNCTION public.is_participant(a uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (
    select 1 from applications ap join listings li on li.id = ap.listing_id
    where ap.id = a and (ap.applicant_id = auth.uid() or li.owner_id = auth.uid())
  )
$function$;
revoke all on function public.is_participant(a uuid) from public, anon, authenticated;
grant execute on function public.is_participant(a uuid) to authenticated;
grant execute on function public.is_participant(a uuid) to service_role;

CREATE OR REPLACE FUNCTION public.job_end_at(d date, st time without time zone, et time without time zone)
 RETURNS timestamp with time zone
 LANGUAGE sql
 STABLE
 SET search_path TO 'public'
AS $function$
  select ((d + coalesce(et, time '23:59:59'))
          + case when et is not null and st is not null and et <= st then interval '1 day' else interval '0' end)
         at time zone 'Europe/London'
$function$;
revoke all on function public.job_end_at(d date, st time without time zone, et time without time zone) from public, anon, authenticated;
grant execute on function public.job_end_at(d date, st time without time zone, et time without time zone) to public, anon, authenticated;
grant execute on function public.job_end_at(d date, st time without time zone, et time without time zone) to service_role;

CREATE OR REPLACE FUNCTION public.km_between(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision)
 RETURNS double precision
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select 6371 * 2 * asin(sqrt(power(sin(radians(lat2 - lat1) / 2), 2)
    + cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)))
$function$;
revoke all on function public.km_between(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision) from public, anon, authenticated;
grant execute on function public.km_between(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision) to public, anon, authenticated;
grant execute on function public.km_between(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision) to service_role;

CREATE OR REPLACE FUNCTION public.my_profile()
 RETURNS json
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select row_to_json(p) from (
    select id, name, postcode, bio, avatar_url, rating_avg, rating_count, verified, created_at, account_type,
           headline, skills, available, available_days, lat, lng, portfolio, is_admin, banned, match_alerts, age_group,
           email_notify
    from profiles where id = auth.uid()) p
$function$;
revoke all on function public.my_profile() from public, anon, authenticated;
grant execute on function public.my_profile() to authenticated;
grant execute on function public.my_profile() to service_role;

CREATE OR REPLACE FUNCTION public.notify(u uuid, ty text, ti text, bo text, li text)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  insert into notifications (user_id, type, title, body, link) select u, ty, ti, left(coalesce(bo, ''), 140), li where u is not null
$function$;
revoke all on function public.notify(u uuid, ty text, ti text, bo text, li text) from public, anon, authenticated;
grant execute on function public.notify(u uuid, ty text, ti text, bo text, li text) to service_role;

CREATE OR REPLACE FUNCTION public.on_application_notify()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare l record; who text; q text;
begin
  if current_setting('neartask.quiet', true) = '1' then return new; end if;
  select owner_id, title, booked_package into l from listings where id = new.listing_id;
  q := case when new.price is null then ''
            else ' · £' || trim(to_char(new.price, 'FM99999.00')) || case when new.price_unit = 'hour' then '/hr' else '' end end;
  q := replace(q, '.00', '');
  if tg_op = 'INSERT' then
    if new.status = 'invited' and l.booked_package is not null then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'booking', 'New booking' || q || ': ' || coalesce(nullif(who, ''), 'someone'), l.title, '/chat/' || new.id);
    elsif new.status = 'invited' then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'invite', coalesce(nullif(who, ''), 'Someone') || ' invited you', l.title, '/chat/' || new.id);
    else
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, 'application',
        case when new.price is null then 'New applicant: ' else 'New quote: ' end || coalesce(nullif(who, ''), 'someone') || q,
        l.title, '/manage/' || new.listing_id);
    end if;
  elsif new.status <> old.status then
    if new.status in ('accepted','declined') and old.status = 'pending' then
      perform notify(new.applicant_id, new.status, initcap(new.status) || ': ' || l.title, '', '/chat/' || new.id);
    elsif old.status = 'invited' and new.status in ('accepted','declined') then
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, new.status, coalesce(nullif(who, ''), 'Worker') || ' ' || new.status || ' your invite', l.title, '/chat/' || new.id);
    end if;
  end if;
  return new;
end $function$;
revoke all on function public.on_application_notify() from public, anon, authenticated;
grant execute on function public.on_application_notify() to service_role;

CREATE OR REPLACE FUNCTION public.on_listing_alert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if new.booked_package is not null then return new; end if;
  insert into notifications (user_id, type, title, body, link)
  select distinct s.user_id, 'alert', 'New match: ' || new.title, new.area || ' - ' || new.pay, '/l/' || new.id
  from saved_searches s
  where s.user_id <> new.owner_id
    and (s.kind = 'all' or s.kind = new.kind)
    and (s.category = 'all' or s.category = new.category)
    and (s.q = '' or (new.title || ' ' || new.area || ' ' || new.description) ilike '%' || s.q || '%');
  return new;
end $function$;
revoke all on function public.on_listing_alert() from public, anon, authenticated;
grant execute on function public.on_listing_alert() to service_role;

CREATE OR REPLACE FUNCTION public.on_listing_match()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n int;
begin
  if new.status <> 'open' or new.booked_package is not null then return new; end if;
  with helpers as (
    select p.id from profiles p
    where p.id <> new.owner_id
      and p.match_alerts and not p.banned
      and new.category = any (p.skills)
      and (new.kind = 'service' or p.available)                -- shifts go to people looking for work
      and not blocked_between(p.id, new.owner_id)
      and (
        (p.lat is not null and new.lat is not null and km_between(p.lat, p.lng, new.lat, new.lng) <= 20)
        or ((p.lat is null or new.lat is null) and p.postcode <> '' and new.area ilike '%' || p.postcode || '%')
      )
      -- skip people who already got a saved-search alert for this listing
      and not exists (select 1 from notifications x where x.user_id = p.id and x.link = '/l/' || new.id)
    order by case when p.lat is not null and new.lat is not null then km_between(p.lat, p.lng, new.lat, new.lng) else 99 end
    limit 100
  ), sent as (
    insert into notifications (user_id, type, title, body, link)
    select h.id, 'match',
      case when new.kind = 'service' then 'New request near you: ' else 'New shift near you: ' end || new.title,
      left(new.area || ' · ' || new.pay, 140), '/l/' || new.id
    from helpers h
    returning 1
  )
  select count(*) into n from sent;
  update listings set notified = n where id = new.id;
  return new;
end $function$;
revoke all on function public.on_listing_match() from public, anon, authenticated;
grant execute on function public.on_listing_match() to service_role;

CREATE OR REPLACE FUNCTION public.on_message_notify()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare ap record; who text;
begin
  select a.applicant_id, l.owner_id, l.title into ap from applications a join listings l on l.id = a.listing_id where a.id = new.application_id;
  select name into who from profiles where id = new.sender_id;
  perform notify(case when new.sender_id = ap.applicant_id then ap.owner_id else ap.applicant_id end,
    'message', coalesce(nullif(who, ''), 'New message') || ' - ' || ap.title, new.body, '/chat/' || new.application_id);
  return new;
end $function$;
revoke all on function public.on_message_notify() from public, anon, authenticated;
grant execute on function public.on_message_notify() to service_role;

CREATE OR REPLACE FUNCTION public.on_notification_push()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not exists (select 1 from push_subscriptions where user_id = new.user_id) then return new; end if;
  perform net.http_post(
    url := 'https://qayxsfanlheldqepegob.supabase.co/functions/v1/send-push',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object('id', new.id)
  );
  return new;
exception when others then
  return new; -- never block the notification itself
end $function$;
revoke all on function public.on_notification_push() from public, anon, authenticated;
grant execute on function public.on_notification_push() to service_role;

CREATE OR REPLACE FUNCTION public.price_guide(cat text)
 RETURNS json
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  with q as (
    select a.price, a.price_unit from applications a join listings l on l.id = a.listing_id
    where l.category = cat and a.price is not null and a.created_at > now() - interval '365 days'
  ), u as (
    select price_unit from q group by price_unit order by count(*) desc, price_unit limit 1
  ), s as (
    select q.price from q, u where q.price_unit = u.price_unit
  )
  select case when (select count(*) from s) < 3 then null else json_build_object(
    'n', (select count(*) from s),
    'unit', (select price_unit from u),
    'low', (select round(percentile_cont(0.25) within group (order by price)::numeric) from s),
    'mid', (select round(percentile_cont(0.5) within group (order by price)::numeric) from s),
    'high', (select round(percentile_cont(0.75) within group (order by price)::numeric) from s)) end
$function$;
revoke all on function public.price_guide(cat text) from public, anon, authenticated;
grant execute on function public.price_guide(cat text) to public, anon, authenticated;
grant execute on function public.price_guide(cat text) to service_role;

CREATE OR REPLACE FUNCTION public.profile_stats(u uuid)
 RETURNS json
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  with mine as (
    select a.id from applications a join listings l on l.id = a.listing_id
    where a.applicant_id = u or l.owner_id = u
  ), m as (
    select x.sender_id, x.created_at,
      lag(x.sender_id) over (partition by x.application_id order by x.created_at) as prev_sender,
      lag(x.created_at) over (partition by x.application_id order by x.created_at) as prev_at
    from messages x
    where x.application_id in (select id from mine) and x.created_at > now() - interval '120 days'
  )
  select json_build_object(
    'jobs_done', (select count(*) from applications a where a.applicant_id = u and a.status = 'accepted' and a.completed_at is not null),
    'hires', (select count(*) from applications a join listings l on l.id = a.listing_id
              where l.owner_id = u and a.status = 'accepted'),
    'reply_minutes', (select round(percentile_cont(0.5) within group (order by extract(epoch from (m.created_at - m.prev_at)) / 60))::int
                      from m where m.sender_id = u and m.prev_sender is not null and m.prev_sender <> u))
$function$;
revoke all on function public.profile_stats(u uuid) from public, anon, authenticated;
grant execute on function public.profile_stats(u uuid) to public, anon, authenticated;
grant execute on function public.profile_stats(u uuid) to service_role;

CREATE OR REPLACE FUNCTION public.public_stats()
 RETURNS json
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select json_build_object(
    'seekers', (select count(*) from profiles where available and account_type = 'person'),
    'businesses', (select count(*) from profiles where account_type = 'business'),
    'listings', (select count(*) from listings where status = 'open' and date >= current_date))
$function$;
revoke all on function public.public_stats() from public, anon, authenticated;
grant execute on function public.public_stats() to public, anon, authenticated;
grant execute on function public.public_stats() to service_role;

CREATE OR REPLACE FUNCTION public.refresh_rating()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  update profiles p set
    rating_avg = coalesce((select round(avg(stars)::numeric, 2) from reviews where reviewee_id = new.reviewee_id), 0),
    rating_count = (select count(*) from reviews where reviewee_id = new.reviewee_id)
  where p.id = new.reviewee_id;
  return new;
end $function$;
revoke all on function public.refresh_rating() from public, anon, authenticated;
grant execute on function public.refresh_rating() to service_role;

CREATE OR REPLACE FUNCTION public.report_job_problem(a uuid, reason text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; since timestamptz;
begin
  select ap.id, ap.applicant_id, ap.status, ap.completed_at, l.id as lid, l.owner_id, l.date into r
  from applications ap join listings l on l.id = ap.listing_id where ap.id = a;
  if r.id is null or auth.uid() not in (r.applicant_id, r.owner_id) then raise exception 'Not allowed'; end if;
  if r.status <> 'accepted' then raise exception 'Only accepted jobs'; end if;
  since := coalesce(r.completed_at, (r.date + 1)::timestamptz);
  if now() > since + interval '72 hours' then raise exception 'The 72-hour window has passed'; end if;
  if char_length(coalesce(reason, '')) not between 5 and 480 then raise exception 'Please describe the problem'; end if;
  insert into reports (reporter_id, listing_id, reported_user_id, reason)
  values (auth.uid(), r.lid, case when auth.uid() = r.owner_id then r.applicant_id else r.owner_id end, '[Job problem] ' || reason);
end $function$;
revoke all on function public.report_job_problem(a uuid, reason text) from public, anon, authenticated;
grant execute on function public.report_job_problem(a uuid, reason text) to authenticated;
grant execute on function public.report_job_problem(a uuid, reason text) to service_role;

CREATE OR REPLACE FUNCTION public.round_profile_location()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if new.lat is not null then new.lat := round(new.lat::numeric, 2); end if;
  if new.lng is not null then new.lng := round(new.lng::numeric, 2); end if;
  return new;
end $function$;
revoke all on function public.round_profile_location() from public, anon, authenticated;
grant execute on function public.round_profile_location() to public, anon, authenticated;
grant execute on function public.round_profile_location() to service_role;

CREATE OR REPLACE FUNCTION public.send_due_emails()
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare r record; n int := 0;
begin
  for r in select x as id from email_due() x loop
    perform net.http_post(
      url := 'https://qayxsfanlheldqepegob.supabase.co/functions/v1/send-email',
      headers := jsonb_build_object('Content-Type', 'application/json'),
      body := jsonb_build_object('id', r.id));
    n := n + 1;
  end loop;
  return n;
end $function$;
revoke all on function public.send_due_emails() from public, anon, authenticated;
grant execute on function public.send_due_emails() to service_role;

CREATE OR REPLACE FUNCTION public.send_shift_reminders()
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  r record; n int := 0; starts timestamptz; whenx text; nm text;
begin
  for r in
    select a.id, a.applicant_id, l.owner_id, l.title, l.date, l.start_time, l.area
    from applications a join listings l on l.id = a.listing_id
    where a.status = 'accepted' and a.completed_at is null
      and l.date is not null and l.start_time is not null
      and ((l.date + l.start_time) at time zone 'Europe/London') > now()
      and ((l.date + l.start_time) at time zone 'Europe/London') <= now() + interval '24 hours'
      and not exists (select 1 from shift_reminders s where s.application_id = a.id)
    for update of a skip locked
  loop
    starts := (r.date + r.start_time) at time zone 'Europe/London';
    whenx := case when r.date = (now() at time zone 'Europe/London')::date then 'today' else 'tomorrow' end
             || ' at ' || to_char(r.start_time, 'HH24:MI');
    insert into shift_reminders (application_id) values (r.id);
    insert into notifications (user_id, type, title, body, link)
      values (r.applicant_id, 'reminder', 'Reminder: ' || r.title || ' ' || whenx,
              coalesce(nullif(r.area, ''), 'Your shift') || '. Message the business if anything changes.',
              '/chat/' || r.id);
    if r.owner_id <> r.applicant_id then
      select coalesce(nullif(trim(name), ''), 'your worker') into nm from profiles where id = r.applicant_id;
      insert into notifications (user_id, type, title, body, link)
        values (r.owner_id, 'reminder', 'Reminder: ' || r.title || ' ' || whenx,
                coalesce(nm, 'your worker') || ' is booked for this shift.',
                '/chat/' || r.id);
    end if;
    n := n + 1;
  end loop;
  return n;
end $function$;
revoke all on function public.send_shift_reminders() from public, anon, authenticated;
grant execute on function public.send_shift_reminders() to service_role;

CREATE OR REPLACE FUNCTION public.stamp_quote()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if tg_op = 'UPDATE' and current_user in ('authenticated', 'anon') then
    if new.id <> old.id then raise exception 'Not allowed'; end if;
    new.created_at := old.created_at;
    if new.price is not distinct from old.price and new.price_unit is not distinct from old.price_unit then
      new.quoted_at := old.quoted_at;
    end if;
  end if;
  if new.price is not null and (tg_op = 'INSERT' or new.price is distinct from old.price or new.price_unit is distinct from old.price_unit) then
    new.quoted_at := now();
  end if;
  if new.price is null then new.quoted_at := null; end if;
  return new;
end $function$;
revoke all on function public.stamp_quote() from public, anon, authenticated;
grant execute on function public.stamp_quote() to service_role;

CREATE OR REPLACE FUNCTION public.stamp_report()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if current_user in ('authenticated', 'anon') then
    new.status := 'open';
    new.created_at := now();
  end if;
  return new;
end $function$;
revoke all on function public.stamp_report() from public, anon, authenticated;
grant execute on function public.stamp_report() to service_role;

CREATE OR REPLACE FUNCTION public.view_listing(l uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare who text; ip text;
begin
  if exists (select 1 from listings where id = l and owner_id = auth.uid()) then return; end if;
  begin
    ip := split_part(coalesce(current_setting('request.headers', true)::json ->> 'x-forwarded-for', ''), ',', 1);
  exception when others then ip := '';
  end;
  who := coalesce(auth.uid()::text, 'ip:' || md5(coalesce(nullif(ip, ''), 'unknown')));
  insert into listing_views (listing_id, viewer) values (l, who) on conflict do nothing;
  if found then update listings set views = views + 1 where id = l; end if;
end $function$;
revoke all on function public.view_listing(l uuid) from public, anon, authenticated;
grant execute on function public.view_listing(l uuid) to public, anon, authenticated;
grant execute on function public.view_listing(l uuid) to service_role;
