-- ============================================================
-- NearTask – live database schema, exported 31 October 2026
-- Supabase project "NearTask App" (qayxsfanlheldqepegob)
-- Part 1: tables (columns, defaults, keys, checks)
-- ============================================================

create table if not exists public.profiles (
  id uuid not null,
  name text default ''::text not null,
  postcode text default ''::text not null,
  bio text default ''::text not null,
  avatar_url text,
  rating_avg numeric(3,2) default 0 not null,
  rating_count integer default 0 not null,
  verified boolean default false not null,
  created_at timestamp with time zone default now() not null,
  account_type text default 'person'::text not null,
  headline text default ''::text not null,
  skills text[] default '{}'::text[] not null,
  available boolean default false not null,
  available_days text[] default '{}'::text[] not null,
  lat double precision,
  lng double precision,
  portfolio text[] default '{}'::text[] not null,
  is_admin boolean default false not null,
  banned boolean default false not null,
  match_alerts boolean default true not null,
  age_group text,
  verified_at timestamp with time zone,
  verified_by uuid,
  verified_note text,
  email_notify boolean default true not null,
  constraint profiles_pkey PRIMARY KEY (id),
  constraint profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE,
  constraint profiles_account_type CHECK ((account_type = ANY (ARRAY['person'::text, 'business'::text]))),
  constraint profiles_age_group CHECK (((age_group IS NULL) OR (age_group = ANY (ARRAY['16-17'::text, '18+'::text])))),
  constraint profiles_bio_check CHECK ((char_length(bio) <= 500)),
  constraint profiles_name_check CHECK ((char_length(name) <= 60)),
  constraint profiles_portfolio_max CHECK ((cardinality(portfolio) <= 8)),
  constraint profiles_postcode_check CHECK ((char_length(postcode) <= 10))
);

create table if not exists public.listings (
  id uuid default gen_random_uuid() not null,
  owner_id uuid default auth.uid() not null,
  kind text not null,
  title text not null,
  category text not null,
  area text not null,
  date date not null,
  start_time time without time zone,
  end_time time without time zone,
  pay text not null,
  description text default ''::text not null,
  requirements text default ''::text not null,
  photo_url text,
  status text default 'open'::text not null,
  created_at timestamp with time zone default now() not null,
  positions integer default 1 not null,
  views integer default 0 not null,
  lat double precision,
  lng double precision,
  details jsonb default '{}'::jsonb not null,
  notified integer default 0 not null,
  booked_package uuid,
  constraint listings_pkey PRIMARY KEY (id),
  constraint listings_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint listings_area_check CHECK (((char_length(area) >= 2) AND (char_length(area) <= 40))),
  constraint listings_category_check CHECK ((category = ANY (ARRAY['hospitality'::text, 'retail'::text, 'warehouse'::text, 'cleaning'::text, 'repairs'::text, 'garden'::text, 'moving'::text, 'care'::text, 'family'::text, 'lessons'::text, 'beauty'::text, 'events'::text, 'tech'::text, 'auto'::text, 'other'::text]))),
  constraint listings_description_check CHECK ((char_length(description) <= 1500)),
  constraint listings_details_shape CHECK (((jsonb_typeof(details) = 'object'::text) AND (length((details)::text) <= 2000))),
  constraint listings_kind_check CHECK ((kind = ANY (ARRAY['job'::text, 'service'::text]))),
  constraint listings_pay_check CHECK (((char_length(pay) >= 1) AND (char_length(pay) <= 30))),
  constraint listings_positions CHECK (((positions >= 1) AND (positions <= 50))),
  constraint listings_requirements_check CHECK ((char_length(requirements) <= 500)),
  constraint listings_status_check CHECK ((status = ANY (ARRAY['open'::text, 'filled'::text, 'closed'::text]))),
  constraint listings_title_check CHECK (((char_length(title) >= 3) AND (char_length(title) <= 80)))
);

create table if not exists public.listing_private (
  listing_id uuid not null,
  address text default ''::text not null,
  constraint listing_private_pkey PRIMARY KEY (listing_id),
  constraint listing_private_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE,
  constraint listing_private_address_check CHECK ((char_length(address) <= 200))
);

create table if not exists public.listing_views (
  listing_id uuid not null,
  viewer text not null,
  day date default CURRENT_DATE not null,
  constraint listing_views_pkey PRIMARY KEY (listing_id, viewer, day),
  constraint listing_views_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE
);

create table if not exists public.packages (
  id uuid default gen_random_uuid() not null,
  owner_id uuid default auth.uid() not null,
  category text not null,
  title text not null,
  description text default ''::text not null,
  price numeric(10,2) not null,
  price_unit text default 'total'::text not null,
  duration text default ''::text not null,
  area text default ''::text not null,
  photo_url text,
  active boolean default true not null,
  lat double precision,
  lng double precision,
  created_at timestamp with time zone default now() not null,
  constraint packages_pkey PRIMARY KEY (id),
  constraint packages_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint packages_area_check CHECK ((char_length(area) <= 40)),
  constraint packages_category_check CHECK ((category = ANY (ARRAY['hospitality'::text, 'retail'::text, 'warehouse'::text, 'cleaning'::text, 'repairs'::text, 'garden'::text, 'moving'::text, 'care'::text, 'family'::text, 'lessons'::text, 'beauty'::text, 'events'::text, 'tech'::text, 'auto'::text, 'other'::text]))),
  constraint packages_description_check CHECK ((char_length(description) <= 800)),
  constraint packages_duration_check CHECK ((char_length(duration) <= 30)),
  constraint packages_price_check CHECK (((price >= (1)::numeric) AND (price < (100000)::numeric))),
  constraint packages_price_unit_check CHECK ((price_unit = ANY (ARRAY['total'::text, 'hour'::text]))),
  constraint packages_title_check CHECK (((char_length(title) >= 3) AND (char_length(title) <= 80)))
);

create table if not exists public.applications (
  id uuid default gen_random_uuid() not null,
  listing_id uuid not null,
  applicant_id uuid default auth.uid() not null,
  message text default ''::text not null,
  status text default 'pending'::text not null,
  created_at timestamp with time zone default now() not null,
  price numeric(10,2),
  price_unit text,
  completed_at timestamp with time zone,
  quoted_at timestamp with time zone,
  completed_by uuid,
  constraint applications_listing_id_applicant_id_key UNIQUE (listing_id, applicant_id),
  constraint applications_pkey PRIMARY KEY (id),
  constraint applications_applicant_id_fkey FOREIGN KEY (applicant_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint applications_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE,
  constraint applications_message_check CHECK ((char_length(message) <= 1000)),
  constraint applications_price CHECK (((price IS NULL) OR ((price >= (1)::numeric) AND (price < (100000)::numeric)))),
  constraint applications_price_unit CHECK ((((price IS NULL) AND (price_unit IS NULL)) OR ((price IS NOT NULL) AND (price_unit IS NOT NULL) AND (price_unit = ANY (ARRAY['total'::text, 'hour'::text]))))),
  constraint applications_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'accepted'::text, 'declined'::text, 'withdrawn'::text, 'invited'::text, 'cancelled'::text])))
);

create table if not exists public.messages (
  id uuid default gen_random_uuid() not null,
  application_id uuid not null,
  sender_id uuid default auth.uid() not null,
  body text not null,
  created_at timestamp with time zone default now() not null,
  constraint messages_pkey PRIMARY KEY (id),
  constraint messages_application_id_fkey FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  constraint messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint messages_body_check CHECK (((char_length(body) >= 1) AND (char_length(body) <= 2000)))
);

create table if not exists public.reviews (
  id uuid default gen_random_uuid() not null,
  application_id uuid not null,
  reviewer_id uuid default auth.uid() not null,
  reviewee_id uuid not null,
  stars integer not null,
  comment text default ''::text not null,
  created_at timestamp with time zone default now() not null,
  constraint reviews_application_id_reviewer_id_key UNIQUE (application_id, reviewer_id),
  constraint reviews_pkey PRIMARY KEY (id),
  constraint reviews_application_id_fkey FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  constraint reviews_reviewee_id_fkey FOREIGN KEY (reviewee_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint reviews_comment_check CHECK ((char_length(comment) <= 500)),
  constraint reviews_stars_check CHECK (((stars >= 1) AND (stars <= 5)))
);

create table if not exists public.favorites (
  user_id uuid default auth.uid() not null,
  listing_id uuid not null,
  created_at timestamp with time zone default now() not null,
  constraint favorites_pkey PRIMARY KEY (user_id, listing_id),
  constraint favorites_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE,
  constraint favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE
);

create table if not exists public.blocks (
  blocker_id uuid default auth.uid() not null,
  blocked_id uuid not null,
  created_at timestamp with time zone default now() not null,
  constraint blocks_pkey PRIMARY KEY (blocker_id, blocked_id),
  constraint blocks_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint blocks_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES profiles(id) ON DELETE CASCADE
);

create table if not exists public.reports (
  id uuid default gen_random_uuid() not null,
  listing_id uuid,
  reporter_id uuid default auth.uid() not null,
  reason text not null,
  created_at timestamp with time zone default now() not null,
  reported_user_id uuid,
  status text default 'open'::text not null,
  constraint reports_pkey PRIMARY KEY (id),
  constraint reports_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE,
  constraint reports_reported_user_id_fkey FOREIGN KEY (reported_user_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint reports_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint reports_reason_check CHECK (((char_length(reason) >= 1) AND (char_length(reason) <= 500))),
  constraint reports_target CHECK (((listing_id IS NOT NULL) OR (reported_user_id IS NOT NULL)))
);

create table if not exists public.notifications (
  id uuid default gen_random_uuid() not null,
  user_id uuid not null,
  type text not null,
  title text not null,
  body text default ''::text not null,
  link text default '/'::text not null,
  read boolean default false not null,
  created_at timestamp with time zone default now() not null,
  pushed_at timestamp with time zone,
  emailed_at timestamp with time zone,
  constraint notifications_pkey PRIMARY KEY (id),
  constraint notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE
);

create table if not exists public.push_subscriptions (
  endpoint text not null,
  user_id uuid default auth.uid() not null,
  subscription jsonb not null,
  created_at timestamp with time zone default now() not null,
  constraint push_subscriptions_pkey PRIMARY KEY (endpoint),
  constraint push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE
);

create table if not exists public.saved_searches (
  id uuid default gen_random_uuid() not null,
  user_id uuid default auth.uid() not null,
  label text default ''::text not null,
  kind text default 'all'::text not null,
  category text default 'all'::text not null,
  q text default ''::text not null,
  created_at timestamp with time zone default now() not null,
  constraint saved_searches_pkey PRIMARY KEY (id),
  constraint saved_searches_user_id_fkey FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE,
  constraint saved_searches_label_check CHECK ((char_length(label) <= 80)),
  constraint saved_searches_q_check CHECK ((char_length(q) <= 60))
);

create table if not exists public.shift_reminders (
  application_id uuid not null,
  sent_at timestamp with time zone default now() not null,
  constraint shift_reminders_pkey PRIMARY KEY (application_id),
  constraint shift_reminders_application_id_fkey FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
);

create table if not exists public.job_events (
  id uuid default gen_random_uuid() not null,
  application_id uuid not null,
  listing_id uuid not null,
  event text not null,
  actor_id uuid,
  reason text default ''::text not null,
  prev_completed_at timestamp with time zone,
  prev_completed_by uuid,
  created_at timestamp with time zone default now() not null,
  constraint job_events_pkey PRIMARY KEY (id),
  constraint job_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES profiles(id) ON DELETE SET NULL,
  constraint job_events_application_id_fkey FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  constraint job_events_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE,
  constraint job_events_event_check CHECK ((event = ANY (ARRAY['completed'::text, 'completion_reverted'::text, 'cancelled'::text]))),
  constraint job_events_reason_check CHECK ((char_length(reason) <= 500))
);

create table if not exists public.admin_actions (
  id uuid default gen_random_uuid() not null,
  actor_id uuid,
  action text not null,
  target_user uuid,
  target_listing uuid,
  target_report uuid,
  note text default ''::text not null,
  created_at timestamp with time zone default now() not null,
  constraint admin_actions_pkey PRIMARY KEY (id),
  constraint admin_actions_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES profiles(id) ON DELETE SET NULL,
  constraint admin_actions_note_check CHECK ((char_length(note) <= 500))
);

create table if not exists public.app_settings (
  key text not null,
  value text not null,
  updated_at timestamp with time zone default now() not null,
  updated_by uuid,
  constraint app_settings_pkey PRIMARY KEY (key),
  constraint app_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES auth.users(id) ON DELETE SET NULL
);

insert into public.app_settings (key, value) values ('support_email', 'info@artwin.co.uk') on conflict (key) do nothing;
