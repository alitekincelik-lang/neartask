-- ============================================================
-- NearTask – live database schema, exported 31 October 2026
-- Part 3: row level security, policies, triggers, indexes,
--         storage, realtime and scheduled jobs
-- ============================================================

-- ---------- Row level security ----------
-- (admin_actions, job_events, listing_views and shift_reminders have RLS on and
--  no policies on purpose: only security definer functions may touch them.)
alter table public.admin_actions enable row level security;
alter table public.app_settings enable row level security;
alter table public.applications enable row level security;
alter table public.blocks enable row level security;
alter table public.favorites enable row level security;
alter table public.job_events enable row level security;
alter table public.listing_private enable row level security;
alter table public.listing_views enable row level security;
alter table public.listings enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.packages enable row level security;
alter table public.profiles enable row level security;
alter table public.push_subscriptions enable row level security;
alter table public.reports enable row level security;
alter table public.reviews enable row level security;
alter table public.saved_searches enable row level security;
alter table public.shift_reminders enable row level security;

grant select on public.app_settings to anon, authenticated;

-- ---------- Policies ----------
create policy "app_settings public read" on public.app_settings as PERMISSIVE for SELECT to anon, authenticated
  using (true);

create policy "applications insert" on public.applications as PERMISSIVE for INSERT to public
  with check (((NOT is_banned()) AND (EXISTS ( SELECT 1
   FROM listings l
  WHERE ((l.id = applications.listing_id) AND (l.status = 'open'::text) AND (NOT blocked_between(l.owner_id, applications.applicant_id))))) AND (NOT (adult_only(listing_id) AND applicant_is_minor(applicant_id))) AND (((applicant_id = auth.uid()) AND (status = 'pending'::text) AND (NOT is_listing_owner(listing_id))) OR ((status = 'invited'::text) AND is_listing_owner(listing_id) AND (applicant_id <> auth.uid())))));

create policy "applications read" on public.applications as PERMISSIVE for SELECT to public
  using (((applicant_id = auth.uid()) OR is_listing_owner(listing_id)));

create policy "applications update" on public.applications as PERMISSIVE for UPDATE to public
  using (((applicant_id = auth.uid()) OR is_listing_owner(listing_id)));

create policy "blocks own" on public.blocks as PERMISSIVE for ALL to public
  using ((blocker_id = auth.uid()))
  with check ((blocker_id = auth.uid()));

create policy "favorites own" on public.favorites as PERMISSIVE for ALL to public
  using ((user_id = auth.uid()))
  with check ((user_id = auth.uid()));

create policy "address read" on public.listing_private as PERMISSIVE for SELECT to public
  using ((is_listing_owner(listing_id) OR (EXISTS ( SELECT 1
   FROM applications a
  WHERE ((a.listing_id = listing_private.listing_id) AND (a.applicant_id = auth.uid()) AND (a.status = 'accepted'::text))))));

create policy "address write" on public.listing_private as PERMISSIVE for ALL to public
  using (is_listing_owner(listing_id))
  with check (is_listing_owner(listing_id));

create policy "listings delete" on public.listings as PERMISSIVE for DELETE to public
  using ((owner_id = auth.uid()));

create policy "listings insert" on public.listings as PERMISSIVE for INSERT to public
  with check (((owner_id = auth.uid()) AND (NOT is_banned())));

create policy "listings read" on public.listings as PERMISSIVE for SELECT to public
  using (((status <> 'closed'::text) OR (owner_id = auth.uid())));

create policy "listings update" on public.listings as PERMISSIVE for UPDATE to public
  using ((owner_id = auth.uid()))
  with check (((owner_id = auth.uid()) AND (NOT is_banned())));

create policy "messages insert" on public.messages as PERMISSIVE for INSERT to public
  with check (((sender_id = auth.uid()) AND can_message(application_id)));

create policy "messages read" on public.messages as PERMISSIVE for SELECT to public
  using (is_participant(application_id));

create policy "notifications own read" on public.notifications as PERMISSIVE for SELECT to public
  using ((user_id = auth.uid()));

create policy "notifications own update" on public.notifications as PERMISSIVE for UPDATE to public
  using ((user_id = auth.uid()))
  with check ((user_id = auth.uid()));

create policy "packages delete" on public.packages as PERMISSIVE for DELETE to public
  using ((owner_id = auth.uid()));

create policy "packages insert" on public.packages as PERMISSIVE for INSERT to public
  with check (((owner_id = auth.uid()) AND (NOT is_banned())));

create policy "packages read" on public.packages as PERMISSIVE for SELECT to public
  using ((active OR (owner_id = auth.uid())));

create policy "packages update" on public.packages as PERMISSIVE for UPDATE to public
  using ((owner_id = auth.uid()))
  with check (((owner_id = auth.uid()) AND (NOT is_banned())));

create policy "profiles read" on public.profiles as PERMISSIVE for SELECT to public
  using (true);

create policy "profiles update own" on public.profiles as PERMISSIVE for UPDATE to public
  using ((id = auth.uid()))
  with check ((id = auth.uid()));

create policy "push own" on public.push_subscriptions as PERMISSIVE for ALL to public
  using ((user_id = auth.uid()))
  with check ((user_id = auth.uid()));

create policy "reports insert" on public.reports as PERMISSIVE for INSERT to public
  with check ((reporter_id = auth.uid()));

create policy "reviews insert" on public.reviews as PERMISSIVE for INSERT to public
  with check ((reviewer_id = auth.uid()));

create policy "reviews read" on public.reviews as PERMISSIVE for SELECT to public
  using (true);

create policy "saved searches own" on public.saved_searches as PERMISSIVE for ALL to public
  using ((user_id = auth.uid()))
  with check ((user_id = auth.uid()));

-- ---------- Storage (photos bucket) ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('photos', 'photos', true, 5242880, '{image/jpeg,image/png,image/webp}') on conflict (id) do nothing;

create policy "photos delete own" on storage.objects as PERMISSIVE for DELETE to authenticated
  using (((bucket_id = 'photos'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));

create policy "photos read" on storage.objects as PERMISSIVE for SELECT to public
  using ((bucket_id = 'photos'::text));

create policy "photos upload own folder" on storage.objects as PERMISSIVE for INSERT to authenticated
  with check (((bucket_id = 'photos'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));

-- ---------- Triggers ----------
CREATE TRIGGER application_auto_fill AFTER INSERT OR UPDATE OF status ON public.applications FOR EACH ROW EXECUTE FUNCTION auto_fill();
CREATE TRIGGER application_completion_guard BEFORE UPDATE ON public.applications FOR EACH ROW EXECUTE FUNCTION guard_completion_columns();
CREATE TRIGGER application_notify AFTER INSERT OR UPDATE OF status ON public.applications FOR EACH ROW EXECUTE FUNCTION on_application_notify();
CREATE TRIGGER application_stamp_quote BEFORE INSERT OR UPDATE ON public.applications FOR EACH ROW EXECUTE FUNCTION stamp_quote();
CREATE TRIGGER application_update_guard BEFORE UPDATE ON public.applications FOR EACH ROW EXECUTE FUNCTION check_application_update();
CREATE TRIGGER listing_alert AFTER INSERT ON public.listings FOR EACH ROW EXECUTE FUNCTION on_listing_alert();
CREATE TRIGGER listing_match AFTER INSERT ON public.listings FOR EACH ROW EXECUTE FUNCTION on_listing_match();
CREATE TRIGGER message_notify AFTER INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION on_message_notify();
CREATE TRIGGER notification_push AFTER INSERT ON public.notifications FOR EACH ROW EXECUTE FUNCTION on_notification_push();
CREATE TRIGGER profile_age_guard BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION guard_profile_age();
CREATE TRIGGER profile_round_location BEFORE INSERT OR UPDATE OF lat, lng ON public.profiles FOR EACH ROW EXECUTE FUNCTION round_profile_location();
CREATE TRIGGER report_stamp BEFORE INSERT ON public.reports FOR EACH ROW EXECUTE FUNCTION stamp_report();
CREATE TRIGGER review_guard BEFORE INSERT ON public.reviews FOR EACH ROW EXECUTE FUNCTION check_review();
CREATE TRIGGER review_rating AFTER INSERT ON public.reviews FOR EACH ROW EXECUTE FUNCTION refresh_rating();
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ---------- Indexes ----------
CREATE INDEX admin_actions_actor_idx ON public.admin_actions USING btree (actor_id);
CREATE INDEX applications_applicant ON public.applications USING btree (applicant_id);
CREATE INDEX blocks_blocked_idx ON public.blocks USING btree (blocked_id);
CREATE INDEX favorites_listing_idx ON public.favorites USING btree (listing_id);
CREATE INDEX job_events_actor_idx ON public.job_events USING btree (actor_id);
CREATE INDEX job_events_app ON public.job_events USING btree (application_id, created_at);
CREATE INDEX job_events_listing_idx ON public.job_events USING btree (listing_id);
CREATE INDEX listings_open_date ON public.listings USING btree (status, date);
CREATE INDEX listings_owner ON public.listings USING btree (owner_id);
CREATE INDEX messages_app ON public.messages USING btree (application_id, created_at);
CREATE INDEX messages_sender_idx ON public.messages USING btree (sender_id);
CREATE INDEX notifications_email_due ON public.notifications USING btree (created_at) WHERE ((emailed_at IS NULL) AND (read = false));
CREATE INDEX notifications_user ON public.notifications USING btree (user_id, created_at DESC);
CREATE INDEX packages_active ON public.packages USING btree (category) WHERE active;
CREATE INDEX packages_owner_idx ON public.packages USING btree (owner_id);
CREATE INDEX profiles_available ON public.profiles USING btree (available) WHERE available;
CREATE INDEX push_subscriptions_user_idx ON public.push_subscriptions USING btree (user_id);
CREATE INDEX reports_listing_idx ON public.reports USING btree (listing_id);
CREATE INDEX reports_reported_user_idx ON public.reports USING btree (reported_user_id);
CREATE INDEX reports_reporter_idx ON public.reports USING btree (reporter_id);
CREATE INDEX reviews_reviewee ON public.reviews USING btree (reviewee_id);
CREATE INDEX reviews_reviewer_idx ON public.reviews USING btree (reviewer_id);
CREATE INDEX saved_searches_user_idx ON public.saved_searches USING btree (user_id);

-- ---------- Realtime ----------
alter publication supabase_realtime add table public.applications;
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.notifications;

-- ---------- Scheduled jobs (pg_cron) ----------
select cron.schedule('neartask-close-past-listings', '20 * * * *', 'select public.close_past_listings()');
select cron.schedule('neartask-email-notifications', '*/5 * * * *', 'select public.send_due_emails()');
select cron.schedule('neartask-shift-reminders', '5 * * * *', 'select public.send_shift_reminders()');
