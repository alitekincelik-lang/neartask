// Small dependency-free map: OpenStreetMap tiles, drag to pan, buttons to zoom.
import { useEffect, useRef, useState, type ReactNode } from "react";
import type { LatLng } from "./geo";
import { Icon } from "./ui";

export interface Pin { id: string; lat: number; lng: number; color: string; label: string }

const T = 256;
const toPx = (p: LatLng, z: number) => {
  const s = T * 2 ** z, r = (p.lat * Math.PI) / 180;
  return { x: ((p.lng + 180) / 360) * s, y: ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * s };
};
const toLL = (x: number, y: number, z: number): LatLng => {
  const s = T * 2 ** z, n = Math.PI - (2 * Math.PI * y) / s;
  return { lng: (x / s) * 360 - 180, lat: (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))) };
};
// Spread pins that share a postcode district so each one can be tapped.
const jitter = (id: string, i: number) => {
  const h = [...id].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const ang = (h % 360) * (Math.PI / 180), rad = 0.0025 + (i % 5) * 0.0018;
  return { dlat: Math.sin(ang) * rad * 0.62, dlng: Math.cos(ang) * rad };
};

export function MiniMap({ pins, center, me, selected, onSelect, onMany, credit, children, height = 440 }: {
  pins: Pin[]; center: LatLng; me?: LatLng | null; selected: string | null; onSelect(id: string | null): void; onMany?(ids: string[]): void; credit: string; children?: ReactNode; height?: number;
}) {
  const box = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(360);
  const [z, setZ] = useState(12);
  const [c, setC] = useState(center);
  const drag = useRef<{ x: number; y: number; c: { x: number; y: number }; moved: boolean } | null>(null);

  useEffect(() => {
    const el = box.current!;
    const ro = new ResizeObserver(() => setW(el.clientWidth));
    ro.observe(el);
    setW(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const cp = toPx(c, z);
  const ox = cp.x - w / 2, oy = cp.y - height / 2;
  const tiles: ReactNode[] = [];
  const n = 2 ** z;
  for (let tx = Math.floor(ox / T); tx <= Math.floor((ox + w) / T); tx++)
    for (let ty = Math.floor(oy / T); ty <= Math.floor((oy + height) / T); ty++) {
      if (ty < 0 || ty >= n) continue;
      const wx = ((tx % n) + n) % n;
      tiles.push(<img key={z + "/" + tx + "/" + ty} className="tile" alt="" draggable={false} src={`https://tile.openstreetmap.org/${z}/${wx}/${ty}.png`}
        style={{ left: tx * T - ox, top: ty * T - oy }} onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} />);
    }

  const down = (e: React.PointerEvent) => { (e.target as Element).setPointerCapture?.(e.pointerId); drag.current = { x: e.clientX, y: e.clientY, c: cp, moved: false }; };
  const move = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) d.moved = true;
    if (d.moved) setC(toLL(d.c.x - dx, d.c.y - dy, z));
  };
  const up = (e: React.PointerEvent) => {
    const d = drag.current;
    drag.current = null;
    if (d && !d.moved && (e.target as HTMLElement).classList.contains("mapsurface")) onSelect(null);
  };
  const zoom = (dz: number) => setZ((x) => Math.max(9, Math.min(16, x + dz)));

  return (
    <div className="map" ref={box} style={{ height }}>
      <div className="mapsurface" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={() => (drag.current = null)}>
        {tiles}
        {me && (() => { const p = toPx(me, z); return <span className="mepin" style={{ left: p.x - ox, top: p.y - oy }} />; })()}
        {(() => {
          // Group pins that would overlap at this zoom level; tapping a group zooms in on it.
          const pts = pins.map((p, i) => { const j = jitter(p.id, i); const q = toPx({ lat: p.lat + j.dlat, lng: p.lng + j.dlng }, z); return { p, x: q.x - ox, y: q.y - oy }; });
          const groups: { x: number; y: number; items: typeof pts }[] = [];
          for (const pt of pts) {
            const g = groups.find((g) => Math.abs(g.x - pt.x) < 46 && Math.abs(g.y - pt.y) < 26);
            if (g) { g.items.push(pt); g.x = (g.x * (g.items.length - 1) + pt.x) / g.items.length; g.y = (g.y * (g.items.length - 1) + pt.y) / g.items.length; }
            else groups.push({ x: pt.x, y: pt.y, items: [pt] });
          }
          return groups.map((g) => {
            if (g.items.length === 1) {
              const { p, x, y } = g.items[0];
              const on = selected === p.id;
              return (
                <button key={p.id} className={"pin" + (on ? " on" : "")} style={{ left: x, top: y, ["--pc" as any]: p.color }}
                  onPointerDown={(e) => e.stopPropagation()} onClick={() => onSelect(p.id)} aria-label={p.label}>
                  <span>{p.label}</span>
                </button>
              );
            }
            return (
              <button key={"g" + g.items[0].p.id} className="cluster" style={{ left: g.x, top: g.y }} onPointerDown={(e) => e.stopPropagation()}
                onClick={() => {
                  // Same spot even when zoomed in: show the listings as a list instead.
                  if (z >= 14 && onMany) onMany(g.items.map((i) => i.p.id));
                  else { setC(toLL(g.x + ox, g.y + oy, z)); setZ((v) => Math.min(16, v + 2)); }
                }} aria-label={g.items.length + " listings"}>
                {g.items.length}
              </button>
            );
          });
        })()}
      </div>
      <div className="mapzoom">
        <button onClick={() => zoom(1)} aria-label="Zoom in"><Icon name="plus" /></button>
        <button onClick={() => zoom(-1)} aria-label="Zoom out"><span className="minus" /></button>
        {me && <button onClick={() => { setC(me); setZ(13); }} aria-label="Centre"><Icon name="pin" /></button>}
      </div>
      <span className="mapcredit">{credit}</span>
      {children}
    </div>
  );
}
