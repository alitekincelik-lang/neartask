// Legal details shown in the app, the privacy policy and the terms.
// The support email comes from public.app_settings ('support_email'), which admins
// change in Admin panel → Settings. Until it loads, the last known value (or the default) is used.
const DEFAULT_SUPPORT_EMAIL = "info@artwin.co.uk";

let supportEmail = DEFAULT_SUPPORT_EMAIL;
try {
  const cached = localStorage.getItem("nt_support_email");
  if (cached) supportEmail = cached;
} catch { /* storage blocked */ }

export function setSupportEmail(v: string) {
  supportEmail = v;
  try { localStorage.setItem("nt_support_email", v); } catch { /* storage blocked */ }
}

// Reads the current support email from Supabase without signing in (the table is public read).
export async function loadSupportEmail(url?: string, anonKey?: string) {
  if (!url || !anonKey) return;
  try {
    const r = await fetch(`${url}/rest/v1/app_settings?key=eq.support_email&select=value`, {
      headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}` },
    });
    if (!r.ok) return;
    const d = (await r.json()) as { value?: string }[];
    if (d?.[0]?.value) setSupportEmail(d[0].value);
  } catch { /* offline: keep the cached value */ }
}

export const COMPANY = {
  name: "Artwin Ltd",
  number: "13371113", // Companies House number
  address: "Office 408, Screenworks, 22 Highbury Grove, London N5 2ER", // Registered office address
  get email() { return supportEmail; },
  ico: "", // ICO registration number, once registered
  updated: "28 October 2026",
};
