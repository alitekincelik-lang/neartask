export type Kind = "job" | "service";
// Broad main headings. Specific trades (plumbing, tutoring, dog walking…) live inside a heading and its smart questions.
export const CATEGORIES = ["hospitality", "retail", "warehouse", "cleaning", "repairs", "garden", "moving", "care", "family", "lessons", "beauty", "events", "tech", "auto", "other"] as const;
export type Category = (typeof CATEGORIES)[number];
export type ListingStatus = "open" | "filled" | "closed";
export type AppStatus = "pending" | "accepted" | "declined" | "withdrawn" | "invited";
export const DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;

export interface Profile {
  id: string;
  name: string;
  postcode: string;
  bio: string;
  avatar_url: string | null;
  rating_avg: number;
  rating_count: number;
  verified: boolean;
  created_at: string;
  account_type: "person" | "business";
  headline: string;
  skills: string[];
  available: boolean;
  available_days: string[];
  lat: number | null;
  lng: number | null;
  is_admin?: boolean;
  banned?: boolean;
  portfolio?: string[];
  match_alerts?: boolean;
  age_group?: AgeGroup | null;
}
export type AgeGroup = "16-17" | "18+";

/** Public track record shown on a profile. */
export interface ProfileStats { jobs_done: number; hires: number; reply_minutes: number | null }
export type PriceUnit = "total" | "hour";
export interface Quote { price: number; unit: PriceUnit }
/** Typical quotes for a category (25th, 50th and 75th percentile). */
export interface PriceGuide { n: number; unit: PriceUnit; low: number; mid: number; high: number }
/** A fixed-price service a helper offers, bookable in one step. */
export interface Package {
  id: string;
  owner_id: string;
  category: Category;
  title: string;
  description: string;
  price: number;
  price_unit: PriceUnit;
  duration: string;
  area: string;
  photo_url: string | null;
  active: boolean;
  created_at: string;
  owner?: Profile;
  distance?: number;
}
export type PackageInput = Pick<Package, "category" | "title" | "description" | "price" | "price_unit" | "duration" | "area" | "photo_url" | "active"> & { id?: string };
export interface Booking { packageId: string; date: string; time: string | null; address: string; note: string }

export interface AdminOverview { users: number; businesses: number; seekers: number; open_listings: number; applications: number; messages_7d: number; new_users_7d: number; open_reports: number }
export interface AdminReport {
  id: string; reason: string; status: string; created_at: string; listing_id: string | null; reported_user_id: string | null;
  listing_title: string | null; listing_status: string | null; listing_owner: string | null;
  reporter_name: string | null; reported_name: string | null; reported_banned: boolean | null;
}

export type ProfileInput = Pick<Profile, "name" | "postcode" | "bio" | "avatar_url" | "account_type" | "headline" | "skills" | "available" | "available_days" | "lat" | "lng"> & { portfolio?: string[]; match_alerts?: boolean; age_group?: AgeGroup | null };

export interface Listing {
  id: string;
  owner_id: string;
  kind: Kind;
  title: string;
  category: Category;
  area: string;
  date: string; // YYYY-MM-DD
  start_time: string | null; // HH:MM
  end_time: string | null;
  pay: string;
  description: string;
  requirements: string;
  photo_url: string | null;
  status: ListingStatus;
  created_at: string;
  positions: number;
  views: number;
  lat: number | null;
  lng: number | null;
  details?: Record<string, string> | null;
  notified?: number;
  booked_package?: string | null;
  owner?: Profile;
  distance?: number;
}

export interface ListingInput {
  id?: string;
  kind: Kind;
  title: string;
  category: Category;
  area: string;
  date: string;
  start_time: string | null;
  end_time: string | null;
  pay: string;
  description: string;
  requirements: string;
  photo_url: string | null;
  status?: ListingStatus;
  address: string;
  positions: number;
  lat?: number | null;
  lng?: number | null;
  details?: Record<string, string>;
}

export interface Application {
  id: string;
  listing_id: string;
  applicant_id: string;
  message: string;
  price?: number | null;
  price_unit?: PriceUnit | null;
  completed_at?: string | null;
  quoted_at?: string | null;
  status: AppStatus;
  created_at: string;
  listing?: Listing;
  applicant?: Profile;
}

export interface Message {
  id: string;
  application_id: string;
  sender_id: string;
  body: string;
  created_at: string;
}

export interface Review {
  id: string;
  application_id: string;
  reviewer_id: string;
  reviewee_id: string;
  stars: number;
  comment: string;
  created_at: string;
  reviewer?: Profile;
}

export interface Thread {
  app: Application;
  listing: Listing;
  other: Profile;
  last: Message | null;
  mineIsOwner: boolean;
}

export interface Notice {
  id: string;
  type: string;
  title: string;
  body: string;
  link: string;
  read: boolean;
  created_at: string;
}

export interface SavedSearch {
  id: string;
  label: string;
  kind: string;
  category: string;
  q: string;
  created_at: string;
}

export interface Stats { seekers: number; businesses: number; listings: number }

export interface ListingStats { listing: Listing; applicants: number; pending: number; accepted: number }

export type When = "any" | "today" | "tomorrow" | "week";
export interface Filters {
  kind: Kind | "all";
  when: When;
  category: Category | "all";
  q: string;
  sort: "soon" | "new" | "near";
  near?: { lat: number; lng: number } | null;
}

export interface Api {
  mode: "demo" | "live";
  currentUser(): Promise<string | null>;
  onAuthChange(cb: (uid: string | null) => void): () => void;
  signUp(email: string, password: string): Promise<"ok" | "confirm">;
  signIn(email: string, password: string): Promise<void>;
  resetPassword(email: string): Promise<void>;
  updatePassword(password: string): Promise<void>;
  onRecovery(cb: () => void): () => void;
  sendCode(email: string): Promise<void>;
  verifyCode(email: string, code: string): Promise<void>;
  signOut(): Promise<void>;

  getProfile(id: string): Promise<Profile | null>;
  profileStats(id: string): Promise<ProfileStats>;
  saveProfile(p: ProfileInput): Promise<void>;
  listWorkers(skill: string, near?: { lat: number; lng: number } | null): Promise<Profile[]>;
  stats(): Promise<Stats>;

  listListings(f: Filters): Promise<Listing[]>;
  getListing(id: string): Promise<Listing | null>;
  myListings(): Promise<Listing[]>;
  saveListing(l: ListingInput): Promise<string>;
  setListingStatus(id: string, status: ListingStatus): Promise<void>;
  deleteListing(id: string): Promise<void>;
  getAddress(listingId: string): Promise<string | null>;
  uploadPhoto(file: File): Promise<string>;
  viewListing(id: string): Promise<void>;
  dashboard(): Promise<ListingStats[]>;
  invite(listingId: string, workerId: string, message: string): Promise<string>;

  apply(listingId: string, message: string, quote?: Quote | null): Promise<string>;
  myApplications(): Promise<Application[]>;
  applicationsFor(listingId: string): Promise<Application[]>;
  getApplication(id: string): Promise<Application | null>;
  setApplicationStatus(id: string, status: AppStatus): Promise<void>;
  completeJob(appId: string): Promise<void>;
  updateQuote(appId: string, quote: Quote): Promise<void>;
  reportJobProblem(appId: string, reason: string): Promise<void>;
  priceGuide(category: Category): Promise<PriceGuide | null>;

  listPackages(f: { category?: Category | "all"; owner?: string; near?: { lat: number; lng: number } | null }): Promise<Package[]>;
  getPackage(id: string): Promise<Package | null>;
  savePackage(p: PackageInput): Promise<string>;
  deletePackage(id: string): Promise<void>;
  bookPackage(b: Booking): Promise<string>;

  threads(): Promise<Thread[]>;
  messages(appId: string): Promise<Message[]>;
  send(appId: string, body: string): Promise<void>;
  subscribe(appId: string, cb: () => void): () => void;
  subscribeAll(cb: () => void): () => void;

  favorites(): Promise<string[]>;
  toggleFavorite(listingId: string): Promise<boolean>;

  review(appId: string, revieweeId: string, stars: number, comment: string): Promise<void>;
  reviewsFor(userId: string): Promise<Review[]>;
  myReview(appId: string): Promise<Review | null>;

  report(listingId: string, reason: string): Promise<void>;

  notifications(): Promise<Notice[]>;
  markAllRead(): Promise<void>;
  onNotification(cb: (n: Notice) => void): () => void;
  savedSearches(): Promise<SavedSearch[]>;
  saveSearch(s: Pick<SavedSearch, "label" | "kind" | "category" | "q">): Promise<void>;
  deleteSearch(id: string): Promise<void>;
  savePush?(sub: PushSubscriptionJSON): Promise<void>;

  deleteAccount(): Promise<void>;
  blockedIds(): Promise<string[]>;
  blockedProfiles(): Promise<Profile[]>;
  block(userId: string): Promise<void>;
  unblock(userId: string): Promise<void>;
  reportUser(userId: string, reason: string): Promise<void>;

  adminOverview(): Promise<AdminOverview>;
  adminReports(): Promise<AdminReport[]>;
  adminResolveReport(id: string, status: "resolved" | "dismissed"): Promise<void>;
  adminSetListingStatus(id: string, status: ListingStatus): Promise<void>;
  adminSetVerified(userId: string, v: boolean): Promise<void>;
  adminSetBanned(userId: string, v: boolean): Promise<void>;
  adminSearch(q: string): Promise<Profile[]>;
  adminSetSetting(key: "support_email", value: string): Promise<void>;
  resetDemo?(): void;
}
