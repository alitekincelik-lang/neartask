// Basic filter for clearly abusive words, as app stores require for user-generated content.
// It is intentionally short: reports, blocking and admin review do the rest.
const WORDS = [
  "fuck", "fucking", "cunt", "nigger", "nigga", "faggot", "retard", "whore", "slut", "twat", "wanker", "bastard", "dickhead", "motherfucker", "paki", "spastic",
];
const RE = new RegExp("\\b(" + WORDS.join("|") + ")\\b", "i");
export const isOffensive = (text: string) => RE.test(text.replace(/[^\p{L}\s]/gu, " "));
