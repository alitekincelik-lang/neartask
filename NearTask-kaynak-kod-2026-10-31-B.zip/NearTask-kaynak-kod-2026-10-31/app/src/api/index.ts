import type { Api } from "../types";
import { createDemoApi } from "./demo";

/** Live mode when Supabase keys are set (see .env.example), otherwise demo mode. */
export async function loadApi(): Promise<Api> {
  const url = import.meta.env?.VITE_SUPABASE_URL as string | undefined;
  const key = import.meta.env?.VITE_SUPABASE_ANON_KEY as string | undefined;
  if (url && key && !url.includes("YOUR-PROJECT")) {
    const { createSupabaseApi } = await import("./supabase");
    return createSupabaseApi(url, key);
  }
  return createDemoApi();
}
