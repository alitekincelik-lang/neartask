// Demo mode: a complete fake backend that lives in the browser.
// Sample people answer your messages, accept invites and post new listings, so every flow can be tried without a server.
import type { AdminReport, Api, Application, AppStatus, Category, Listing, ListingInput, Message, Notice, Package, Profile, Review, SavedSearch, Thread, Filters, ListingStatus, PriceGuide } from "../types";
import { applyFilters, blobToDataUrl, lsGet, lsSet, shrinkImage, today, uid } from "../util";
import { km, locate } from "../geo";
import { adultOnly, adultOnlyPackage, quoteExpired } from "../categories";

const KEY = "neartask_demo_v5";
const ME = "me";

type SeedListing = Listing & { offset?: number };
interface DB {
  v: 5;
  session: string | null;
  users: Profile[];
  listings: SeedListing[];
  priv: Record<string, string>;
  apps: Application[];
  msgs: Message[];
  favs: Record<string, string[]>;
  reviews: Review[];
  reports: { listing_id: string; reason: string }[];
  bot: Record<string, number>;
  notices: Notice[];
  searches: SavedSearch[];
  blocks: string[];
  reports2: AdminReport[];
  packages: Package[];
  matchedSkills?: string[];
  mineSeeded?: boolean;
}

const ago = (mins: number) => new Date(Date.now() - mins * 60000).toISOString();

// Sample quote history so the price guide has something to show in demo mode.
const SAMPLE_QUOTES: Partial<Record<Category, number[]>> = {
  cleaning: [60, 75, 80, 95, 110, 120, 140], repairs: [40, 55, 60, 80, 95, 120], garden: [35, 45, 60, 70, 90],
  moving: [40, 60, 80, 120, 180], lessons: [25, 28, 30, 35, 40], family: [10, 12, 12, 15, 18], tech: [30, 40, 45, 60],
  care: [20, 25, 30, 35], beauty: [30, 40, 45, 60], events: [150, 250, 300, 450], auto: [20, 35, 40, 60],
};
const HOURLY: Category[] = ["lessons"];
function quantile(xs: number[], q: number) {
  const a = [...xs].sort((x, y) => x - y), i = (a.length - 1) * q, lo = Math.floor(i), hi = Math.ceil(i);
  return Math.round(a[lo] + (a[hi] - a[lo]) * (i - lo));
}
function seedPackages(): Package[] {
  const P = (id: string, owner_id: string, category: Category, title: string, description: string, price: number, price_unit: "total" | "hour", duration: string, area: string): Package =>
    ({ id, owner_id, category, title, description, price, price_unit, duration, area, photo_url: null, active: true, created_at: ago(60 * 24 * 10) });
  return [
    P("p1", "maria", "cleaning", "Regular home clean", "Kitchen, bathroom, hoovering and dusting. I bring all products.", 45, "total", "3 hours", "Keynsham BS31"),
    P("p2", "maria", "cleaning", "End of tenancy clean (2-bed)", "Full deep clean including oven and inside windows.", 140, "total", "5 hours", "Keynsham BS31"),
    P("p3", "olu", "repairs", "Handyman by the hour", "Shelves, curtain rails, flat-pack, small fixes. Own tools.", 25, "hour", "1 hour minimum", "Bath BA1"),
    P("p4", "olu", "garden", "Hedge trim & tidy", "Small to medium hedges, clippings taken away.", 60, "total", "Half a day", "Bath BA1"),
    P("p5", "sam", "family", "Dog walk (1 hour)", "Group of up to 3 dogs, collection from your door.", 12, "total", "1 hour", "Keynsham BS31"),
    P("p6", "lucy", "lessons", "GCSE maths lesson", "Exam-focused lessons, homework help, past papers.", 30, "hour", "1 hour", "Keynsham BS31"),
    P("p7", "jake", "moving", "Man with a van", "Single items or small moves, two pairs of hands available.", 40, "hour", "2 hour minimum", "Bristol BS30"),
  ];
}
function person(id: string, name: string, postcode: string, o: Partial<Profile> = {}): Profile {
  const p = locate(postcode);
  return {
    id, name, postcode, bio: "", avatar_url: null, rating_avg: 0, rating_count: 0, verified: false, created_at: ago(60 * 24 * 120),
    account_type: "person", headline: "", skills: [], available: false, available_days: [], lat: p?.lat ?? null, lng: p?.lng ?? null, ...o,
  };
}
const WEEKDAYS = ["mon", "tue", "wed", "thu", "fri"], WEEKEND = ["sat", "sun"];
// Simple illustrated "work photos" for sample profiles (SVG data URLs, no network needed).
const tile = (bg: string, fg: string, path: string) =>
  "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" fill="${bg}"/><path d="${path}" fill="none" stroke="${fg}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>`);
const SAMPLE_WORK = [
  tile("#E8F0FE", "#2F6FDB", "M30 85h60M38 85V50h44v35M50 50V38h20v12"),
  tile("#E3F3F2", "#0E7C7B", "M25 80l25-30 15 18 10-12 20 24z"),
  tile("#FFF3D6", "#A86A00", "M40 30h40v60H40zM40 50h40M40 70h40"),
  tile("#E6F4E3", "#3E8E41", "M60 95V55M60 60c0-15-12-25-27-25 0 15 10 25 27 25zM60 68c0-12 10-22 25-22 0 12-10 22-25 22z"),
  tile("#FDEDE4", "#D35F2E", "M25 45h50v35H25zM75 58h15l8 10v12H75"),
];

function seed(): DB {
  const biz = { account_type: "business" as const, verified: true };
  const users = [
    person(ME, "", ""),
    person("hotel", "Keynsham Hotel (sample)", "BS31", { ...biz, bio: "Busy country-house hotel and restaurant.", rating_avg: 4.8, rating_count: 23 }),
    person("cafe", "Riverside Café (sample)", "BS31", { ...biz, bio: "Family café by the river.", rating_avg: 4.6, rating_count: 11 }),
    person("trade", "Unit 4 Trade Supplies (sample)", "BS31", { account_type: "business", bio: "Building and trade supplies.", rating_avg: 4.3, rating_count: 7 }),
    person("pub", "The Lock Keeper (sample)", "BS31", { ...biz, bio: "Riverside pub and kitchen.", rating_avg: 4.5, rating_count: 9 }),
    person("anna", "Anna (sample)", "BS31", { bio: "Saltford homeowner.", rating_avg: 4.9, rating_count: 5 }),
    person("david", "David (sample)", "BA2", { bio: "Moving house in Bath.", rating_avg: 4.5, rating_count: 2 }),
    person("helen", "Helen (sample)", "BS31", { bio: "Retired teacher, needs a hand now and then.", rating_avg: 5, rating_count: 9 }),
    person("tom", "Tom (sample)", "BS31", { headline: "Experienced waiter and bar staff", bio: "5 years in hotels and restaurants. Food hygiene level 2.", skills: ["hospitality"], available: true, available_days: ["fri", "sat", "sun"], rating_avg: 4.7, rating_count: 14, verified: true }),
    person("priya", "Priya (sample)", "BS4", { headline: "Student, evenings and weekends", bio: "Friendly, reliable and quick to learn.", skills: ["hospitality", "cleaning"], available: true, available_days: [...WEEKEND, "wed"], rating_avg: 4.4, rating_count: 3 }),
    person("jake", "Jake (sample)", "BS30", { headline: "Warehouse and moving, own van", bio: "Forklift licence. Happy to lift.", skills: ["warehouse", "moving"], available: true, available_days: WEEKDAYS, rating_avg: 4.8, rating_count: 21, verified: true }),
    person("maria", "Maria (sample)", "BS31", { headline: "Professional cleaner", bio: "Homes and holiday lets. Brings own supplies.", skills: ["cleaning", "care"], available: true, available_days: ["mon", "tue", "thu", "sat"], rating_avg: 4.9, rating_count: 32, verified: true, portfolio: SAMPLE_WORK.slice(0, 3) }),
    person("olu", "Olu (sample)", "BA1", { headline: "Handyman and gardener", bio: "Small repairs, flat-pack, hedges and lawns.", skills: ["repairs", "garden"], available: true, available_days: [...WEEKDAYS, "sat"], rating_avg: 4.6, rating_count: 12, portfolio: SAMPLE_WORK.slice(3) }),
    person("lucy", "Lucy (sample)", "BS31", { headline: "Maths & science tutor", bio: "Qualified teacher. GCSE and A-level, in person or online.", skills: ["lessons"], available: true, available_days: ["mon", "wed", "thu"], rating_avg: 5, rating_count: 17, verified: true }),
    person("sam", "Sam (sample)", "BS31", { headline: "Dog walker & pet sitter", bio: "Insured, DBS checked. Small groups only.", skills: ["family"], available: true, available_days: WEEKDAYS, rating_avg: 4.9, rating_count: 26 }),
    person("sophie", "Sophie (sample)", "BS14", { headline: "Chef de partie", bio: "Kitchen experience in busy hotels.", skills: ["hospitality"], available: true, available_days: ["thu", "fri", "sat"], rating_avg: 4.7, rating_count: 6 }),
    person("ben", "Ben (sample)", "BA2", { headline: "Carer and errands", bio: "DBS checked. Shopping, lifts, companionship.", skills: ["care"], available: true, available_days: WEEKDAYS, rating_avg: 5, rating_count: 8 }),
  ];
  const L = (id: string, owner_id: string, kind: "job" | "service", title: string, category: any, area: string, offset: number,
    start: string | null, end: string | null, pay: string, description: string, requirements: string, created: number, positions = 1, views = 0, details: Record<string, string> = {}): SeedListing => {
    const p = locate(area);
    return { id, owner_id, kind, title, category, area, offset, date: today(offset), start_time: start, end_time: end, pay, description,
      requirements, photo_url: null, status: "open", created_at: ago(created), positions, views, lat: p?.lat ?? null, lng: p?.lng ?? null, details };
  };
  const listings = [
    L("s1", "hotel", "job", "Waiter, evening shift", "hospitality", "Keynsham BS31", 1, "18:00", "22:00", "£13.50/hr",
      "Serve dinner in a busy hotel restaurant. Friendly team, staff meal included.", "Right to work in the UK. Smart black clothes.", 40, 2, 37),
    L("s2", "cafe", "job", "Kitchen porter", "hospitality", "Keynsham BS31", 0, "12:00", "16:00", "£12.80/hr",
      "Wash up and help keep the kitchen clean over the lunch rush.", "Right to work in the UK.", 90, 1, 22),
    L("s3", "trade", "job", "Warehouse packer", "warehouse", "Keynsham BS31", 3, "08:00", "14:00", "£12.50/hr",
      "Pick and pack trade orders. Light lifting, steel toe-caps provided.", "Right to work in the UK.", 300, 3, 51),
    L("s4", "anna", "service", "Garden tidy-up", "garden", "Saltford BS31", 5, "09:00", "12:00", "£60",
      "Cut the hedge and clear leaves from a small front garden. Tools provided.", "Own transport helpful.", 200, 1, 14, { task: "Hedges & trimming", size: "Small", waste: "Yes", frequency: "One-off" }),
    L("s5", "helen", "service", "House clean, 3 hours", "cleaning", "Keynsham BS31", 1, "10:00", "13:00", "£45",
      "Two-bed flat, kitchen and bathroom focus.", "Please bring your own supplies.", 25, 1, 9, { type: "Regular clean", size: "2 bedrooms", supplies: "Cleaner brings them", frequency: "Fortnightly" }),
    L("s6", "david", "service", "Help moving a sofa", "moving", "Bath BA2", 0, "14:00", "15:00", "£30",
      "Move a sofa from a ground-floor flat to a van. Two people needed.", "Able to lift.", 15, 2, 18),
    L("s7", "hotel", "job", "Housekeeping assistant", "hospitality", "Keynsham BS31", 2, "09:00", "14:00", "£12.60/hr",
      "Prepare guest rooms to a high standard. Training given.", "Right to work in the UK.", 120, 2, 29),
    L("s8", "helen", "service", "Fix a dripping tap", "repairs", "Keynsham BS31", 4, null, null, "£40",
      "Kitchen mixer tap drips constantly. Probably needs a new cartridge.", "Basic plumbing tools.", 500, 1, 6, { trade: "Plumbing", size: "Small (under 2 hours)", materials: "Tradesperson supplies them" }),
    L("s9", "pub", "job", "Bar staff, Saturday", "hospitality", "Keynsham BS31", 6, "17:00", "23:00", "£12.70/hr + tips",
      "Pull pints and serve food on our busiest night.", "Right to work in the UK. 18+.", 60, 2, 12),
    L("s10", "cafe", "job", "Barista, weekend mornings", "hospitality", "Bristol BS4", 5, "07:30", "12:30", "£12.60/hr",
      "Make coffee and serve breakfast at our Bristol branch.", "Barista experience preferred.", 400, 1, 20),
    L("s11", "ben", "service", "Weekly shopping trip", "care", "Bath BA1", 3, "10:00", "12:00", "£25",
      "Drive an elderly neighbour to the supermarket and help carry bags.", "Car and clean licence.", 80, 1, 4),
    L("s12", "anna", "service", "GCSE maths tutor for Year 10", "lessons", "Saltford BS31", 6, "17:00", "18:00", "£30/hr",
      "Weekly session to build confidence before mocks.", "DBS check.", 140, 1, 11, { subject: "Maths", level: "GCSE", format: "Either", frequency: "Weekly" }),
    L("s13", "david", "service", "Dog walker, weekday lunchtimes", "family", "Bath BA2", 2, "12:00", "13:00", "£12 a walk",
      "Friendly spaniel, 1 hour walk, Monday to Friday.", "Experience with dogs.", 220, 1, 15, { help: "Dog walking", count: "1", dbs: "No", frequency: "Weekly" }),
    L("s14", "helen", "service", "Laptop set-up and printer help", "tech", "Keynsham BS31", 3, null, null, "£40",
      "New laptop needs setting up, files moved over and the printer connected.", "", 160, 1, 5, { help: "Computer / phone help", format: "In person" }),
  ];
  const addr = "(sample address)";
  const priv: Record<string, string> = Object.fromEntries(listings.map((l) => [l.id, l.area + " " + addr]));
  const reviews: Review[] = [
    { id: "r1", application_id: "x", reviewer_id: "tom", reviewee_id: "hotel", stars: 5, comment: "Well organised and paid on time.", created_at: ago(9000) },
    { id: "r2", application_id: "x", reviewer_id: "priya", reviewee_id: "cafe", stars: 4, comment: "Nice team, busy lunch.", created_at: ago(20000) },
    { id: "r3", application_id: "x", reviewer_id: "hotel", reviewee_id: "tom", stars: 5, comment: "Excellent with guests.", created_at: ago(15000) },
    { id: "r4", application_id: "x", reviewer_id: "helen", reviewee_id: "maria", stars: 5, comment: "Spotless. Will book again.", created_at: ago(5000) },
    { id: "r5", application_id: "x", reviewer_id: "trade", reviewee_id: "jake", stars: 5, comment: "Hard worker, on time every day.", created_at: ago(7000) },
  ];
  return { v: 5, session: null, packages: seedPackages(), users, listings, priv, apps: [], msgs: [], favs: {}, reviews, reports: [], bot: {}, notices: [], searches: [], blocks: [], reports2: [] };
}

export function createDemoApi(): Api {
  let db: DB = lsGet<DB | null>(KEY, null) || seed();
  if (db.v !== 5) db = seed();
  db.blocks = db.blocks || [];
  db.reports2 = db.reports2 || [];
  db.listings.forEach((l) => { if (l.offset !== undefined) l.date = today(l.offset); });
  const save = () => lsSet(KEY, db);
  save();

  const subs = new Map<string, Set<() => void>>();
  const allSubs = new Set<() => void>();
  const authSubs = new Set<(u: string | null) => void>();
  const noticeSubs = new Set<(n: Notice) => void>();
  const emit = (appId: string) => { subs.get(appId)?.forEach((f) => f()); allSubs.forEach((f) => f()); };

  const user = (id: string) => db.users.find((u) => u.id === id)!;
  const withOwner = (l: Listing): Listing => ({ ...l, owner: user(l.owner_id) });
  const listing = (id: string) => db.listings.find((l) => l.id === id);
  const need = () => { if (!db.session) throw new Error("auth"); return db.session; };
  const fullApp = (a: Application): Application => ({ ...a, listing: withOwner(listing(a.listing_id)!), applicant: user(a.applicant_id) });
  const later = (ms: number, fn: () => void) => setTimeout(fn, ms);
  const short = (n: string) => n.replace(/\s*\(sample\)/, "");

  function notify(userId: string, type: string, title: string, body: string, link: string) {
    if (userId !== ME) return;
    const n: Notice = { id: uid(), type, title, body: body.slice(0, 140), link, read: false, created_at: new Date().toISOString() };
    db.notices.unshift(n);
    save();
    noticeSubs.forEach((f) => f(n));
  }
  function post(appId: string, sender: string, body: string) {
    db.msgs.push({ id: uid(), application_id: appId, sender_id: sender, body, created_at: new Date().toISOString() });
    const a = db.apps.find((x) => x.id === appId);
    if (a) {
      const l = listing(a.listing_id)!;
      const to = sender === a.applicant_id ? l.owner_id : a.applicant_id;
      notify(to, "message", short(user(sender).name) + " · " + l.title, body, "/chat/" + appId);
    }
    save();
    emit(appId);
  }
  function setStatus(a: Application, status: AppStatus) {
    const old = a.status;
    a.status = status;
    const l = listing(a.listing_id)!;
    if (status === "accepted" && l.status === "open" && db.apps.filter((x) => x.listing_id === l.id && x.status === "accepted").length >= (l.positions || 1)) l.status = "filled";
    if (old === "pending" && (status === "accepted" || status === "declined"))
      notify(a.applicant_id, status, (status === "accepted" ? "Accepted: " : "Declined: ") + l.title, "", "/chat/" + a.id);
    if (old === "invited" && (status === "accepted" || status === "declined"))
      notify(l.owner_id, status, short(user(a.applicant_id).name) + " " + status + " your invite", l.title, "/chat/" + a.id);
    save();
    emit(a.id);
  }

  /** Demo version of the server's automatic matching: nearby helpers who picked this category. */
  function matchHelpers(category: string, kind: string, at: { lat: number | null; lng: number | null }, owner: string) {
    return db.users.filter((u) => u.id !== owner && u.id !== ME && u.skills.includes(category) && (kind === "service" || u.available) &&
      (at.lat == null || u.lat == null || km({ lat: at.lat, lng: at.lng! }, { lat: u.lat, lng: u.lng! }) <= 20));
  }
  /** A couple of matched sample helpers reply to your new request, so you can see matching and quotes working. */
  function simulateReplies(listingId: string, helpers: Profile[]) {
    helpers.slice(0, 2).forEach((h, i) => later(3500 + i * 3500, () => {
      const l = listing(listingId);
      if (!l || l.booked_package || l.status !== "open" || db.apps.some((a) => a.listing_id === listingId && a.applicant_id === h.id)) return;
      let price: number | undefined, unit: "total" | "hour" = "total";
      if (l.kind === "service") {
        const base = parseFloat((l.pay.match(/\d+(\.\d+)?/) || ["0"])[0]) || 60;
        unit = /\/\s*h(ou)?r/i.test(l.pay) ? "hour" : "total";
        price = Math.max(5, Math.round(base * (i === 0 ? 0.95 : 1.1)));
      }
      const message = l.kind === "service" ? "Hi! I can help with this. " + (h.headline || "Happy to answer any questions.") : "Hello, I'm available for this shift. " + (h.headline || "");
      const a: Application = { id: uid(), listing_id: listingId, applicant_id: h.id, message, status: "pending", created_at: new Date().toISOString(), ...(price ? { price, price_unit: unit } : {}) };
      db.apps.push(a);
      db.msgs.push({ id: uid(), application_id: a.id, sender_id: h.id, body: message, created_at: a.created_at });
      notify(ME, "application", (price ? "New quote: " : "New applicant: ") + short(h.name) + (price ? " · £" + price + (unit === "hour" ? "/hr" : "") : ""), l.title, "/manage/" + listingId);
      save(); allSubs.forEach((f) => f());
    }));
  }
  /** When you add a category under "What I do", a sample neighbour posts a matching request a few seconds later. */
  function simulateMatchFor(skills: string[]) {
    const fresh = skills.filter((c) => !(db.matchedSkills || []).includes(c));
    if (!fresh.length) return;
    db.matchedSkills = [...(db.matchedSkills || []), ...fresh];
    const cat = fresh[0];
    later(6000, () => {
      const p = locate("BS31");
      const l = { id: uid(), owner_id: "anna", kind: "service", title: "Help needed: " + (cat === "other" ? "small job" : cat.replace(/^./, (c) => c.toUpperCase())), category: cat,
        area: "Saltford BS31", date: today(3), offset: 3, start_time: "10:00", end_time: null, pay: "£50", description: "Sample request created to show automatic matching.",
        requirements: "", photo_url: null, status: "open", created_at: new Date().toISOString(), positions: 1, views: 0, lat: p!.lat, lng: p!.lng, details: {} } as SeedListing;
      db.listings.unshift(l);
      db.priv[l.id] = "Saltford BS31 (sample address)";
      if (user(ME).match_alerts !== false) notify(ME, "match", "New request near you: " + l.title, l.area + " · " + l.pay, "/l/" + l.id);
      save();
    });
  }

  const OWNER_SCRIPT = [
    "Thanks for getting in touch! Are you free for the full time?",
    "Great. Any similar experience?",
    "Perfect, you're confirmed. The exact address is now on the listing. See you then!",
  ];
  const APPLICANT_SCRIPT = ["Thanks! Happy to answer any questions.", "Yes, that works for me.", "Great, see you then."];

  function botReply(appId: string) {
    const a = db.apps.find((x) => x.id === appId);
    if (!a) return;
    const l = listing(a.listing_id)!;
    const n = db.bot[appId] || 0;
    if (n >= 3) return;
    db.bot[appId] = n + 1;
    if (a.applicant_id === ME) {
      later(1600, () => {
        post(appId, l.owner_id, OWNER_SCRIPT[n]);
        if (n === 2 && a.status === "pending") setStatus(a, "accepted");
      });
    } else later(1600, () => post(appId, a.applicant_id, APPLICANT_SCRIPT[n]));
  }

  function seedMine() {
    if (db.mineSeeded) return;
    db.mineSeeded = true;
    const id = "mine1";
    const p = locate("BS31");
    db.listings.unshift({
      id, owner_id: ME, kind: "job", title: "Breakfast service, Sunday", category: "hospitality", area: "Keynsham BS31",
      date: today(2), offset: 2, start_time: "07:00", end_time: "11:00", pay: "£13/hr", positions: 2, views: 46, lat: p!.lat, lng: p!.lng,
      description: "Help serve breakfast to hotel guests. This is a sample listing so you can try managing applicants.",
      requirements: "Right to work in the UK.", photo_url: null, status: "open", created_at: ago(180),
    } as SeedListing);
    db.priv[id] = "Your address (sample)";
    const mk = (who: string, message: string, mins: number) => {
      const a: Application = { id: uid(), listing_id: id, applicant_id: who, message, status: "pending", created_at: ago(mins) };
      db.apps.push(a);
      db.msgs.push({ id: uid(), application_id: a.id, sender_id: who, body: message, created_at: a.created_at });
      db.notices.unshift({ id: uid(), type: "application", title: "New applicant: " + short(user(who).name), body: "Breakfast service, Sunday", link: "/manage/" + id, read: false, created_at: a.created_at });
    };
    mk("tom", "Hi, I've done breakfast service for 5 years. I'd love this shift.", 120);
    mk("priya", "Hello! I'm free Sunday morning and learn fast.", 45);
    // A home-service request with priced quotes, to try comparing offers.
    const id2 = "mine2";
    db.listings.unshift({
      id: id2, owner_id: ME, kind: "service", title: "End of tenancy clean, 2-bed flat", category: "cleaning", area: "Keynsham BS31",
      date: today(5), offset: 5, start_time: "09:00", end_time: null, pay: "£100–150", positions: 1, views: 31, lat: p!.lat, lng: p!.lng,
      description: "Full clean before handing back the keys, including oven and windows inside. Sample listing to try comparing quotes.",
      requirements: "", photo_url: null, status: "open", created_at: ago(300),
      details: { type: "End of tenancy", size: "2 bedrooms", supplies: "Cleaner brings them", frequency: "One-off" },
    } as SeedListing);
    db.priv[id2] = "Your address (sample)";
    const quote = (who: string, message: string, mins: number, price: number, unit: "total" | "hour") => {
      const a: Application = { id: uid(), listing_id: id2, applicant_id: who, message, status: "pending", created_at: ago(mins), price, price_unit: unit };
      db.apps.push(a);
      db.msgs.push({ id: uid(), application_id: a.id, sender_id: who, body: message, created_at: a.created_at });
    };
    quote("maria", "I do end of tenancy cleans every week and bring all products, oven included. About 5 hours.", 200, 140, "total");
    quote("priya", "Happy to help! I can do it with a friend so it's done in one morning.", 150, 95, "total");
    quote("olu", "I can do the clean and fix any small marks on the walls if needed.", 90, 120, "total");
    db.notices.unshift({ id: uid(), type: "application", title: "3 quotes: End of tenancy clean", body: "Compare prices and reviews", link: "/manage/" + id2, read: false, created_at: ago(90) });
    db.notices.unshift({ id: uid(), type: "welcome", title: "Welcome to NearTask", body: "Turn on alerts in Explore to hear about new listings first.", link: "/explore", read: false, created_at: ago(1) });
  }

  const api: Api = {
    mode: "demo",
    async currentUser() { return db.session; },
    onAuthChange(cb) { authSubs.add(cb); return () => authSubs.delete(cb); },
    async signUp(email, password) { if (password.length < 6) throw new Error("short"); await api.verifyCode(email, "000000"); return "ok"; },
    async signIn(email, password) { if (!/^\S+@\S+\.\S+$/.test(email) || !password) throw new Error("wrong"); await api.verifyCode(email, "000000"); },
    async resetPassword() {},
    async updatePassword() {},
    onRecovery() { return () => {}; },
    async sendCode(email) { if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("email"); },
    async verifyCode(email, code) {
      if (!/^\d{6}$/.test(code)) throw new Error("code");
      db.session = ME;
      const me = user(ME);
      me.is_admin = true; // demo: you are the admin so the panel can be tried
      if (!me.name) me.name = email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()).slice(0, 30);
      seedMine();
      save();
      authSubs.forEach((f) => f(ME));
    },
    async signOut() { db.session = null; save(); authSubs.forEach((f) => f(null)); },

    async getProfile(id) { return db.users.find((u) => u.id === id) || null; },
    async profileStats(id) {
      const u = db.users.find((x) => x.id === id);
      const done = db.apps.filter((a) => a.applicant_id === id && a.status === "accepted").length;
      const hires = db.apps.filter((a) => a.status === "accepted" && listing(a.listing_id)?.owner_id === id).length;
      // Sample people get a believable track record; you start from zero.
      const seedJobs = id === ME ? 0 : Math.round((u?.rating_count || 0) * 1.4);
      const h = [...id].reduce((n, c) => n + c.charCodeAt(0), 0);
      return { jobs_done: seedJobs + done, hires: (u?.account_type === "business" ? seedJobs * 2 : 0) + hires, reply_minutes: id === ME ? null : [25, 50, 140, 300, 900][h % 5] };
    },
    async saveProfile(p) { const me = user(need()); Object.assign(me, p); save(); if (p.skills?.length && p.match_alerts !== false) simulateMatchFor(p.skills); },
    async listWorkers(skill, near) {
      const list = db.users.filter((u) => u.available && u.account_type === "person" && u.id !== db.session && (skill === "all" || u.skills.includes(skill)));
      const d = (u: Profile) => (near && u.lat != null ? km(near, { lat: u.lat, lng: u.lng! }) : 999);
      return list.sort((a, b) => d(a) - d(b) || b.rating_avg - a.rating_avg);
    },
    async stats() {
      return {
        seekers: db.users.filter((u) => u.available && u.account_type === "person").length,
        businesses: db.users.filter((u) => u.account_type === "business").length,
        listings: applyFilters(db.listings, { kind: "all", when: "any", category: "all", q: "", sort: "soon" }).length,
      };
    },

    async listListings(f: Filters) { return applyFilters(db.listings.filter((l) => !l.booked_package).map(withOwner), f); },
    async getListing(id) { const l = listing(id); return l ? withOwner(l) : null; },
    async myListings() { const me = need(); return db.listings.filter((l) => l.owner_id === me).map(withOwner); },
    async saveListing(inp: ListingInput) {
      const me = need();
      const { address, ...rest } = inp;
      const p = locate(inp.area);
      const geo = { lat: p?.lat ?? null, lng: p?.lng ?? null };
      if (inp.id) {
        const l = listing(inp.id);
        if (!l || l.owner_id !== me) throw new Error("forbidden");
        Object.assign(l, rest, geo);
        delete l.offset;
      } else {
        const id = uid();
        const helpers = matchHelpers(rest.category, rest.kind, geo, me);
        db.listings.unshift({ ...rest, ...geo, id, owner_id: me, status: "open", views: 0, notified: helpers.length, created_at: new Date().toISOString() } as Listing);
        inp.id = id;
        simulateReplies(id, helpers);
      }
      db.priv[inp.id!] = address;
      save();
      return inp.id!;
    },
    async setListingStatus(id, status: ListingStatus) { const l = listing(id); if (l && l.owner_id === need()) { l.status = status; save(); } },
    async deleteListing(id) {
      const me = need();
      db.listings = db.listings.filter((l) => !(l.id === id && l.owner_id === me));
      const gone = db.apps.filter((a) => a.listing_id === id).map((a) => a.id);
      db.apps = db.apps.filter((a) => a.listing_id !== id);
      db.msgs = db.msgs.filter((m) => !gone.includes(m.application_id));
      save();
      allSubs.forEach((f) => f());
    },
    async getAddress(listingId) {
      const me = db.session;
      const l = listing(listingId);
      if (!me || !l) return null;
      if (l.owner_id === me || db.apps.some((a) => a.listing_id === listingId && a.applicant_id === me && a.status === "accepted")) return db.priv[listingId] || "";
      return null;
    },
    async uploadPhoto(file) { return blobToDataUrl(await shrinkImage(file, 720)); },
    async viewListing(id) { const l = listing(id); if (l && l.owner_id !== db.session) { l.views = (l.views || 0) + 1; save(); } },
    async dashboard() {
      const me = need();
      return db.listings.filter((l) => l.owner_id === me).map((l) => {
        const apps = db.apps.filter((a) => a.listing_id === l.id);
        return { listing: withOwner(l), applicants: apps.filter((a) => a.status !== "invited").length,
          pending: apps.filter((a) => a.status === "pending").length, accepted: apps.filter((a) => a.status === "accepted").length };
      });
    },
    async invite(listingId, workerId, message) {
      const me = need();
      const l = listing(listingId);
      if (!l || l.owner_id !== me) throw new Error("forbidden");
      let a = db.apps.find((x) => x.listing_id === listingId && x.applicant_id === workerId);
      if (!a) {
        a = { id: uid(), listing_id: listingId, applicant_id: workerId, message, status: "invited", created_at: new Date().toISOString() };
        db.apps.push(a);
        post(a.id, me, message);
        const app = a;
        later(2200, () => { post(app.id, workerId, "Thanks for the invite! Yes, I can do it."); setStatus(app, "accepted"); });
      }
      return a.id;
    },

    async apply(listingId, message, quote) {
      const me = need();
      const l = listing(listingId)!;
      if (l.owner_id === me) throw new Error("own");
      if (user(me).age_group === "16-17" && adultOnly(l)) throw new Error("adult");
      const q = quote ? { price: quote.price, price_unit: quote.unit, quoted_at: new Date().toISOString() } : {};
      let a = db.apps.find((x) => x.listing_id === listingId && x.applicant_id === me);
      if (!a) {
        a = { id: uid(), listing_id: listingId, applicant_id: me, message, status: "pending", created_at: new Date().toISOString(), ...q };
        db.apps.push(a);
      } else if (a.status === "withdrawn") Object.assign(a, { status: "pending" }, q);
      post(a.id, me, message);
      botReply(a.id);
      return a.id;
    },
    async myApplications() { const me = need(); return db.apps.filter((a) => a.applicant_id === me).map(fullApp).reverse(); },
    async applicationsFor(listingId) { return db.apps.filter((a) => a.listing_id === listingId).map(fullApp); },
    async getApplication(id) { const a = db.apps.find((x) => x.id === id); return a ? fullApp(a) : null; },
    async updateQuote(appId, quote) {
      const me = need();
      const a = db.apps.find((x) => x.id === appId && x.applicant_id === me);
      if (!a || a.status !== "pending") throw new Error("forbidden");
      Object.assign(a, { price: quote.price, price_unit: quote.unit, quoted_at: new Date().toISOString() });
      const l = listing(a.listing_id)!;
      post(a.id, me, "Updated quote: £" + quote.price + (quote.unit === "hour" ? "/hr" : ""));
      notify(l.owner_id, "application", "Updated quote: " + short(user(me).name) + " · £" + quote.price, l.title, "/manage/" + l.id);
      save();
    },
    async completeJob(appId) {
      const me = need();
      const a = db.apps.find((x) => x.id === appId);
      if (!a || listing(a.listing_id)?.owner_id !== me) throw new Error("forbidden");
      if (a.status !== "accepted") throw new Error("not accepted");
      if (a.completed_at) return;
      a.completed_at = new Date().toISOString();
      notify(ME, "completed", "How did it go? " + listing(a.listing_id)!.title, "Leave a review to help others choose.", "/chat/" + appId);
      save(); emit(appId);
    },
    async reportJobProblem(appId, reason) {
      need();
      const a = db.apps.find((x) => x.id === appId);
      const l = a && listing(a.listing_id);
      if (!a || !l || a.status !== "accepted") throw new Error("forbidden");
      const since = a.completed_at ? Date.parse(a.completed_at) : Date.parse(l.date + "T23:59");
      if (Date.now() > since + 72 * 3600000) throw new Error("window");
      const other = l.owner_id === ME ? a.applicant_id : l.owner_id;
      db.reports2.unshift({ id: uid(), reason: "[Job problem] " + reason, status: "open", created_at: new Date().toISOString(), listing_id: l.id, reported_user_id: other,
        listing_title: l.title, listing_status: l.status, listing_owner: l.owner_id, reporter_name: user(ME).name, reported_name: user(other).name, reported_banned: false });
      save();
    },
    async priceGuide(category) {
      const real = db.apps.filter((a) => a.price != null && listing(a.listing_id)?.category === category);
      const unit = HOURLY.includes(category) ? "hour" : "total";
      const xs = [...(SAMPLE_QUOTES[category] || []), ...real.filter((a) => (a.price_unit || "total") === unit).map((a) => a.price!)];
      if (xs.length < 3) return null;
      return { n: xs.length, unit, low: quantile(xs, 0.25), mid: quantile(xs, 0.5), high: quantile(xs, 0.75) } as PriceGuide;
    },

    async listPackages(f) {
      let list = db.packages.filter((p) => (f.owner ? p.owner_id === f.owner : p.active) && (!f.category || f.category === "all" || p.category === f.category));
      const withD = list.map((p) => {
        const pos = locate(p.area);
        return { ...p, owner: user(p.owner_id), distance: f.near && pos ? km(f.near, pos) : undefined };
      });
      return f.near ? withD.sort((a, b) => (a.distance ?? 999) - (b.distance ?? 999)) : withD;
    },
    async getPackage(id) { const p = db.packages.find((x) => x.id === id); return p ? { ...p, owner: user(p.owner_id) } : null; },
    async savePackage(inp) {
      const me = need();
      if (inp.id) {
        const p = db.packages.find((x) => x.id === inp.id && x.owner_id === me);
        if (!p) throw new Error("forbidden");
        Object.assign(p, inp);
        save(); return p.id;
      }
      const id = uid();
      db.packages.unshift({ ...inp, id, owner_id: me, created_at: new Date().toISOString() } as Package);
      save(); return id;
    },
    async deletePackage(id) { const me = need(); db.packages = db.packages.filter((p) => !(p.id === id && p.owner_id === me)); save(); },
    async bookPackage(b) {
      const me = need();
      const p = db.packages.find((x) => x.id === b.packageId && x.active);
      if (!p) throw new Error("gone");
      if (p.owner_id === me) throw new Error("own");
      if (user(me).age_group === "16-17" && adultOnlyPackage(p)) throw new Error("adult");
      const payt = "£" + p.price + (p.price_unit === "hour" ? "/hr" : "");
      const lid = await api.saveListing({ kind: "service", title: p.title, category: p.category, area: user(me).postcode || p.area || "Local", date: b.date,
        start_time: b.time, end_time: null, pay: payt, description: b.note, requirements: "", photo_url: null, address: b.address, positions: 1, details: {} });
      const l = listing(lid)!;
      l.booked_package = p.id;
      l.notified = 0;
      const when = new Date(b.date + "T12:00").toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
      const msg = "Booking request: " + p.title + " (" + payt + ") on " + when + (b.time ? " at " + b.time : "") + (b.note ? "\n" + b.note : "");
      const appId = await api.invite(lid, p.owner_id, msg);
      const a = db.apps.find((x) => x.id === appId)!;
      a.price = p.price; a.price_unit = p.price_unit;
      save();
      return appId;
    },
    async setApplicationStatus(id, status) {
      const a = db.apps.find((x) => x.id === id);
      if (!a) return;
      if (status === "accepted" && quoteExpired(a)) throw new Error("expired");
      setStatus(a, status);
      if (status === "accepted" && a.applicant_id !== ME) later(1400, () => post(id, a.applicant_id, "Brilliant, thank you! I'll be there on time."));
    },

    async threads() {
      const me = db.session;
      if (!me) return [];
      const out: Thread[] = [];
      for (const a of db.apps) {
        const l = listing(a.listing_id);
        if (!l || (a.applicant_id !== me && l.owner_id !== me)) continue;
        const ms = db.msgs.filter((m) => m.application_id === a.id);
        out.push({ app: fullApp(a), listing: withOwner(l), other: user(l.owner_id === me ? a.applicant_id : l.owner_id), last: ms[ms.length - 1] || null, mineIsOwner: l.owner_id === me });
      }
      return out.sort((x, y) => (y.last?.created_at || y.app.created_at).localeCompare(x.last?.created_at || x.app.created_at));
    },
    async messages(appId) { return db.msgs.filter((m) => m.application_id === appId); },
    async send(appId, body) { const me = need(); post(appId, me, body); botReply(appId); },
    subscribe(appId, cb) {
      if (!subs.has(appId)) subs.set(appId, new Set());
      subs.get(appId)!.add(cb);
      return () => subs.get(appId)!.delete(cb);
    },
    subscribeAll(cb) { allSubs.add(cb); return () => allSubs.delete(cb); },

    async favorites() { return db.session ? db.favs[db.session] || [] : []; },
    async toggleFavorite(listingId) {
      const me = need();
      const f = (db.favs[me] = db.favs[me] || []);
      const i = f.indexOf(listingId);
      if (i > -1) f.splice(i, 1); else f.push(listingId);
      save();
      return i === -1;
    },

    async review(appId, revieweeId, stars, comment) {
      const me = need();
      if (db.reviews.some((r) => r.application_id === appId && r.reviewer_id === me)) return;
      db.reviews.push({ id: uid(), application_id: appId, reviewer_id: me, reviewee_id: revieweeId, stars, comment, created_at: new Date().toISOString() });
      const mine = db.reviews.filter((r) => r.reviewee_id === revieweeId);
      const u = user(revieweeId);
      u.rating_count = mine.length;
      u.rating_avg = Math.round((mine.reduce((s, r) => s + r.stars, 0) / mine.length) * 100) / 100;
      save();
    },
    async reviewsFor(userId) {
      return db.reviews.filter((r) => r.reviewee_id === userId).map((r) => ({ ...r, reviewer: user(r.reviewer_id) })).reverse();
    },
    async myReview(appId) { return db.reviews.find((r) => r.application_id === appId && r.reviewer_id === db.session) || null; },

    async report(listingId, reason) {
      const l = listing(listingId);
      db.reports2.unshift({ id: uid(), reason, status: "open", created_at: new Date().toISOString(), listing_id: listingId, reported_user_id: null,
        listing_title: l?.title || null, listing_status: l?.status || null, listing_owner: l?.owner_id || null,
        reporter_name: user(ME).name, reported_name: l ? user(l.owner_id).name : null, reported_banned: false });
      save();
    },
    async deleteAccount() { db = seed(); save(); authSubs.forEach((f) => f(null)); },
    async blockedIds() { return db.blocks; },
    async blockedProfiles() { return db.blocks.map(user).filter(Boolean); },
    async block(u) { if (!db.blocks.includes(u)) db.blocks.push(u); save(); },
    async unblock(u) { db.blocks = db.blocks.filter((x) => x !== u); save(); },
    async reportUser(u, reason) {
      db.reports2.unshift({ id: uid(), reason, status: "open", created_at: new Date().toISOString(), listing_id: null, reported_user_id: u,
        listing_title: null, listing_status: null, listing_owner: null, reporter_name: user(ME).name, reported_name: user(u)?.name || null, reported_banned: !!user(u)?.banned });
      save();
    },
    async adminSetSetting() { /* demo: saved only in this browser by the Settings screen */ },
    async adminOverview() {
      return { users: db.users.length, businesses: db.users.filter((u) => u.account_type === "business").length,
        seekers: db.users.filter((u) => u.available).length, open_listings: applyFilters(db.listings, { kind: "all", when: "any", category: "all", q: "", sort: "soon" }).length,
        applications: db.apps.length, messages_7d: db.msgs.length, new_users_7d: 1, open_reports: db.reports2.filter((r) => r.status === "open").length };
    },
    async adminReports() {
      if (!db.reports2.length) db.reports2.push({ id: uid(), reason: "Asks applicants to pay a 'registration fee'.", status: "open", created_at: ago(90), listing_id: "s8", reported_user_id: null,
        listing_title: "Fix a dripping tap", listing_status: "open", listing_owner: "helen", reporter_name: "Priya (sample)", reported_name: "Helen (sample)", reported_banned: false });
      return db.reports2.map((r) => ({ ...r, listing_status: r.listing_id ? listing(r.listing_id)?.status || null : null, reported_banned: !!user(r.reported_user_id || r.listing_owner || "")?.banned }));
    },
    async adminResolveReport(id, status) { const r = db.reports2.find((x) => x.id === id); if (r) r.status = status; save(); },
    async adminSetListingStatus(id, status) { const l = listing(id); if (l) l.status = status; save(); },
    async adminSetVerified(u, v) { const p = user(u); if (p) p.verified = v; save(); },
    async adminSetBanned(u, v) { const p = user(u); if (p) { p.banned = v; if (v) db.listings.forEach((l) => { if (l.owner_id === u && l.status === "open") l.status = "closed"; }); } save(); },
    async adminSearch(q) { const s = q.toLowerCase(); return db.users.filter((u) => u.id !== ME && (!s || u.name.toLowerCase().includes(s))); },

    async notifications() { return db.session ? db.notices.slice(0, 50) : []; },
    async markAllRead() { db.notices.forEach((n) => (n.read = true)); save(); },
    onNotification(cb) { noticeSubs.add(cb); return () => noticeSubs.delete(cb); },
    async savedSearches() { return db.session ? db.searches : []; },
    async saveSearch(s) {
      need();
      db.searches.unshift({ ...s, id: uid(), created_at: new Date().toISOString() });
      save();
      // Demo: a matching listing appears a few seconds later, to show how alerts work.
      later(5000, () => {
        const kind = s.kind === "service" ? "service" : "job";
        const cat = s.category !== "all" ? s.category : kind === "job" ? "hospitality" : "cleaning";
        const owner = kind === "job" ? "pub" : "anna";
        const p = locate("BS31");
        const l = { id: uid(), owner_id: owner, kind, title: (s.q ? s.q[0].toUpperCase() + s.q.slice(1) + " – " : "") + (kind === "job" ? "Extra shift this weekend" : "Help needed this weekend"),
          category: cat, area: "Keynsham BS31", date: today(4), offset: 4, start_time: "10:00", end_time: "15:00", pay: kind === "job" ? "£13/hr" : "£50",
          description: "New sample listing created to show how alerts work.", requirements: "", photo_url: null, status: "open", created_at: new Date().toISOString(),
          positions: 1, views: 0, lat: p!.lat, lng: p!.lng } as SeedListing;
        db.listings.unshift(l);
        db.priv[l.id] = "Keynsham BS31 (sample address)";
        notify(ME, "alert", "New match: " + l.title, l.area + " · " + l.pay, "/l/" + l.id);
      });
    },
    async deleteSearch(id) { db.searches = db.searches.filter((s) => s.id !== id); save(); },
    resetDemo() { const s = db.session; db = seed(); save(); if (s) authSubs.forEach((f) => f(null)); },
  };
  return api;
}
