import { useApp } from "./state";
import { Icon } from "./ui";
import { Explore, Home, Saved } from "./screens/Browse";
import { ListingView, Manage } from "./screens/Listing";
import { PostForm } from "./screens/Post";
import { Chat, Inbox } from "./screens/Chat";
import { BlockedList, Login, Me, Recovery, UserView } from "./screens/Account";
import { Admin } from "./screens/Admin";
import { Privacy, Terms } from "./screens/Legal";
import { Dashboard, Notices } from "./screens/Extra";
import { BookService, ServiceForm, Services } from "./screens/Services";
import type { Key } from "./i18n";

const TABS: [string, string, Key, string[]][] = [
  ["/", "home", "home", ["home", "notices"]],
  ["/explore", "search", "explore", ["explore", "listing", "user", "saved", "services", "service"]],
  ["/post", "plus", "post", ["post", "edit", "manage", "copy"]],
  ["/inbox", "chat", "inbox", ["inbox", "chat"]],
  ["/me", "user", "profile", ["me", "login", "dashboard", "admin", "privacy", "terms", "blocked", "newService", "editService"]],
];

export function App() {
  const { route: r, t, go, unread, onboarded, uid } = useApp();
  const screen = (() => {
    switch (r.name) {
      case "home": return <Home />;
      case "explore": return <Explore />;
      case "listing": return <ListingView key={r.id} id={r.id} />;
      case "post": return <PostForm key="new" />;
      case "edit": return <PostForm key={r.id} id={r.id} />;
      case "manage": return <Manage id={r.id} />;
      case "inbox": return <Inbox />;
      case "chat": return <Chat key={r.id} id={r.id} />;
      case "me": return <Me />;
      case "user": return <UserView key={r.id} id={r.id} />;
      case "saved": return <Saved />;
      case "login": return <Login next={r.next} />;
      case "notices": return <Notices />;
      case "recovery": return <Recovery />;
      case "admin": return <Admin />;
      case "privacy": return <Privacy />;
      case "terms": return <Terms />;
      case "blocked": return <BlockedList />;
      case "dashboard": return <Dashboard />;
      case "copy": return <PostForm key={"copy" + r.id} copyFrom={r.id} />;
      case "services": return <Services />;
      case "service": return <BookService key={r.id} id={r.id} />;
      case "newService": return <ServiceForm key="new" />;
      case "editService": return <ServiceForm key={r.id} id={r.id} />;
    }
  })();
  const hideNav = r.name === "chat" || r.name === "login" || r.name === "recovery" || (r.name === "home" && !onboarded && !uid);
  return (
    <div className={"shell" + (hideNav ? " nonav" : "")}>
      <main>{screen}</main>
      {!hideNav && (
        <nav className="tabbar" aria-label="Main">
          {TABS.map(([path, icon, label, names]) => {
            const on = names.includes(r.name);
            return (
              <button key={path} className={(on ? "on" : "") + (icon === "plus" ? " posttab" : "")} aria-current={on ? "page" : undefined} onClick={() => go(path)}>
                <span className="tabic"><Icon name={icon} size={icon === "plus" ? 24 : 22} />{icon === "chat" && unread > 0 && <span className="badge">{unread}</span>}</span>
                <span>{t(label)}</span>
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}
