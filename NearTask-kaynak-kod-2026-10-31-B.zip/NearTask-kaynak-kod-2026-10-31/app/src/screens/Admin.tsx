import { useState } from "react";
import { useApp } from "../state";
import type { AdminReport, Profile } from "../types";
import { Avatar, Empty, Icon, Loading, TopBar, useLoad } from "../ui";
import { fmtAgo, type Key } from "../i18n";
import { COMPANY, setSupportEmail } from "../company";

type Tab = "overview" | "reports" | "users" | "settings";

export function Admin() {
  const { api, t, isAdmin, uid, me } = useApp();
  const [tab, setTab] = useState<Tab>("overview");
  if (!uid || !me) return <div className="screen"><Loading /></div>;
  if (!isAdmin) return <div className="screen"><TopBar backTo="/me" /><Empty icon="lock" text={t("notFound")} /></div>;
  return (
    <div className="screen">
      <TopBar title={t("adminPanel")} backTo="/me" />
      <div className="seg tabs">
        {(["overview", "reports", "users", "settings"] as Tab[]).map((x) => (
          <button key={x} className={tab === x ? "on" : ""} onClick={() => setTab(x)}>{t(("a." + x) as Key)}</button>
        ))}
      </div>
      {tab === "overview" ? <Overview go={setTab} /> : tab === "reports" ? <Reports /> : tab === "settings" ? <Settings /> : <Users />}
      {api.mode === "demo" && <p className="note">Demo: you're shown as the admin so you can try this screen. In the live app only accounts marked as admin see it.</p>}
    </div>
  );
}

function Settings() {
  const { api, t, toast } = useApp();
  const [email, setEmail] = useState(COMPANY.email);
  const [busy, setBusy] = useState(false);
  const clean = email.trim().toLowerCase();
  const save = async () => {
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(clean)) return toast(t("a.supportEmailBad"));
    setBusy(true);
    try {
      await api.adminSetSetting("support_email", clean);
      setSupportEmail(clean);
      setEmail(clean);
      toast(t("a.supportEmailSaved"));
    } catch { toast(t("error")); } finally { setBusy(false); }
  };
  return (
    <>
      <h2 className="sec">{t("a.supportEmail")}</h2>
      <p className="mute xs">{t("a.supportEmailHint")}</p>
      <label>{t("a.supportEmailLabel")}
        <input type="email" inputMode="email" autoComplete="off" maxLength={120} value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <button className="btn full" disabled={busy || clean === COMPANY.email} onClick={save}>{t("save")}</button>
    </>
  );
}

function Overview({ go }: { go(t: Tab): void }) {
  const { api, t } = useApp();
  const [o] = useLoad(() => api.adminOverview(), [api]);
  if (!o) return <Loading />;
  const tiles: [Key, number, string][] = [
    ["a.usersTotal", o.users, "user"], ["a.new", o.new_users_7d, "plus"], ["a.biz", o.businesses, "briefcase"], ["a.seekers", o.seekers, "search"],
    ["a.open", o.open_listings, "list"], ["a.apps", o.applications, "check"], ["a.msgs", o.messages_7d, "chat"], ["a.openReports", o.open_reports, "flag"],
  ];
  return (
    <>
      <div className="kpis">
        {tiles.map(([k, v, icon]) => (
          <button key={k} className={"kpi" + (k === "a.openReports" && v > 0 ? " alert" : "")} onClick={() => k === "a.openReports" && go("reports")}>
            <Icon name={icon} size={18} /><b>{v.toLocaleString()}</b><span>{t(k)}</span>
          </button>
        ))}
      </div>
    </>
  );
}

function Reports() {
  const { api, t, lang, toast, go } = useApp();
  const [filter, setFilter] = useState<"open" | "all">("open");
  const [list, reload] = useLoad(() => api.adminReports(), [api]);
  if (!list) return <Loading />;
  const shown = list.filter((r) => filter === "all" || r.status === "open");
  const act = async (fn: () => Promise<void>, msg: Key) => { try { await fn(); toast(t(msg)); reload(); } catch { toast(t("error")); } };
  const target = (r: AdminReport) => r.reported_user_id || r.listing_owner;
  return (
    <>
      <div className="chips">
        <button className={"chip" + (filter === "open" ? " on" : "")} onClick={() => setFilter("open")}>{t("a.status.open")}</button>
        <button className={"chip" + (filter === "all" ? " on" : "")} onClick={() => setFilter("all")}>{t("all")}</button>
      </div>
      {!shown.length ? <Empty icon="check" text={t("a.noReports")} /> : shown.map((r) => (
        <div key={r.id} className={"reportcard st-" + r.status}>
          <div className="trow">
            <b className="ellip">{r.listing_title ? r.listing_title : r.reported_name}</b>
            <span className={"status sm " + (r.status === "open" ? "st-pending" : "st-declined")}>{t(("a.status." + r.status) as Key)}</span>
          </div>
          <span className="mute xs block">{r.listing_title ? r.reported_name + " · " : ""}{t("a.reportedBy", { name: r.reporter_name || "?" })} · {fmtAgo(lang, r.created_at)}</span>
          <p className="quote">"{r.reason}"</p>
          {r.reported_banned && <span className="tag off">{t("a.suspended")}</span>}
          <div className="btnwrap">
            {r.listing_id && <button className="btn ghost sm" onClick={() => go("/l/" + r.listing_id)}><Icon name="search" size={15} /> View</button>}
            {r.listing_id && (r.listing_status === "closed"
              ? <button className="btn ghost sm" onClick={() => act(() => api.adminSetListingStatus(r.listing_id!, "open"), "saved")}>{t("a.reopenListing")}</button>
              : <button className="btn ghost sm" onClick={() => act(() => api.adminSetListingStatus(r.listing_id!, "closed"), "saved")}>{t("a.closeListing")}</button>)}
            {target(r) && (r.reported_banned
              ? <button className="btn ghost sm" onClick={() => act(() => api.adminSetBanned(target(r)!, false), "saved")}>{t("a.unban")}</button>
              : <button className="btn danger sm" onClick={() => act(() => api.adminSetBanned(target(r)!, true), "saved")}>{t("a.ban")}</button>)}
            {r.status === "open" && <>
              <button className="btn sm" onClick={() => act(() => api.adminResolveReport(r.id, "resolved"), "saved")}><Icon name="check" size={15} /> {t("a.resolve")}</button>
              <button className="btn ghost sm" onClick={() => act(() => api.adminResolveReport(r.id, "dismissed"), "saved")}>{t("a.dismiss")}</button>
            </>}
          </div>
        </div>
      ))}
    </>
  );
}

function Users() {
  const { api, t, toast, go } = useApp();
  const [q, setQ] = useState("");
  const [list, reload] = useLoad(() => api.adminSearch(q), [api, q]);
  const act = async (fn: () => Promise<void>) => { try { await fn(); toast(t("saved")); reload(); } catch { toast(t("error")); } };
  return (
    <>
      <label className="searchbox"><Icon name="search" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("a.search")} type="search" /></label>
      {!list ? <Loading /> : !list.length ? <Empty icon="user" text={t("none")} /> : list.map((p: Profile) => (
        <div key={p.id} className="usercard">
          <button className="owner flat" onClick={() => go("/u/" + p.id)}>
            <Avatar p={p} size={40} />
            <span className="grow"><b className="ellip block">{p.name || "—"}</b>
              <span className="mute xs">{t(p.account_type === "business" ? "business" : "person")}{p.postcode ? " · " + p.postcode : ""}</span></span>
            {p.verified && <span className="vtag"><Icon name="check" size={12} /> {t("verified")}</span>}
            {p.banned && <span className="tag off">{t("a.suspended")}</span>}
          </button>
          <div className="btnwrap">
            <button className="btn ghost sm" onClick={() => act(() => api.adminSetVerified(p.id, !p.verified))}>{p.verified ? t("a.unverify") : t("a.verify")}</button>
            <button className={"btn sm " + (p.banned ? "ghost" : "danger")} onClick={() => act(() => api.adminSetBanned(p.id, !p.banned))}>{p.banned ? t("a.unban") : t("a.ban")}</button>
          </div>
        </div>
      ))}
    </>
  );
}
