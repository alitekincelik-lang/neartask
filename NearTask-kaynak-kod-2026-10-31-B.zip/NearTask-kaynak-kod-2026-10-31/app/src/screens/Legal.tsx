import { COMPANY } from "../company";
import { TopBar } from "../ui";

const who = () =>
  `${COMPANY.name}${COMPANY.number ? `, a company registered in England and Wales (company number ${COMPANY.number})` : ""}${COMPANY.address ? `, registered office ${COMPANY.address}` : ""}`;

function Doc({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="screen legal">
      <TopBar title={title} backTo="/me" />
      <article className="doc">
        <h1>{title}</h1>
        <p className="mute xs">Last updated {COMPANY.updated}</p>
        {children}
        <p className="mute xs">Questions? Email <b>{COMPANY.email}</b>.</p>
      </article>
    </div>
  );
}

export function Privacy() {
  return (
    <Doc title="Privacy Policy">
      <p>NearTask is run by {who()} ("we", "us"). We are the data controller for personal data processed through NearTask{COMPANY.ico ? ` and are registered with the Information Commissioner's Office (ICO) under number ${COMPANY.ico}` : ""}. This policy explains what we collect, why, and your rights under UK data protection law (UK GDPR and the Data Protection Act 2018).</p>

      <h2>What we collect</h2>
      <ul>
        <li><b>Account details:</b> email address, an encrypted password, and whether you are 16–17 or 18 and over.</li>
        <li><b>Profile:</b> name or business name, postcode district, photo or logo, short bio, the areas you work in ("What I do"), the days you're available and work photos, if you add them.</li>
        <li><b>Listings and services:</b> job or request details and the answers to the quick questions, pay, date and time, area, photos, fixed-price services you publish, and the exact address, which we only show to the person accepted for the job.</li>
        <li><b>Activity:</b> offers and the prices you quote, invites, bookings, messages, reviews, jobs marked as done, problem reports, saved listings, alerts, reports and blocks.</li>
        <li><b>Technical data:</b> basic logs (such as IP address and device type) kept by our hosting providers for security.</li>
      </ul>

      <h2>Location and postcode</h2>
      <ul>
        <li>We store your postcode district (for example BS31) and an approximate point worked out from it, never your exact location.</li>
        <li>If you tap "Use my location", your phone's location is used on your device to sort results by distance. It is not stored.</li>
        <li>The exact address of a job is shown only to the person accepted for it.</li>
      </ul>

      <h2>Why we use it (and our lawful basis)</h2>
      <ul>
        <li>To run the service you sign up for: showing listings, connecting people, offers, bookings, messaging and notifications (<i>contract</i>).</li>
        <li><b>Matching:</b> we use the areas you choose under "What I do" and your postcode district to tell you about nearby requests (<i>legitimate interests</i>; you can turn this off in your profile).</li>
        <li><b>Price guide:</b> we show typical prices for each area of work, worked out from offers on NearTask. Only totals are shown, never who quoted or for which job (<i>legitimate interests</i>).</li>
        <li><b>Track record:</b> profiles show how many jobs someone completed or how many people they hired, and their usual reply time. Only counts and an average are shown, never the jobs or messages themselves (<i>legitimate interests</i>).</li>
        <li><b>Safety:</b> preventing fraud, reviewing reports and problem reports, and suspending accounts that break our rules (<i>legitimate interests</i>).</li>
        <li>To meet legal obligations, for example responding to lawful requests (<i>legal obligation</i>).</li>
        <li>To send phone notifications, only if you turn them on (<i>consent</i>, which you can withdraw in your phone settings).</li>
      </ul>
      <p>We don't sell your data and we don't use it for advertising.</p>

      <h2>Notifications</h2>
      <ul>
        <li>Job-matching notifications are on when you choose areas under "What I do". You can turn them off in your profile.</li>
        <li>We do not send marketing messages. If we ever do, we will ask first, with a setting separate from job-matching notifications.</li>
      </ul>

      <h2>Who can see what</h2>
      <ul>
        <li>Your profile name, photo, area, bio, the areas you work in, work photos, fixed-price services, track record, rating and reviews are visible to other users.</li>
        <li>A price you quote is visible to the person who posted the request.</li>
        <li>Messages are only visible to the two people in the conversation.</li>
        <li>Our admins can see reports and problem reports and take action on accounts and listings.</li>
        <li>We do not show anyone's age to other users.</li>
      </ul>

      <h2>Service providers</h2>
      <p>These providers process data only to run their service for us. Where data is transferred outside the UK, it is protected by appropriate safeguards such as UK adequacy regulations or standard contractual clauses.</p>
      <ul>
        <li><b>Supabase:</b> database, sign-in and photo storage (all account and app data).</li>
        <li><b>GitHub Pages:</b> hosts the app (your IP address when the app loads).</li>
        <li><b>Google Fonts and jsDelivr:</b> deliver the app's font and a code library (your IP address).</li>
        <li><b>OpenStreetMap and postcodes.io:</b> map images and postcode lookups (your IP address, the map area you view, the postcode district you enter).</li>
      </ul>

      <h2>How long we keep it</h2>
      <ul>
        <li>Account, listings, services, offers, messages and notifications: while your account is open; deleted when you delete it.</li>
        <li>Problem reports: as long as needed to deal with them, and no longer than 2 years.</li>
        <li>Backups are overwritten within 30 days. We may keep a record of a suspension if needed to stop repeat abuse.</li>
      </ul>

      <h2>Your rights</h2>
      <p>You can ask for a copy of your data, correct it, object to or restrict how we use it, withdraw consent, or delete it. Deleting your account in the app (Profile → Delete account) removes your profile, listings, offers, messages and photos. For anything else, email {COMPANY.email}; we reply within one month. You can also complain to the ICO at ico.org.uk.</p>

      <h2>Users aged 16 and 17</h2>
      <ul>
        <li>NearTask is for people aged 16 and over.</li>
        <li>Jobs and services involving selling or serving alcohol, childcare or care are for people aged 18 and over, and NearTask blocks offers and bookings for them from 16 and 17-year-olds.</li>
        <li>Businesses taking on 16 and 17-year-olds must follow the extra rules for young workers, including limits on hours and night work.</li>
      </ul>

      <h2>Changes</h2>
      <p>If we make important changes we'll tell you in the app.</p>
    </Doc>
  );
}

export function Terms() {
  return (
    <Doc title="Terms of Use">
      <p>These terms are an agreement between you and {who()}, which runs NearTask. By creating an account you agree to them.</p>

      <h2>1. What NearTask is</h2>
      <p>NearTask is a local marketplace that connects people and businesses for shifts and home services around Keynsham, Bristol and Bath. We provide an online space where users find each other. We do not choose, supply or manage workers, set anyone's pay or hours, or charge either side for introductions, and we are not a party to any agreement you make with another user. Pay, hours, safety and the quality of work are agreed between you and the other person.</p>

      <h2>2. Your account</h2>
      <ul>
        <li>You must be 16 or over and give accurate information, including your age group. Jobs and services involving alcohol, childcare or care need you to be 18 or over.</li>
        <li>Keep your password safe. You are responsible for what happens on your account.</li>
        <li>One person or business per account. Do not impersonate anyone.</li>
      </ul>

      <h2>3. Zero tolerance for abuse</h2>
      <p>You must not post or send anything that is harassing, hateful, threatening, sexual or violent; discriminatory on grounds such as race, religion, sex, sexual orientation, disability or age; fraudulent or misleading, including fake jobs or asking anyone to pay to apply; or illegal, including work for people who do not have the right to work in the UK.</p>
      <p>You can report listings and people, and block anyone. We review reports as quickly as we can and may remove content or suspend accounts that break these rules, without notice. If someone is in immediate danger, call 999 first.</p>

      <h2>4. Businesses posting jobs</h2>
      <ul>
        <li>You are responsible for deciding the correct employment status of anyone you take on, and for employment law, including right-to-work checks, the National Minimum Wage, holiday pay, health and safety, the rules for young workers and tax.</li>
        <li>Listings must describe real work with honest pay.</li>
      </ul>

      <h2>5. People posting requests</h2>
      <ul>
        <li>Describe the job honestly, including the answers to the quick questions, so helpers can quote fairly.</li>
        <li>You are responsible for a safe place to work and for paying what you agreed.</li>
      </ul>

      <h2>6. Helpers and their status</h2>
      <ul>
        <li>NearTask does not decide anyone's employment status. Whether you are an employee, a worker or self-employed depends on the real arrangement between you and the person or business you work for, and your rights and duties (such as pay, holiday, tax and National Insurance) follow from that. If you work for yourself, you are responsible for your own tax, National Insurance and any licences, qualifications or checks the work needs (for example a DBS check for childcare or care).</li>
        <li>We recommend public liability insurance for trades, cleaning, moving and similar work.</li>
        <li>Work photos, skills and your track record must be your own and true.</li>
      </ul>

      <h2>7. Quotes</h2>
      <ul>
        <li>A price you give with an offer is a quote for the job as described. It is valid for 48 hours unless you withdraw it sooner or the poster accepts someone else. Once the poster accepts it, it is your agreed price.</li>
        <li>After 48 hours the quote is marked as expired and cannot be accepted until you send an updated quote.</li>
        <li>If the job turns out different from the description, agree any change of price in the chat before you start.</li>
        <li>The price guide shows typical quotes from other users. It is a guide only, not a price we set or guarantee.</li>
      </ul>

      <h2>8. Fixed-price services and bookings</h2>
      <ul>
        <li>A fixed-price service is an offer at a set price that customers can book. The helper confirms or declines each booking in the chat.</li>
        <li>Either side can cancel free of charge up to 24 hours before the booked time. After that:
          <ul>
            <li><b>Customer cancels less than 24 hours before:</b> no charge, unless the helper has already set off; then the customer pays reasonable travel costs the helper asks for in the chat.</li>
            <li><b>Customer cancels after work has started:</b> the customer pays for the work done so far, at the agreed price or rate.</li>
            <li><b>Helper cancels late or doesn't turn up:</b> no charge to the customer. Repeated late cancellations or no-shows can lead to suspension.</li>
            <li><b>You can't agree:</b> either side can report it (section 10). We can't decide who owes what; for money disputes you keep your normal legal rights.</li>
          </ul>
        </li>
        <li>If the work needed is more than the service describes, agree the extra in the chat before you start.</li>
      </ul>

      <h2>9. Payments and fees</h2>
      <ul>
        <li>NearTask is free to use at the moment. We do not take payment for jobs, hold money or charge commission.</li>
        <li>You pay each other directly, as you agree in the chat. We recommend paying once the job is done.</li>
        <li>If we introduce fees, we will tell you at least 30 days before and you can close your account first.</li>
      </ul>

      <h2>10. NearTask Promise (complaint review, not a guarantee)</h2>
      <ul>
        <li>The NearTask Promise is a complaint review and account safety process. It is not insurance, a payment guarantee, a refund or compensation.</li>
        <li>If something goes wrong with a job agreed through NearTask, either side can report it in the chat within 72 hours of the job being marked as done (or of the job date).</li>
        <li>Our team will review the report, may contact you both, and can warn, suspend or remove the other person. For money disputes you keep your normal legal rights, including the small claims process.</li>
      </ul>

      <h2>11. Notifications and matching</h2>
      <ul>
        <li>When you choose areas under "What I do", we send you new requests and shifts posted near you in those areas. You can turn this off in your profile at any time.</li>
        <li>Requests you post may be sent to helpers nearby who chose that area.</li>
      </ul>

      <h2>12. Reviews</h2>
      <p>Reviews must be honest and based on real work agreed through NearTask. We may remove reviews that are fake, abusive or not about the work.</p>

      <h2>13. Your content</h2>
      <p>You keep ownership of what you post, including work photos. You give us permission to display it in NearTask so the service works.</p>

      <h2>14. Our responsibility</h2>
      <p>We work to keep NearTask available and safe, but we cannot promise it will always be available or error-free. We are responsible for loss you suffer that is a foreseeable result of us breaking these terms or not using reasonable care and skill. We are not responsible for what other users do or for agreements between users, because we do not take part in them. Nothing in these terms takes away your legal rights as a consumer, or limits liability that cannot be limited by law, such as for death or personal injury caused by negligence, or for fraud.</p>

      <h2>15. Ending your account</h2>
      <p>You can delete your account at any time in the app. We may suspend or close accounts that break these terms.</p>

      <h2>16. Changes and law</h2>
      <p>We will tell you in the app before important changes to these terms take effect. These terms are governed by the law of England and Wales.</p>
    </Doc>
  );
}
