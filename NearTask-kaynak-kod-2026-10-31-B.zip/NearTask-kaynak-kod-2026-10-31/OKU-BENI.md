# NearTask – kaynak kod paketi (31 Ekim 2026)

## İçindekiler

| Klasör | Ne var | Ne kadar güncel |
| --- | --- | --- |
| `site/` | neartask.co.uk'de şu an yayında olan dosyaların tamamı (derlenmiş `index.html`, gizlilik, şartlar, hesap silme, PWA dosyaları, `.well-known/assetlinks.json`) | **Canlı ile birebir aynı** (GitHub, 31 Ekim) |
| `app/supabase/live-2026-10-31/` | Canlı veritabanının tam SQL dökümü: 18 tablo, 54 fonksiyon, 30 güvenlik kuralı, 15 tetikleyici, 23 indeks, fotoğraf deposu, 3 zamanlanmış görev | **Canlı ile birebir aynı.** Her fonksiyon canlı veritabanıyla karşılaştırıldı; boş bir veritabanında hatasız kuruldu |
| `app/supabase/functions/` | `send-push` ve `send-email` sunucu fonksiyonları | **Canlı ile aynı** (send-email sürüm 3) |
| `app/src/`, `app/package.json`, `app/scripts/` … | React/TypeScript kaynak kodu (v12) + 31 Ekim değişiklikleri (destek e-postası ayarı, yönetici paneli → Settings) | **27 Ekim sürümü.** Aşağıdaki nota bak |
| `app/supabase/*.sql` (v3–v7, schema.sql) | Eski adım adım veritabanı dosyaları | Tarihçe; yeni kurulumda `live-2026-10-31` kullan |
| `history/` | GitHub geçmişinden kurtarılan eski SQL ve not dosyaları | Tarihçe |

## Önemli: `app/src` canlı siteden geride

Ulaşabildiğim en yeni React kaynağı 27 Ekim tarihli v12. Canlı site 28 Ekim'de kaynağı GitHub'a yüklenmemiş daha yeni bir sürümle 9 kez güncellenmiş. Canlı sitedeki metinlerle karşılaştırınca v12'de şunlar eksik görünüyor:

- Yönetici paneli **Jobs** sekmesi (tamamlanan işler, geri alma, iptaller, iş geçmişi)
- Kabul edilmiş işi **iptal etme** akışı ve "iş bitti" zaman kontrolü
- **Takvime ekle** (Google / Apple)
- Profilde **e-posta bildirimi** açma/kapama
- Tanıtım ekranları ("How it works") ve bazı kayıt/hata metinleri

Veritabanı ve sunucu tarafı (`live-2026-10-31`) bu özelliklerin hepsini içeriyor. Eksik olan yalnızca ekran kodu.

**Ne yapmalı:** Özel depon `alitekincelik-lang/neartask-source` içindeki zip'te 28 Ekim sonrası kaynak varsa en güncel kod odur. Yoksa eksik ekranları canlı siteden yeniden yazmak gerekir.

## Kullanım

- Siteyi yayınlamak: `site/` klasörünün içeriği GitHub Pages'e olduğu gibi yüklenir.
- Kaynaktan derlemek: `app/` içinde `npm install` ve `npm run build:single`. Bu komut, `app/` sürümünü (v12 + destek e-postası ayarı) derler.
- Veritabanını sıfırdan kurmak: yeni Supabase projesinde SQL Editor'de sırayla `01_tables.sql`, `02_functions.sql`, `03_security_triggers_jobs.sql`. `02_functions.sql` içindeki `send_due_emails` fonksiyonu eski projenin adresini kullanıyor; yeni projede güncelle.
- Gizli anahtarlar pakette yok (service_role, VAPID özel anahtarı, Resend). `.env.production` içindeki anon anahtarı herkese açık olacak şekilde tasarlanmıştır.

## 31 Ekim 2026 – Plan B (SEO, uygulama kodu değişmedi)
- `site/index.html` ve `app/index.html`: yeni başlık, açıklama, canonical, Open Graph/Twitter etiketleri, Organization + WebSite yapısal verisi (JSON-LD). Uygulama betiği birebir aynı.
- `site/privacy.html`, `terms.html`, `delete-account.html`: canonical ve açıklama eklendi.
- Yeni: `site/robots.txt`, `site/sitemap.xml`, `site/og-image.png` (paylaşım önizlemesi, 1200×630). Aynıları `app/public/` içinde.
